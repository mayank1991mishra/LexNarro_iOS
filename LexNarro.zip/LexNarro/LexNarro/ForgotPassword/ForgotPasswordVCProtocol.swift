//
//  ForgotPasswordVCProtocol.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation

@objc protocol ForgotPasswordVCProtocol:class {
    func hideSubviews(target:ForgotPasswordVC)
    func addAnimationOnWelcomeLabel(target:ForgotPasswordVC)
    func validateEmailAddress(target: ForgotPasswordVC) -> Bool
    func doProceed(target: ForgotPasswordVC, username:String)
    func addAnimationOnForgotPasswordVCButton(target:ForgotPasswordVC)

}
