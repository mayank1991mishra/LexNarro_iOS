//
//  ForgotPasswordVCViewModel.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash

class ForgotPasswordVCViewModel: ForgotPasswordVCProtocol {
    func addAnimationOnForgotPasswordVCButton(target: ForgotPasswordVC) {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 3
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: target.btnProceed.center.x - 10, y: target.btnProceed.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: target.btnProceed.center.x + 10, y: target.btnProceed.center.y))
        target.btnProceed.layer.add(animation, forKey: "position")
        
    }
    
    func doProceed(target: ForgotPasswordVC, username: String) {
        target.btnProceed.isEnabled = false
        if !validateEmailAddress(target: target) {
            target.txtFldUserName.shakeTextField(errorMessage: "Please enter valid email address") { (status) in
                target.btnProceed.isEnabled = true
            }
            addAnimationOnForgotPasswordVCButton(target: target)
        }else{
            target.btnProceed.isEnabled = true
            if !CommonFunctions.checkInternetConnection() {
                
                CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
                return
            }
            CommonFunctions.showLoader()
            let soapMessage = """
            <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:for="http://www.lexnarro.com.au/services/ForgotPassword.asmx">
            <soapenv:Header/>
            <soapenv:Body>
            <for:mailPassword>
            <for:emailId>\(username)</for:emailId>
            </for:mailPassword>
            </soapenv:Body>
            </soapenv:Envelope>
            """
            SoapClient.sharedManager.callWebServiceWithSoapMessage(serviceUrl: LexString.WebService.ForgotPassword.mailPasswordService, soapAction: LexString.WebService.ForgotPassword.mailPasswordSoapAction, soapMessage: soapMessage) { (responseString, message) in
                
                if let response = responseString{
                     let xml = SWXMLHash.parse(response)
                    let messageStr = xml["soap:Envelope"]["soap:Body"]["mailPasswordResponse"]["mailPasswordResult"]["Message"].element?.text ?? ""
                    
                    let status = xml["soap:Envelope"]["soap:Body"]["mailPasswordResponse"]["mailPasswordResult"]["Status"].element?.text ?? ""
                    if status == "SUCCESS" || status == "Success" || status == "success" {
                        CommonFunctions.showAlertMessage(title: "Success", message: messageStr, viewController: target)

                    }else{
                        CommonFunctions.showAlertMessage(title: status, message: messageStr , viewController: target)
                    }

                }else{
                    CommonFunctions.showAlertMessage(title: nil, message: message ?? "Unknown Error", viewController: target)
                }
                CommonFunctions.hideLoader()
            }
        }
    }
    
    func hideSubviews(target: ForgotPasswordVC) {
        target.lblWelcomeCenterX.constant -= target.view.bounds.width
        target.leasdingConstraint.constant -= target.view.bounds.width
    }
    
    func addAnimationOnWelcomeLabel(target: ForgotPasswordVC) {
        UIView.animate(withDuration: 0.8, delay: 0.0, options: [.transitionCurlDown], animations: {
            target.lblWelcomeCenterX.constant += target.view.bounds.width
            target.leasdingConstraint.constant += target.view.bounds.width
            target.view.layoutIfNeeded()
            
        }, completion: nil)
    }
    
    func validateEmailAddress(target: ForgotPasswordVC) -> Bool {
        var isValidate = false
        
        if target.txtFldUserName.text!.isEmpty{
            isValidate = false
        }else if !target.txtFldUserName.text!.isValidEmail(){
            isValidate = false
        }
        else{
            isValidate = true
        }
        
        return isValidate
    }
    
}
