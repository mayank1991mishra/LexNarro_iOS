//
//  ForgotPasswordVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController {
    @IBOutlet weak var leasdingConstraint: NSLayoutConstraint!
    @IBOutlet weak var lblWelcomeCenterX: NSLayoutConstraint!
    @IBOutlet weak var txtFldUserName: TextFieldWithIcon!
    @IBOutlet weak var btnProceed: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ForgotPasswordVCViewModel().hideSubviews(target: self)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        ForgotPasswordVCViewModel().addAnimationOnWelcomeLabel(target: self)
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnForgotPasswordAction(_ sender: Any) {
        ForgotPasswordVCViewModel().doProceed(target: self, username: txtFldUserName.text!)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
