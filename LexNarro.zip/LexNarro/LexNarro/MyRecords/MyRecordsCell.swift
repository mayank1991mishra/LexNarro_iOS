//
//  MyRecordsCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 27/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

protocol MyRecordsDelegate:class  {
    func openRecordsDetails(cell:UITableViewCell,userTraining:UserTrainingTransaction)
    func editRecordsDetails(cell:UITableViewCell,userTraining:UserTrainingTransaction)
    func deleteRecordsDetails(cell:UITableViewCell,userTraining:UserTrainingTransaction)
}

class MyRecordsCell: UITableViewCell {
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblActivity: UILabel!
    @IBOutlet weak var lblUnits: UILabel!
    
    @IBOutlet weak var lblProvider: UILabel!
    @IBOutlet weak var lblYear: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDetails: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    var delegate:MyRecordsDelegate?
    var userTraining:UserTrainingTransaction!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func loadData(userTrainingTransaction:UserTrainingTransaction,delegate: MyRecordsVC){
        userTraining = userTrainingTransaction
        self.delegate = delegate
        lblDate.text = userTrainingTransaction.date
        lblCategory.text = userTrainingTransaction.categoryName
        lblActivity.text = userTrainingTransaction.activityName
        lblUnits.text = userTrainingTransaction.units
        lblProvider.text = userTrainingTransaction.provider
        lblYear.text = userTrainingTransaction.CPDYear
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnEditAction(_ sender: Any) {
        self.delegate?.editRecordsDetails(cell: self, userTraining: userTraining)
    }
    @IBAction func btnDetailsAction(_ sender: Any) {
        delegate?.openRecordsDetails(cell: self, userTraining: userTraining)
    }
    @IBAction func btnDeleteAction(_ sender: Any) {
        delegate?.deleteRecordsDetails(cell: self, userTraining: userTraining)
    }
    
}
