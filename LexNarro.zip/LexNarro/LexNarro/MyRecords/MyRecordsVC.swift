//
//  MyRecordsVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 27/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash


struct UserTrainingTransaction:Comparable {
    
    static func == (lhs: UserTrainingTransaction, rhs:UserTrainingTransaction) -> Bool{
        
        return lhs.Id == rhs.Id
    }
    
    static func < (lhs: UserTrainingTransaction, rhs: UserTrainingTransaction) -> Bool {
        
        return lhs.Id < rhs.Id
    }
    
    var Id:String
    var transactionId:String
    var userId:String
    var firstName:String
    var date:String
    var stateId:String
    var stateName:String
    var categoryId:String
    var categoryName:String
    var activityId:String
    var activityName:String
    var subActivityId:String
    var subActivityName:String
    var hours:String
    var provider:String
    var CPDYear:String
    var descrption:String
    var units:String
    
}

class MyRecordsVC: UIViewController {
    
    @IBOutlet weak var btnCPDYear: UIButton!
    @IBOutlet weak var tblView: UITableView!
    var arrayTransactions = [UserTrainingTransaction]()
    var selectedCPDYear:DashboardCPDYearModel!
    
    @IBOutlet weak var bottomView: UIStackView!
    //var selectedFinYear:DashboardFinancialYearModel!
    var selectedIndexYear = 0
    var dataFromService = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        dataFromService = false
        tblView.tableFooterView = UIView()
        
        tblView.estimatedRowHeight = 297
        tblView.rowHeight = UITableView.automaticDimension
        
        if let cpYear =  CommonFunctions().objAppdelegate.selectedCPDYear{
            selectedCPDYear = cpYear
            callWebserviceUserTrainingTransaction(email:  User.fetchCurrentUser()?.emailAddress ?? "", CPDYear: selectedCPDYear.value)
            
            selectedIndexYear = CommonFunctions.calCulateSelectedIndex(selectedYear: selectedCPDYear.value)
            btnCPDYear.setTitle(selectedCPDYear.value, for: .normal)
            
        }else{
            let cpdYear = CommonFunctions.calCulateCPDYear(date1: Date())
            callWebserviceUserTrainingTransaction(email:  User.fetchCurrentUser()?.emailAddress ?? "", CPDYear: cpdYear)
            selectedIndexYear = CommonFunctions.calCulateSelectedIndex(selectedYear: cpdYear)
            btnCPDYear.setTitle(cpdYear, for: .normal)
            
        }
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
        
    }
    @IBAction func btnDownloadAction(_ sender: Any) {
        let user = User.fetchCurrentUser()!
        
        let fileName = Date().currentTimeMillis()
        callWebServiceToDownloadTheReport(user: user, CPDYear: selectedCPDYear.value) {[unowned self] (pdfUrl, message) in
            
            // print(pdfUrl)
            if let pdf = pdfUrl, let url = URL(string: pdf){
                
                CommonFunctions.savePdf(pdfUrl: url, fileName: "\(fileName)", completion: { (message) in
                    OperationQueue.main.addOperation({
                        let vc = ViewReportVC.instantiate(fromAppStoryboard: .Dashboard)
                        vc.urlString = pdf
                        vc.fileName = "LexNarro-\(fileName).pdf"
                        self.navigationController?.pushViewController(vc, animated: true)
                    })
                    
                })
            }
        }
    }
    @IBAction func btnEmailAction(_ sender: Any) {
        let user = User.fetchCurrentUser()!
        
        callWebServiceToEmailTheReport(user: user, CPDYear: selectedCPDYear.value) { (message, errorMessage) in
            
        }
    }
    
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func btnCreateNewrecordAction(_ sender: Any) {
        let createNewRecordVC = CreateNewRecordVC.instantiate(fromAppStoryboard: .LeftMenu)
        createNewRecordVC.objNavigationType = .PUSH
        self.navigationController?.pushViewController(createNewRecordVC, animated: true)
    }
    
    @IBAction func btnSelectFinYearAction(_ sender: Any) {
        if CommonFunctions().objAppdelegate.CPDYear == nil || CommonFunctions().objAppdelegate.CPDYear?.count == 0{
            CommonFunctions.showAlertMessage(title: nil, message: "No Previous CPD Years are available.", viewController: self)
            return
        }
        
        
        let email = User.fetchCurrentUser()?.emailAddress ?? ""
        
        let btn = sender as! UIButton
        let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
        // let data = ["2018-2019"]
        pickerPopupVC.selectedIndex = selectedIndexYear
        pickerPopupVC.showPickerForData(data: CommonFunctions().objAppdelegate.CPDYear!) {[unowned self] (selectedData,selectedIndex) in
            self.selectedIndexYear = selectedIndex
            self.selectedCPDYear  = selectedData as? DashboardCPDYearModel
            //self.selectedFinYearString = self.selectedFinYear.value
            btn.setTitle(self.selectedCPDYear?.value ?? "", for: .normal)
            self.callWebserviceUserTrainingTransaction(email:  email, CPDYear: self.selectedCPDYear?.value ?? "")
            
        }
        // pickerPopupVC.delegate = self
        self.present(pickerPopupVC, animated: true, completion: nil)
        
    }
    
    func callWebserviceToDeleteTransaction(Id:String,userTraining: UserTrainingTransaction,indexPath:IndexPath){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:DeleteTraining>
        <!--Optional:-->
        <tra:Id>\(Id)</tra:Id>
        </tra:DeleteTraining>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.deleteTrainingService) else{return}
        
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.deleteTrainingSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["DeleteTrainingResponse"]["DeleteTrainingResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["DeleteTrainingResponse"]["DeleteTrainingResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: self)
                    OperationQueue.main.addOperation({
                        if self.arrayTransactions.count > 1 {
                            let index = self.arrayTransactions.firstIndex(of: userTraining)
                            self.arrayTransactions.remove(at: index!)
                            self.tblView.beginUpdates()
                            self.tblView.deleteRows(at: [indexPath], with: .automatic)
                            self.tblView.endUpdates()
                        }else{
                           self.arrayTransactions.removeAll()
                            self.tblView.reloadData()
                        }
                        NotificationCenter.default.post(name: Notification.Name(LexNotification.RefereshData), object: nil)
                    })
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebserviceUserTrainingTransaction(email:String,CPDYear:String){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:GetTraining>
        <tra:email>\(email)</tra:email>
        <tra:finYear>\(CPDYear)</tra:finYear>
        </tra:GetTraining>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.getTrainingService) else{return}
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.getTrainingSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetTrainingResponse"]["GetTrainingResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetTrainingResponse"]["GetTrainingResult"]["Message"].element?.text ?? ""
                
                self.dataFromService = true
                
                if (status == "Success")  || (status == "SUCCESS") {
                    self.arrayTransactions.removeAll()
                    
                    for elem in xml["soap:Envelope"]["soap:Body"]["GetTrainingResponse"]["GetTrainingResult"]["UserTraining"]["UserTrainingTransaction"].all {
                        
                        let date = !(elem["Date"].element?.text ?? "").isEmpty ? (elem["Date"].element?.text ?? "").components(separatedBy: "T") : [""]
                        
                        
                        
                        let transaction =  UserTrainingTransaction(Id: elem["Id"].element?.text ?? "", transactionId: elem["TransactionId"].element?.text ?? "", userId: elem["User_Id"].element?.text ?? "", firstName: elem["FirstName"].element?.text ?? "", date: date.first!, stateId: elem["StateId"].element?.text ?? "", stateName: elem["StateName"].element?.text ?? "", categoryId: elem["CategoryId"].element?.text ?? "", categoryName: elem["CategoryName"].element?.text ?? "", activityId: elem["ActivityId"].element?.text ?? "", activityName: elem["ActivityName"].element?.text ?? "", subActivityId: elem["SubActivityId"].element?.text ?? "", subActivityName: elem["SubActivityName"].element?.text ?? "", hours: elem["Hours"].element?.text ?? "", provider: elem["Provider"].element?.text ?? "", CPDYear: elem["Financial_Year"].element?.text ?? "", descrption: elem["Descrption"].element?.text ?? "", units: elem["Units"].element?.text ?? "")
                        
                        self.arrayTransactions.append(transaction)
                    }
                    
                    print(self.arrayTransactions)
                    
                    
                    
                }else {
                    self.arrayTransactions.removeAll()
                    
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
                OperationQueue.main.addOperation({
                    self.arrayTransactions = self.arrayTransactions.reversed()
                    self.bottomView.isHidden = self.arrayTransactions.isEmpty
                    self.tblView.reloadData()
                })
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebServiceToDownloadTheReport(user:User,CPDYear:String,completion: @escaping(String?,String)-> Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dow="http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <dow:DownloadTrainingReport>
        <dow:finYear>\(CPDYear)</dow:finYear>
        <dow:userEmail>\(user.emailAddress ?? "")</dow:userEmail>
        <dow:user_Id>\(user.userId ?? "")</dow:user_Id>
        <dow:stateShortName>\(user.stateEnrolledShortName ?? "")</dow:stateShortName>
        </dow:DownloadTrainingReport>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.DownloadAndEmailService.downloadTrainingReportService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.DownloadAndEmailService.downloadTrainingReportsoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(nil,error.debugDescription)
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["Message"].element?.text ?? ""
                let documentUrl = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["DocumentUrl"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    completion(documentUrl,message)
                    
                }else {
                    completion(nil,message)
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebServiceToEmailTheReport(user:User,CPDYear:String,completion: @escaping(String?,String)-> Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dow="http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <dow:EmailTrainingReport>
        <dow:finYear>\(CPDYear)</dow:finYear>
        <dow:userEmail>\(user.emailAddress ?? "")</dow:userEmail>
        <dow:user_Id>\(user.userId ?? "")</dow:user_Id>
        <dow:stateShortName>\(user.stateEnrolledShortName ?? "")</dow:stateShortName>
        </dow:EmailTrainingReport>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.DownloadAndEmailService.emailTrainingReportService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.DownloadAndEmailService.emailTrainingReportSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(nil,error.debugDescription)
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["EmailTrainingReportResponse"]["EmailTrainingReportResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["EmailTrainingReportResponse"]["EmailTrainingReportResult"]["Message"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    completion(nil,message)
                    
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: self)
                    
                    
                }else {
                    completion(nil,message)
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension MyRecordsVC:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrayTransactions.isEmpty {
            let lbl = CommonFunctions.addEmptyMessageLablel(text: "No records available for this CPD Year ",dataFromService: dataFromService)
            tableView.backgroundView = lbl
            return 0
        }
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayTransactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyRecordsCell", for: indexPath) as! MyRecordsCell
        cell.loadData(userTrainingTransaction: arrayTransactions[indexPath.row],delegate: self)
        return cell
        
    }
    
    
}

extension MyRecordsVC:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
}
extension MyRecordsVC:MyRecordsDelegate{
    func openRecordsDetails(cell: UITableViewCell, userTraining: UserTrainingTransaction) {
        let indexPath = tblView.indexPath(for: cell)
        
        let openRecordDetails = CreateNewRecordVC.instantiate(fromAppStoryboard: .LeftMenu)
        openRecordDetails.objNavigationType = .DETAILS
        openRecordDetails.objUserTrainingTransaction = arrayTransactions[(indexPath?.row)!]
        self.navigationController?.pushViewController(openRecordDetails, animated: true)
        
    }
    
    func editRecordsDetails(cell: UITableViewCell, userTraining: UserTrainingTransaction) {
        let indexPath = tblView.indexPath(for: cell)
        
        let openRecordDetails = CreateNewRecordVC.instantiate(fromAppStoryboard: .LeftMenu)
        openRecordDetails.objNavigationType = .EDIT
        openRecordDetails.objUserTrainingTransaction = arrayTransactions[(indexPath?.row)!]
        
        self.navigationController?.pushViewController(openRecordDetails, animated: true)
        
    }
    
    func deleteRecordsDetails(cell: UITableViewCell, userTraining: UserTrainingTransaction) {
        guard let indexPath = tblView.indexPath(for: cell) else {return}
        
        let alertVC = UIAlertController(title: nil, message: "Are you sure? you want to delete record.", preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "YES", style: .default, handler: { (action) in
            self.callWebserviceToDeleteTransaction(Id: userTraining.Id, userTraining: userTraining, indexPath: indexPath)
        }))
        alertVC.addAction(UIAlertAction(title: "NO", style: .cancel, handler: { (action) in
            
        }))
        self.present(alertVC, animated: true, completion: nil)
    }
    
    
}
