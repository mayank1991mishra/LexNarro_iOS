//
//  SubCategoryShortCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class SubCategoryShortCell: UICollectionViewCell {
    @IBOutlet weak var viewDot: SolidCircle!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgViewCompleted: UIImageView!
    
    func loadData(target:DashboardVC,cattegory:DashboardCategoryModel,execCategory:DashboardExistingCategoryModel) {
        lblName.text = cattegory.shortName
        let unitsDone:Float = Float(execCategory.unitsDone) ?? 0.0
        imgViewCompleted.isHidden = unitsDone >= Float(1.0) ? false : true
       }
}
