//
//  CarrayOverVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 05/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash

struct CrrayOver {
    var Id:String
    var transactionId:String
    var userId:String
    var firstName:String
    var date:String
    var stateId:String
    var stateName:String
    var categoryId:String
    var categoryName:String
    var activityId:String
    var activityName:String
    var subActivityId:String
    var subActivityName:String
    var hours:String
    var provider:String
    var yourRole:String
    var CPDYear:String
    var forwardable:String
    var hasbeenForwarded:String
    var desc:String
    var units:String
    var isSelected:Bool
    
}

class CrrayOverVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var arrayCarrayOver = [CrrayOver]()
    
    @IBOutlet weak var btnCarryOver: UIButton!
    @IBOutlet weak var btnCPDYear: UIButton!
    @IBOutlet weak var lblAllowedUnits: UILabel!
    @IBOutlet weak var imgCarryOver: UIImageView!
    var CPDYear:[DashboardCPDYearModel] = [DashboardCPDYearModel]()
    var arraySelectedCarrayOver = [CrrayOver]()
    var selectedCPDYear:DashboardCPDYearModel!
    var selectedIndexYear = 0
    var dataFromService = false
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnCarryOver.isHidden = true
        self.imgCarryOver.isHidden = true

        tblView.estimatedRowHeight = 290
        tblView.rowHeight = UITableView.automaticDimension
     // let currentCPDYear =  CommonFunctions.calCulateFinancialYear(date1: Date())
        if let cpYear =  CommonFunctions().objAppdelegate.selectedCPDYear{
            selectedCPDYear = cpYear
            callWebserviceTogetCarray(CPDYear: selectedCPDYear.value)
            selectedIndexYear = CommonFunctions.calCulateSelectedIndex(selectedYear: selectedCPDYear.value)
            btnCPDYear.setTitle(selectedCPDYear.value, for: .normal)

        }else{
            let cpdYear = CommonFunctions.calCulateCPDYear(date1: Date())
            callWebserviceTogetCarray(CPDYear: cpdYear)
            selectedIndexYear = CommonFunctions.calCulateSelectedIndex(selectedYear: cpdYear)
            btnCPDYear.setTitle(cpdYear, for: .normal)

        }
        CPDYear = CommonFunctions().objAppdelegate.CPDYear ??  [DashboardCPDYearModel]()
        dataFromService = false
    }
    

    
   
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnDoCarrayOverAction(_ sender: Any) {
       
        if !arraySelectedCarrayOver.isEmpty {
            callWebserviceToDoCarray(CPDYear: selectedCPDYear.value)
        }else{
            CommonFunctions.showAlertMessage(title: "Alert", message: "Please select units to carray over", viewController: self)
            
        }
    }
    
    @IBAction func btnCPDYearAction(_ sender: Any) {
        
        if CommonFunctions().objAppdelegate.CPDYear == nil || CommonFunctions().objAppdelegate.CPDYear?.count == 0{
            CommonFunctions.showAlertMessage(title: nil, message: "No Previous CPD Years are available.", viewController: self)
            return
        }

        
        let popupVC =  PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
        popupVC.selectedIndex = selectedIndexYear
        popupVC.showPickerForData(data: CPDYear) {[unowned self] (selectedData,selectedIndex)  in
            let fYear = selectedData as! DashboardCPDYearModel
            self.selectedIndexYear = selectedIndex
            self.selectedCPDYear = fYear
            self.btnCPDYear.setTitle(fYear.value, for: .normal)
            self.callWebserviceTogetCarray(CPDYear: fYear.value)
        }
        self.present(popupVC, animated: true, completion: nil)
        
    }
    
    func callWebserviceToDoCarray(CPDYear:String){
        let user = User.fetchCurrentUser()!
        var ids = [String]()
        var units = [String]()
        
        for carryOver in arraySelectedCarrayOver {
            ids.append(carryOver.Id)
            units.append(carryOver.units)
        }
        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:car="http://www.lexnarro.com.au/services/carryOver.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <car:DoCarryOver>
        <car:financialYear>\(CPDYear)</car:financialYear>
        <car:ids>\(ids.joined(separator: ","))</car:ids>
        <car:units>\(units.joined(separator: ","))</car:units>
        <car:userId>\(user.userId ?? "")</car:userId>
        <car:stateId>\(user.stateID ?? "")</car:stateId>
        </car:DoCarryOver>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.CarryOver.doService) else{return}
       
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.CarryOver.doSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
              //  print(backToString)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["DoCarryOverResponse"]["DoCarryOverResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["DoCarryOverResponse"]["DoCarryOverResult"]["Message"].element?.text ?? ""
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: self)
                    
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebserviceTogetCarray(CPDYear:String){
        let user = User.fetchCurrentUser()!
        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:car="http://www.lexnarro.com.au/services/carryOver.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <car:GetCarryOverRecords>
        <car:stateId>\(user.stateID ?? "")</car:stateId>
        <car:finYear>\(CPDYear)</car:finYear>
        <car:User_Id>\(user.userId ?? "")</car:User_Id>
        </car:GetCarryOverRecords>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.CarryOver.getService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.CarryOver.getSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetCarryOverRecordsResponse"]["GetCarryOverRecordsResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetCarryOverRecordsResponse"]["GetCarryOverRecordsResult"]["Message"].element?.text ?? ""
                let maximumUnitsAllowed = xml["soap:Envelope"]["soap:Body"]["GetCarryOverRecordsResponse"]["GetCarryOverRecordsResult"]["MaximumUnitsAllowed"].parsedText
                self.arrayCarrayOver.removeAll()
                self.dataFromService = true

                if (status == "Success")  || (status == "SUCCESS") {
                    
                    for elem in xml["soap:Envelope"]["soap:Body"]["GetCarryOverRecordsResponse"]["GetCarryOverRecordsResult"]["UserTraining"]["UserTrainingTransaction"].all {
                        
                        let date = !(elem["Date"].element?.text ?? "").isEmpty ? (elem["Date"].element?.text ?? "").components(separatedBy: "T") : [""]

                        let carrayOver = CrrayOver(Id: elem.pasredString(key: "Id"), transactionId: elem.pasredString(key: "TransactionId"), userId: elem.pasredString(key: "User_Id"), firstName: elem.pasredString(key: "FirstName"), date: date.first!, stateId: elem.pasredString(key: "StateId"), stateName: elem.pasredString(key: "StateName"), categoryId: elem.pasredString(key: "CategoryId"), categoryName: elem.pasredString(key: "CategoryName"), activityId: elem.pasredString(key: "ActivityId"), activityName: elem.pasredString(key: "ActivityName"), subActivityId: elem.pasredString(key: "SubActivityId"), subActivityName: elem.pasredString(key: "SubActivityName"), hours: elem.pasredString(key: "Hours"), provider: elem.pasredString(key: "Provider"), yourRole: elem.pasredString(key: "Your_Role"), CPDYear: elem.pasredString(key: "Financial_Year"), forwardable: elem.pasredString(key: "Forwardable"), hasbeenForwarded: elem.pasredString(key: "Has_been_Forwarded"), desc: elem.pasredString(key: "Descrption"), units: elem.pasredString(key: "Units"), isSelected: false)
                        
                        self.arrayCarrayOver.append(carrayOver)
                    }
                    OperationQueue.main.addOperation({
                        self.btnCarryOver.isHidden = false
                        self.imgCarryOver.isHidden = false
                        self.lblAllowedUnits.text = "Allowed units to transfer = \(maximumUnitsAllowed)"
                        self.tblView.reloadData()
                    })
                    
                }else {

                    OperationQueue.main.addOperation({
                        self.tblView.reloadData()
                        self.btnCarryOver.isHidden = true
                        self.imgCarryOver.isHidden = true
                        self.lblAllowedUnits.text = ""

                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    })
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension CrrayOverVC:  UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrayCarrayOver.isEmpty {
            let lbl = CommonFunctions.addEmptyMessageLablel(text: "No carry over available for this CPD Year ", dataFromService: dataFromService)
            tableView.backgroundView = lbl
            return 0
        }
        tableView.backgroundView = UIView()

        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrayCarrayOver.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CarrayOverCell", for: indexPath) as! CarrayOverCell
       // cell.btnSelect.isSelected =
        
        cell.delegate = self
        cell.loadData(data: arrayCarrayOver[indexPath.row])
        return cell
        
    }
}
extension CrrayOverVC:UITableViewDelegate{
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension

    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
}

extension CrrayOverVC: CarrayOverDelegate{
    func selectData(cell: CarrayOverCell) {
        let indexPath = tblView.indexPath(for: cell)!
        let carrayOver = arrayCarrayOver[indexPath.row]
        
        let isContains = arraySelectedCarrayOver.contains { (carr) -> Bool in
            return carr.Id == carrayOver.Id
        }
        
        if !isContains {
            arraySelectedCarrayOver.append(carrayOver)
           let carr = CrrayOver(Id: carrayOver.Id, transactionId: carrayOver.transactionId, userId: carrayOver.userId, firstName: carrayOver.firstName, date: carrayOver.date, stateId: carrayOver.stateId, stateName: carrayOver.stateName, categoryId: carrayOver.categoryId, categoryName: carrayOver.categoryName, activityId: carrayOver.activityId, activityName: carrayOver.activityName, subActivityId: carrayOver.subActivityId, subActivityName: carrayOver.subActivityName, hours: carrayOver.hours, provider: carrayOver.provider, yourRole: carrayOver.yourRole, CPDYear: carrayOver.CPDYear, forwardable: carrayOver.forwardable, hasbeenForwarded: carrayOver.hasbeenForwarded, desc: carrayOver.desc, units: carrayOver.units, isSelected: true)
            
            arrayCarrayOver[indexPath.row] = carr
        }else{
            if let index = arraySelectedCarrayOver.index(where: { (item) -> Bool in
                item.Id == carrayOver.Id // test if this is the item you're looking for
            }){
                arraySelectedCarrayOver.remove(at: index)
                let carr = CrrayOver(Id: carrayOver.Id, transactionId: carrayOver.transactionId, userId: carrayOver.userId, firstName: carrayOver.firstName, date: carrayOver.date, stateId: carrayOver.stateId, stateName: carrayOver.stateName, categoryId: carrayOver.categoryId, categoryName: carrayOver.categoryName, activityId: carrayOver.activityId, activityName: carrayOver.activityName, subActivityId: carrayOver.subActivityId, subActivityName: carrayOver.subActivityName, hours: carrayOver.hours, provider: carrayOver.provider, yourRole: carrayOver.yourRole, CPDYear: carrayOver.CPDYear, forwardable: carrayOver.forwardable, hasbeenForwarded: carrayOver.hasbeenForwarded, desc: carrayOver.desc, units: carrayOver.units, isSelected: false)
                
                arrayCarrayOver[indexPath.row] = carr

            }
        }
        
        tblView.reloadRows(at: [indexPath], with: .none)
        //tblView.reloadData()
        print(arraySelectedCarrayOver)
    }
    func clickUnit(cell: CarrayOverCell) {
        
    }
}
