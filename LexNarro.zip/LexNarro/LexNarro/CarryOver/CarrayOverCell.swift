//
//  CarrayOverCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 08/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

protocol CarrayOverDelegate:class {
    func selectRevordToCarrayOver(cell:CarrayOverCell)
    func editUnits(cell:CarrayOverCell,units:String)
}

class CarrayOverCell: UITableViewCell {
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblActivity: UILabel!
    @IBOutlet weak var lblUnits: UILabel!
    @IBOutlet weak var lblProvider: UILabel!
    @IBOutlet weak var lblCPDYear: UILabel!
   // @IBOutlet weak var btnUnits: UIButton!
    @IBOutlet weak var btnSelect: UIButton!
    weak var delegate:CarrayOverDelegate?
    @IBOutlet weak var txtUnits: UITextField!
    var units = "0.00"
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
      

        
    }

    func loadData(data:CrrayOver)  {
        lblDate.text = data.date
        lblCategory.text = data.categoryName
        lblActivity.text = data.activityName
        lblUnits.text = data.units
        lblProvider.text = data.provider
        lblCPDYear.text = data.CPDYear
        btnSelect.isSelected = data.isSelected
        txtUnits.text = data.editedUnits
        txtUnits.delegate = self
        units = data.units
        
    }
    @IBAction func btnSelectAction(_ sender: Any) {
        delegate?.selectRevordToCarrayOver(cell: self)
    }

    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension CarrayOverCell:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let editedUnits:String = textField.text! + string
        
        if  Double(editedUnits)! > Double(units)! {
            return false
        }
        return true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
       // textField.becomeFirstResponder()
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.delegate?.editUnits(cell: self, units: textField.text!)
    }
}

