//
//  LeftMenu.swift
//  UrbanDrive
//
//  Created by ANAND AVASTHI on 30/05/18.
//  Copyright © 2018 Roovea. All rights reserved.
//

import UIKit


class LeftMenuVC: CommonVC {
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var imgVwProfile: UIImageView!
    static let kTitle = "Title"
    static let kImageName = "ImageName"
    var objUserType = USERTYPE()
    //var arrayItems = [[String:String]]()
    
    
    
    var arraySidemenuItems = [[kTitle:"My Profile",kImageName:"menu_Profile"],
                              [kTitle:"My Records",kImageName:"menu_my_records"],
                              [kTitle:"Create New Records",kImageName:"menu_Create_New_Record"],
                              [kTitle:"Carry over",kImageName:"menu_Carray_over"],
                            [kTitle:"My Transaction",kImageName:"menu_MyTransaction"],
                            [kTitle:"My Subscription",kImageName:"menu_my_subscription"],
                            [kTitle:"Terms and Conditions",kImageName:"terms"],
                            [kTitle:"Privacy Policy",kImageName:"terms"]]
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        updateUI()
    }

    func openTermsAndPolicy(){
        let stryBoard = UIStoryboard(name: "LeftMenu", bundle: nil)
        let termsNavVC = stryBoard.instantiateViewController(withIdentifier: "WebBasedNavVC") as! CommonNavVC
        self.present(termsNavVC, animated: true, completion: nil)
        
    }
    
    @IBAction func btnLogoutAction(_ sender: Any) {
        let alertController = UIAlertController(title: "Logout", message: "Are you sure? you want to logout.", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "NO", style: .cancel, handler: nil))
        alertController.addAction(UIAlertAction(title: "YES", style: .default, handler: { (action) in
            OperationQueue.main.addOperation({
                User.deleteUser()
               let loginVC = LoginVC.instantiate(fromAppStoryboard: .Authentication)
                (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController = loginVC
            })
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    func updateUI()  {
      
    }
    

    func openProfile()  {
       let storyb = UIStoryboard(name: "Authentication", bundle: nil)
        guard let navSignupVc = storyb.instantiateViewController(withIdentifier: "navSignup") as? UINavigationController else{return}
        let signupVC = navSignupVc.viewControllers.first as? SignupVC
        signupVC?.naviagetionType = .PROFILE
        self.present(navSignupVc, animated: true, completion: nil)

    }
    
    
    func openCreateNewRecord()  {
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)
        
        let createNewRecordNavVC = storyboard.instantiateViewController(withIdentifier: "CreateNewRecordNavVC") as! UINavigationController
        let createNewRecordVC = createNewRecordNavVC.viewControllers.first as! CreateNewRecordVC
        createNewRecordVC.objNavigationType = .PRESENT
        self.present(createNewRecordNavVC, animated: false, completion: nil)
        
    }
    
    func openMyRecordsRecord()  {
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)
        
        let myRecordsNavVC = storyboard.instantiateViewController(withIdentifier: "MyRecordsNavVC") 
        self.present(myRecordsNavVC, animated: false, completion: nil)
        
    }
    
    func openMyTransaction()  {
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)

         let ObjMyTransactionNavVC = storyboard.instantiateViewController(withIdentifier: "MyTransactionNavVC")
        self.present(ObjMyTransactionNavVC, animated: false, completion: nil)

    }
    
    func openSubscriptionPlan()  {
        
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)

         let objSubscriptionNavVC = storyboard.instantiateViewController(withIdentifier: "SubscriptionNavVC")
        self.present(objSubscriptionNavVC, animated: false, completion: nil)
        
    }
    
    func openCarrayOver()  {
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)
        
        let carrayOverVC = storyboard.instantiateViewController(withIdentifier: "CarrayOverNavVC")

        self.present(carrayOverVC, animated: false, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension LeftMenuVC: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arraySidemenuItems.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCell
        let dict = arraySidemenuItems[indexPath.row]
        cell.imgView.image = UIImage(named: dict[LeftMenuVC.kImageName] ?? "")
        cell.lblTitle?.text = dict[LeftMenuVC.kTitle] ?? ""
        return cell
    }
}

extension LeftMenuVC:UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objSideMenuVC = self.parent as! SideMenuController
        objSideMenuVC.toggleMenu()
        
        switch indexPath.row {
        case 0:
            openProfile()
            break
        case 1:
            openMyRecordsRecord()
            break
        case 2:
            openCreateNewRecord()
            break
        case 3:
            openCarrayOver()
            break
        case 4:
            openMyTransaction()
            break
        case 5:
            openSubscriptionPlan()
            break
        case 6:
            objTermsAndPolicy = TermsAndPolicy.TERMS
            openTermsAndPolicy()
            break
        case 7:
            objTermsAndPolicy = TermsAndPolicy.POLICY

            openTermsAndPolicy()
            break
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
}
