//
//  CreateNewRecordVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 27/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash
import PDFKit

enum NavigationType {
    case PRESENT
    case PUSH
    case DETAILS
    case EDIT
    case PROFILE
    case Signup
    init(){
        self = .PRESENT
    }
}

extension CreateNewRecordVC{
    
}

struct Category {
    var Id:String
    var name:String
}

struct Activity {
    var Id:String
    var name:String
}

struct SubActivity {
    var Id:String
    var name:String
    var ActivityID:String
    var shortName:String
    var stateID:String
}

struct DetailTraining {
    var Id:String
    var transactionId:String
    var userId:String
    var firstName:String
    var date:String
    var stateId:String
    var stateName:String
    var categoryId:String
    var categoryName:String
    var activityId:String
    var activityName:String
    var subActivityId:String
    var subActivityName:String
    var hours:String
    var provider:String
    var CPDYear:String
    var descrption:String
    var fileName:String
    var units:String
    var role:String
    var imageLink:String
}

class CreateNewRecordVC: UIViewController {
    @IBOutlet weak var txtFldOnBoardingDate: TextFieldWithIcon!
    @IBOutlet weak var txtSelectCategory: TextFieldWithIcon?
    @IBOutlet weak var txtFldActivity: TextFieldWithIcon!
    @IBOutlet weak var txtFieldSubActivity: TextFieldWithIcon!
    @IBOutlet weak var txtProvider: TextFieldWithIcon!
    @IBOutlet weak var txtFldHours: TextFieldWithIcon!
    @IBOutlet weak var imgViewAttendee: UIImageView!
    @IBOutlet weak var imgViewPresentor: UIImageView!
    @IBOutlet weak var imgViewAuthor: UIImageView!
    @IBOutlet weak var viewDate: UIView!
    @IBOutlet weak var viewCategory: UIView!
    @IBOutlet weak var viewActivity: UIView!
    
    @IBOutlet weak var txtFldFileName: TextFieldWithIcon!
    @IBOutlet weak var txtViewDescription: UITextView!
    @IBOutlet weak var btnCreate: UIButton!
    @IBOutlet weak var btnSelectDate: UIButton!
    @IBOutlet weak var btncategory: UIButton!
    @IBOutlet weak var btnActivity: UIButton!
    @IBOutlet weak var btnSubActivity: UIButton!
    @IBOutlet weak var btnAttendee: UIButton!
    @IBOutlet weak var btnPresentor: UIButton!
    @IBOutlet weak var btnAuthor: UIButton!
    @IBOutlet weak var btnFileUpload: UIButton!
    @IBOutlet weak var lblAttendee: UILabel!
    @IBOutlet weak var lblPresenter: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var viewImageFile: UIView!
    @IBOutlet weak var imgViewFile: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var btnRemoveFile: UIButton!
    var objNavigationType:NavigationType?
    var objUserTrainingTransaction:UserTrainingTransaction!
    
    @IBOutlet weak var pdfPreview: UIView!
    var selectedActivity:Activity?
    var selectedSubActivity:SubActivity?
    var selectedCategory:Category?
    var role = ""
    private lazy var imagePicker = ImagePicker()
    var selectedImage:UIImage?
    var detailsTraining:DetailTraining!
    var pdfLink = ""
    
    
    @IBOutlet weak var viewPreviewAndDelete: UIView!
    //@IBOutlet weak var constraintViewHeight: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 219/255, green: 30/255, blue: 37/219, alpha: 1.0)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white]
        pdfPreview.isHidden = true
        viewImageFile.isHidden = true
        self.view.layoutIfNeeded()
        imagePicker.delegate = self
        if objNavigationType == .DETAILS {
            print(objUserTrainingTransaction.stateId)
            self.callWebserviceUserTrainingTransaction(transactId: objUserTrainingTransaction.Id)
            self.addViewToDisableUserIntraction(status: false)
            self.title = "Record Details"
            self.btnRemoveFile.isHidden = true
        }else if objNavigationType == .EDIT{
            self.title = "Edit Record"
            btnCreate.setTitle("UPDATE", for: .normal)
            self.callWebserviceUserTrainingTransaction(transactId: objUserTrainingTransaction.Id)
            self.addViewToDisableUserIntraction(status: true)
        }else{
            activityIndicator.stopAnimating()
            selectRoleWithRole(role: "")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
    private func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
        imagePicker.present(parent: self, sourceType: sourceType)
    }
    @IBAction func btnPreviewAction(_ sender: Any) {
        
        DispatchQueue.main.async {
            if self.pdfLink.contains(".pdf") {
                // self.downloadPdf(url: details.imageLink)
                guard let imgStr = self.pdfLink.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)else{return}
                let vc = ViewReportVC.instantiate(fromAppStoryboard: .Dashboard)
                vc.urlString = imgStr
                self.present(vc, animated: true, completion: nil)
            }else{
                let imagePreviewVC = ImagePreviewVC.instantiate(fromAppStoryboard: .Popup)
                imagePreviewVC.image = self.imgViewFile.image
                self.present(imagePreviewVC, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func btnRemoveAction(_ sender: Any) {
        self.viewImageFile.isHidden = true
        self.imgViewFile.image = nil
        self.pdfPreview.isHidden = true
        selectedImage = nil
        // txtFldFileName.text = ""
        self.view.layoutIfNeeded()
        
    }
    
    func addViewToDisableUserIntraction(status:Bool)  {
        self.txtFldHours.isUserInteractionEnabled = status
        self.txtProvider.isUserInteractionEnabled = status
        self.txtFldFileName.isUserInteractionEnabled = status
        self.txtViewDescription.isUserInteractionEnabled = status
        self.btnAuthor.isUserInteractionEnabled = status
        self.btnAttendee.isUserInteractionEnabled = status
        self.btnPresentor.isUserInteractionEnabled = status
        self.btncategory.isUserInteractionEnabled = status
        self.btnActivity.isUserInteractionEnabled = status
        self.btnSubActivity.isUserInteractionEnabled = status
        self.txtFldOnBoardingDate.isUserInteractionEnabled = status
        self.txtSelectCategory?.isUserInteractionEnabled = status
        self.txtFldActivity.isUserInteractionEnabled = status
        self.txtFieldSubActivity.isUserInteractionEnabled = status
        self.btnSelectDate.isUserInteractionEnabled = status
        self.btnFileUpload.isHidden = !status
        btnCreate.isHidden = !status
    }
    
    func isValidateSelectedDate() ->Bool  {
        return !self.txtFldOnBoardingDate!.text!.isEmpty
    }
    
    func isValidateCategory() ->Bool  {
        return !self.txtSelectCategory!.text!.isEmpty
    }
    
    func isValidateActivity() ->Bool  {
        return !self.txtFldActivity!.text!.isEmpty
    }
    
    func isValidateHours() ->Bool  {
        return !self.txtFldHours!.text!.isEmpty
    }
    
    func isValidateProvider() ->Bool  {
        return !self.txtProvider!.text!.isEmpty
    }
    
    func isValidateRole() ->Bool  {
        return !role.isEmpty
    }
    
    func isValidateFileName() ->Bool  {
        
        if  txtFldFileName.text!.isEmpty {
            return true
        }
        return false
    }
    
    func isValidateImage() ->Bool  {
        
        if !txtFldFileName.text!.isEmpty && (imgViewFile.image != nil){
            return true
        }
        return false
    }
    
    func callWebserviceToCreateRecord(user:User, completion:@escaping (String)->Void){
        let categoryId =  selectedCategory?.Id ?? ""
        let activityId =  selectedActivity?.Id ?? ""
        let subActivityId = selectedSubActivity?.Id ?? ""
        
        var base64Image = ""
        if let img = selectedImage{
            if let imageData:Data = img.jpegData(compressionQuality: 0.1){
                base64Image = imageData.base64EncodedString()
            }
        }
        
        let filename = "\(txtFldFileName.text ?? "")".trimmingCharacters(in: .whitespacesAndNewlines)
        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:CreateTraining>
        
        <tra:User_Id>\(user.userId ?? "")</tra:User_Id>
        
        <tra:Date>\(txtFldOnBoardingDate.text ?? "")</tra:Date>
        
        <tra:State_Id>\(user.stateEnrolled ?? "")</tra:State_Id>
        
        <tra:Category_Id>\(categoryId)</tra:Category_Id>
        
        <tra:Activity_Id>\(activityId)</tra:Activity_Id>
        
        <tra:SubActivity_Id>\(subActivityId)</tra:SubActivity_Id>
        
        <tra:Hours>\(txtFldHours.text ?? "")</tra:Hours>
        
        <tra:Provider>\(txtProvider.text ?? "")</tra:Provider>
        
        <tra:Your_Role>\(role)</tra:Your_Role>
        
        <tra:Descrption>\(txtViewDescription.text ?? "")</tra:Descrption>
        
        <tra:FileName>\(filename).jpeg</tra:FileName>
        
        <tra:File>\(base64Image)</tra:File>
        </tra:CreateTraining>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.createTrainingService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.createTrainingSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["CreateTrainingResponse"]["CreateTrainingResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["CreateTrainingResponse"]["CreateTrainingResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    // CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: self)
                    
                    OperationQueue.main.addOperation({
                        
                        let alertVC = UIAlertController(title: status, message: message, preferredStyle: .alert)
                        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                            let sideMenuController =  SideMenuController.instantiate(fromAppStoryboard: .Dashboard)
                            CommonFunctions().objAppdelegate.window?.rootViewController = sideMenuController
                            
                        }))
                        self.present(alertVC, animated: true, completion: nil)
                    })
                    
                }else {
                    
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            completion("")
            
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebserviceToEditRecord(detailTraining:DetailTraining, completion:@escaping (String)->Void){
        let categoryId = (selectedCategory != nil) ? selectedCategory?.Id ?? "" : detailTraining.categoryId
        let activityId = (selectedActivity != nil) ? selectedActivity?.Id ?? "" : detailTraining.activityId
        let subActivityId = (selectedSubActivity != nil) ? selectedSubActivity?.Id ?? "" : detailTraining.subActivityId
        
        var base64Image = ""
        if let img = selectedImage{
            if let imageData:Data = img.jpegData(compressionQuality: 0.1){
                //base64Image = String(data: imageData, encoding: .utf8)!
                base64Image = imageData.base64EncodedString()
            }
        }
        let filename = "\(txtFldFileName.text ?? "")".trimmingCharacters(in: .whitespacesAndNewlines)
        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:EditTraining>
        <tra:recordId>\(objUserTrainingTransaction.transactionId)</tra:recordId>
        <tra:User_Id>\(detailTraining.userId)</tra:User_Id>
        <tra:Date>\(txtFldOnBoardingDate.text ?? "")</tra:Date>
        <tra:State_Id>\(User.fetchCurrentUser()!.stateEnrolled ?? "")</tra:State_Id>
        <tra:Category_Id>\(categoryId)</tra:Category_Id>
        <tra:Activity_Id>\(activityId)</tra:Activity_Id>
        <tra:SubActivity_Id>\(subActivityId)</tra:SubActivity_Id>
        <tra:Hours>\(txtFldHours.text ?? "")</tra:Hours>
        <tra:Provider>\(txtProvider.text ?? "")</tra:Provider>
        <tra:Your_Role>\(role)</tra:Your_Role>
        <tra:Descrption>\(txtViewDescription.text ?? "")</tra:Descrption>
        <tra:FileName>\(filename).jpeg</tra:FileName>
        <tra:File>\(base64Image)</tra:File>
        </tra:EditTraining>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.editTrainingService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.editTrainingSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["EditTrainingResponse"]["EditTrainingResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["EditTrainingResponse"]["EditTrainingResult"]["Message"].element?.text ?? ""
                if (status == "Success")  || (status == "SUCCESS") {
                    OperationQueue.main.addOperation({
                        
                        let alertVC = UIAlertController(title: status, message: message, preferredStyle: .alert)
                        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                            let sideMenuController =  SideMenuController.instantiate(fromAppStoryboard: .Dashboard)
                            CommonFunctions().objAppdelegate.window?.rootViewController = sideMenuController
                        }))
                        self.present(alertVC, animated: true, completion: nil)
                    })
                }else {
                    OperationQueue.main.addOperation({
                        CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    })
                }
            }
            completion("")
            
            CommonFunctions.hideLoader()
        }
        task.resume()
    }
    
    
    func callWebserviceTogetSubActivity(stateId:String,activityId:String, completion:@escaping ([SubActivity])->Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:GetSubActivities>
        <tra:stateId>\(stateId)</tra:stateId>
        <tra:activityId>\(activityId)</tra:activityId>
        </tra:GetSubActivities>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.getSubActivitiesService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.getSubActivitiesSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            var arraySubActivities = [SubActivity]()
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetSubActivitiesResponse"]["GetSubActivitiesResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetSubActivitiesResponse"]["GetSubActivitiesResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    let elems = xml["soap:Envelope"]["soap:Body"]["GetSubActivitiesResponse"]["GetSubActivitiesResult"]["UserSubActivities"]["Sub_Activity_Master"].all
                    
                    for elem in elems{
                        let subActivity =  SubActivity(Id: elem.pasredString(key: "ID"), name: elem.pasredString(key: "Name"), ActivityID: elem.pasredString(key: "Activity_ID"), shortName: elem.pasredString(key: "ShortName"), stateID: elem.pasredString(key: "StateID"))
                        arraySubActivities.append(subActivity)
                    }
                    
                    print(arraySubActivities)
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Failure", message: message, viewController: self)
                }
                
            }
            completion(arraySubActivities)
            
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebserviceTogetCategories(stateId:String,completion:@escaping ([Category])->Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:GetCategories>
        <tra:stateId>\(stateId)</tra:stateId>
        </tra:GetCategories>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.getCategoriesService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.getCategoriesSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            var arrayCategories = [Category]()
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetCategoriesResponse"]["GetCategoriesResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetCategoriesResponse"]["GetCategoriesResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    let elems = xml["soap:Envelope"]["soap:Body"]["GetCategoriesResponse"]["GetCategoriesResult"]["UserCategories"]["Category_Master"].all
                    
                    for elem in elems{
                        let category =  Category(Id: elem.pasredString(key: "ID"), name: elem.pasredString(key: "Name"))
                        arrayCategories.append(category)
                    }
                    
                    print(arrayCategories)
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            
            completion(arrayCategories)
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    
    func callWebserviceTogetActivities(stateId:String,completion:@escaping ([Activity])->Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:GetActivities>
        <tra:stateId>\(stateId)</tra:stateId>
        </tra:GetActivities>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.getActivitiesService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.getActivitiesSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            var arrayActivities = [Activity]()
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetActivitiesResponse"]["GetActivitiesResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetActivitiesResponse"]["GetActivitiesResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    let elems = xml["soap:Envelope"]["soap:Body"]["GetActivitiesResponse"]["GetActivitiesResult"]["UserActivities"]["Activity_Master"].all
                    
                    for elem in elems{
                        let activity =  Activity(Id: elem.pasredString(key: "ID"), name: elem.pasredString(key: "Name"))
                        arrayActivities.append(activity)
                    }
                    
                    print(arrayActivities)
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            completion(arrayActivities)
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    
    func callWebserviceUserTrainingTransaction(transactId:String){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tra="http://www.lexnarro.com.au/services/Training.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <tra:DetailTraining>
        <tra:id>\(transactId)</tra:id>
        </tra:DetailTraining>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Training.detailTrainingService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Training.detailTrainingSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["DetailTrainingResponse"]["DetailTrainingResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["DetailTrainingResponse"]["DetailTrainingResult"]["Message"].element?.text ?? ""
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    let elem = xml["soap:Envelope"]["soap:Body"]["DetailTrainingResponse"]["DetailTrainingResult"]["UserTraining"]["UserTrainingTransaction"]
                    
                    print(elem)
                    
                    let detailIDTrain =  DetailTraining(Id: elem["Id"].element?.text ?? "", transactionId: elem["TransactionId"].element?.text ?? "", userId: elem["User_Id"].element?.text ?? "", firstName: elem["FirstName"].element?.text ?? "", date: elem["Date"].element?.text ?? "", stateId: elem["StateId"].element?.text ?? "", stateName: elem["StateName"].element?.text ?? "", categoryId: elem["CategoryId"].element?.text ?? "", categoryName: elem["CategoryName"].element?.text ?? "", activityId: elem["ActivityId"].element?.text ?? "", activityName: elem["ActivityName"].element?.text ?? "", subActivityId: elem["SubActivityId"].element?.text ?? "", subActivityName: elem["SubActivityName"].element?.text ?? "", hours: elem["Hours"].element?.text ?? "", provider: elem["Provider"].element?.text ?? "", CPDYear: elem["Financial_Year"].element?.text ?? "", descrption: elem["Descrption"].element?.text ?? "", fileName: elem["FileName"].element?.text ?? "", units: elem["Units"].element?.text ?? "", role: elem.pasredString(key: "Your_Role"), imageLink: elem.pasredString(key: "ImageLink"))
                    
                    OperationQueue.main.addOperation({
                        self.loadDataWithDetails(detailIDTrain)
                    })
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    func loadDataWithDetails(_ details:DetailTraining)  {
        detailsTraining = details
        txtFldOnBoardingDate.text = details.date
        txtSelectCategory!.text = details.categoryName
        txtFldActivity.text = details.activityName
        txtFieldSubActivity.text = details.subActivityName
        txtFldHours.text = details.hours
        txtProvider.text = details.provider
        txtViewDescription.text = details.descrption
        txtFldFileName.text = details.fileName
        viewImageFile.isHidden = details.imageLink.isEmpty
        
        pdfLink = details.imageLink
        if details.imageLink.contains(".pdf") {
            viewImageFile.isHidden = true
            pdfPreview.isHidden = false
            // self.downloadPdf(url: details.imageLink)
        }
        if txtFldFileName.text!.contains("."){
            txtFldFileName.text = String( txtFldFileName.text!.split(separator: ".").first ?? "")
        }
        
        activityIndicator.startAnimating()
        //.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        if let imgStr = details.imageLink.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed){
            imgViewFile.downloaded(from: imgStr, contentMode: .scaleAspectFill) { (status) in
                OperationQueue.main.addOperation({
                    self.activityIndicator.stopAnimating()
                    if !status {
                        self.viewImageFile.isHidden = true
                    }
                })
            }
        }else{
            self.activityIndicator.stopAnimating()
        }
        selectRoleWithRole(role: details.role)
    }
    
    
    @IBAction func btnBackAction(_ sender: Any) {
        if objNavigationType == .PRESENT {
            self.dismiss(animated: true, completion: nil)
        }else{
            self.navigationController?.popViewController(animated: true)
        }
    }
    @IBAction func btnAttendeeAction(_ sender: Any) {
        DispatchQueue.main.async {
            self.selectRoleWithRole(role: "attendee")
        }
    }
    
    @IBAction func btnPresenterAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            self.selectRoleWithRole(role: "presentor")
        }
    }
    
    @IBAction func btnAuthorAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            self.selectRoleWithRole(role: "author")
        }
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    func selectRoleWithRole(role:String)   {
        self.role = role
        
        if role == "attendee" || role == "Attendee" || role == "ATTENDEE" {
            imgViewAuthor.image = UIImage(named: "uncheckRadio")
            imgViewPresentor.image = UIImage(named: "uncheckRadio")
            lblAuthor.textColor = LexColor.whiteColor
            lblPresenter.textColor = LexColor.whiteColor
            UIView.transition(with: imgViewAttendee, duration: 1.5, options: .transitionCurlDown, animations: {
                self.imgViewAttendee.image = UIImage(named: "checkRadio")
            }, completion: nil)
            
            UIView.transition(with: lblAttendee, duration: 1.5, options: .transitionCurlDown, animations: {
                self.lblAttendee.textColor = LexColor.redColor
            }, completion: nil)
            
        }else if role == "presentor" || role == "Presentor" || role == "PRESENTOR"{
            imgViewAuthor.image = UIImage(named: "uncheckRadio")
            imgViewAttendee.image = UIImage(named: "uncheckRadio")
            imgViewPresentor.image = UIImage(named: "checkRadio")
            lblAttendee.textColor = LexColor.whiteColor
            lblAuthor.textColor = LexColor.whiteColor
            UIView.transition(with: imgViewPresentor, duration: 1.5, options: .transitionCurlDown, animations: {
                self.imgViewPresentor.image = UIImage(named: "checkRadio")
            }, completion: nil)
            UIView.transition(with: lblPresenter, duration: 1.5, options: .transitionCurlDown, animations: {
                self.lblPresenter.textColor = LexColor.redColor
            }, completion: nil)
            
        }else if role == "author" || role == "Author" || role == "AUTHOR"{
            imgViewAttendee.image = UIImage(named: "uncheckRadio")
            imgViewPresentor.image = UIImage(named: "uncheckRadio")
            imgViewAuthor.image = UIImage(named: "checkRadio")
            lblAttendee.textColor = LexColor.whiteColor
            lblPresenter.textColor = LexColor.whiteColor
            
            UIView.transition(with: imgViewAuthor, duration: 1.5, options: .transitionCurlDown, animations: {
                self.imgViewAuthor.image = UIImage(named: "checkRadio")
                
            }, completion: nil)
            UIView.transition(with: lblAuthor, duration: 1.5, options: .transitionCurlDown, animations: {
                self.lblAuthor.textColor = LexColor.redColor
            }, completion: nil)
            
            
        }else{
            imgViewAttendee.image = UIImage(named: "uncheckRadio")
            imgViewPresentor.image = UIImage(named: "uncheckRadio")
            imgViewAuthor.image = UIImage(named: "uncheckRadio")
            lblAttendee.textColor = LexColor.whiteColor
            lblAuthor.textColor = LexColor.whiteColor
            lblPresenter.textColor = LexColor.whiteColor
        }
    }
    
    
    @IBAction func btnUploadAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            let alertController = UIAlertController(title: nil, message: "Select option to pick file", preferredStyle: .actionSheet)
            alertController.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action) in
                //self.constraintViewHeight.constant = 750
                DispatchQueue.main.async {
                    
                    self.view.layoutIfNeeded()
                    self.imagePicker.cameraAsscessRequest()
                }
            }))
            alertController.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { (action) in
                //self.constraintViewHeight.constant = 750
                DispatchQueue.main.async {
                    
                    self.view.layoutIfNeeded()
                    self.imagePicker.photoGalleryAsscessRequest()
                }
            }))
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
                
            }))
            
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    @IBAction func btnCreateAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            if !self.isValidateSelectedDate(){
                self.txtFldOnBoardingDate.shakeTextField(errorMessage: "Please select date") { (status) in
                }
                
            }else if !self.isValidateCategory(){
                self.txtSelectCategory!.shakeTextField(errorMessage: "Please select category") { (status) in
                }
                
            }else if !self.isValidateActivity(){
                self.txtFldActivity.shakeTextField(errorMessage: "Please select activity") { (status) in
                }
                
            }else if !self.isValidateHours(){
                self.txtFldHours.shakeTextField(errorMessage: "Please enter hours") { (status) in
                }
                
            }else if !self.isValidateProvider(){
                self.txtProvider.shakeTextField(errorMessage: "Please enter provider name") { (status) in
                    
                }
                
            }else if !self.isValidateRole(){
                CommonFunctions.showAlertMessage(title: "Role", message: "Please select role", viewController: self)
            }
            else if !self.isValidateFileName(){
                self.txtFldFileName.shakeTextField(errorMessage: "File name can not be empty") { (status) in
                    if self.imgViewFile.image == nil{
                    CommonFunctions.showAlertMessage(title: "Upload document", message: "Please upload image or remove title", viewController: self)
                    } else{
                        if self.objNavigationType == .EDIT {
                            self.callWebserviceToEditRecord(detailTraining: self.detailsTraining) { (message) in
                            }}else{
                            self.callWebserviceToCreateRecord(user: User.fetchCurrentUser()!) { (message) in
                            }}
                    }

                }
            }
//            }else if !self.isValidateImage(){
//                CommonFunctions.showAlertMessage(title: "Upload document", message: "Please upload image or remove title", viewController: self)
//
//            }
            else{
                if self.imgViewFile.image != nil{
                    let user = User.fetchCurrentUser()!
                    
                    self.txtFldFileName.text = "NONAME\(user.userId ?? "")"
                }
                if self.objNavigationType == .EDIT {
                    self.callWebserviceToEditRecord(detailTraining: self.detailsTraining) { (message) in
                    }}else{
                    self.callWebserviceToCreateRecord(user: User.fetchCurrentUser()!) { (message) in
                    }}
            }
        }
        
    }
    @IBAction func btnSelectCategoryAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            let stateID =  User.fetchCurrentUser()!.stateEnrolled ?? ""
            
            self.callWebserviceTogetCategories(stateId: stateID) { (arrayCategories) in
                if arrayCategories.count > 0{
                    let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
                    
                    pickerPopupVC.showPickerForData(data: arrayCategories) { (selectedData,selectedIndex) in
                        self.selectedCategory = selectedData as? Category
                        self.txtSelectCategory?.text = (selectedData as? Category)?.name
                    }
                    // pickerPopupVC.delegate = self
                    self.present(pickerPopupVC, animated: true, completion: nil)
                }
                
            }
        }
        
    }
    @IBAction func btnSelectActivityAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            let stateID =  User.fetchCurrentUser()!.stateEnrolled ?? ""
            
            self.callWebserviceTogetActivities(stateId: stateID) { (arrayActivities) in
                if arrayActivities.count > 0{
                    
                    let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
                    
                    pickerPopupVC.showPickerForData(data: arrayActivities) { (selectedData,selectedIndex) in
                        self.selectedActivity = selectedData as? Activity
                        self.txtFldActivity?.text = (selectedData as? Activity)?.name
                    }
                    // pickerPopupVC.delegate = self
                    self.present(pickerPopupVC, animated: true, completion: nil)
                }
                
            }}
        
        
    }
    
    
    @IBAction func btnSelectSubActivityAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            if let activity = self.selectedActivity {
                let stateID = self.objNavigationType == .EDIT ? self.objUserTrainingTransaction.stateId : (User.fetchCurrentUser()!.stateID ?? "")
                
                self.callWebserviceTogetSubActivity(stateId: stateID, activityId: activity.Id ) { (arraySubActivity) in
                    if arraySubActivity.count > 0{
                        let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
                        
                        pickerPopupVC.showPickerForData(data: arraySubActivity) { (selectedData,selectedIndex) in
                            self.selectedSubActivity = selectedData as? SubActivity
                            self.txtFieldSubActivity?.text = (selectedData as? SubActivity)?.name
                        }
                        // pickerPopupVC.delegate = self
                        self.present(pickerPopupVC, animated: true, completion: nil)
                    }
                }
            }else{
                
                CommonFunctions.showAlertMessage(title: "Alert", message: "Please select activity first", viewController: self)
                
            }
        }
    }
    
   
    
    @IBAction func btnSelectDateAction(_ sender: Any) {
        DispatchQueue.main.async {
            
            let datePickerVC = DatePickerVC.instantiate(fromAppStoryboard: .Popup)
            datePickerVC.getDate { (selectedDate) in
                self.txtFldOnBoardingDate.text = selectedDate
            }
            self.present(datePickerVC, animated: true, completion: nil)
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension CreateNewRecordVC: UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // The list of array to display. Can be changed dynamically
        
        
    }
}

extension CreateNewRecordVC: ImagePickerDelegate {
    
    func imagePickerDelegate(didSelect image: UIImage, delegatedForm: ImagePicker) {
        pdfPreview.isHidden = true
        if txtFldFileName.text!.contains("."){
            txtFldFileName.text = String( txtFldFileName.text!.split(separator: ".").first ?? "")
        }
        selectedImage = image
        activityIndicator.stopAnimating()
        
        UIView.transition(with: viewImageFile, duration: 1.5, options: .curveEaseIn, animations: {
            self.viewImageFile.isHidden = false
            self.imgViewFile.image = self.selectedImage
        }, completion: nil)
        imagePicker.dismiss()
    }
    
    func imagePickerDelegate(didCancel delegatedForm: ImagePicker) { imagePicker.dismiss() }
    
    func imagePickerDelegate(canUseGallery accessIsAllowed: Bool, delegatedForm: ImagePicker) {
        if accessIsAllowed { presentImagePicker(sourceType: .photoLibrary) }
    }
    
    func imagePickerDelegate(canUseCamera accessIsAllowed: Bool, delegatedForm: ImagePicker) {
        // works only on real device (crash on simulator)
        if accessIsAllowed { presentImagePicker(sourceType: .camera) }
    }
}




