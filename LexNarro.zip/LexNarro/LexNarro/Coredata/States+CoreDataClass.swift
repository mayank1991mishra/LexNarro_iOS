//
//  States+CoreDataClass.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData

@objc(States)
public class States: NSManagedObject {

    static  let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext

    class  func insertSate(userdata:[String:String]) {
        
        /*
         An NSEntityDescription object is associated with a specific class instance
         Class
         NSEntityDescription
         A description of an entity in Core Data.
         
         Retrieving an Entity with a Given Name here person
         */
        let entityDesc = NSEntityDescription.entity(forEntityName: "States",
                                                    in: managedContext)!
        let objState = NSManagedObject(entity: entityDesc, insertInto: managedContext) as! States
        
        objState.stateId = parseDictionary(userdata: userdata, key: "Id")
        objState.name = parseDictionary(userdata: userdata, key: "Name")
        objState.shortName = parseDictionary(userdata: userdata, key: "ShortName")
        CoreDataManager.sharedManager.saveContext()
        
    }
    
    
    class func fetchAllStates() -> [States] {
        
        var allStates = [States]()
        
        do {
            if let states = try managedContext.fetch(States.fetchRequest()) as? [States]{
                allStates = states
            }
            return allStates
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return allStates
        }
    }
    
    class func deleteAllStates()  {
        do {
            guard let states = try managedContext.fetch(States.fetchRequest()) as? [States] else {return}
            for state in states {
                managedContext.delete(state)
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        CoreDataManager.sharedManager.saveContext()
    }
    
    class func parseDictionary(userdata:[String:Any],key:String)-> String{
     
        if let parsedString = userdata[key] as? String {
            return parsedString
        }else if let parsedNumber = userdata[key] as? NSNumber{
            return "\(parsedNumber)"
        }else if let parsedBool = userdata[key] as? Bool{
            return "\(parsedBool)"
        }else{
            return ""
        }
    }
}
