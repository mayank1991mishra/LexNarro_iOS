//
//  EnrolledStates+CoreDataClass.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData

@objc(EnrolledStates)
public class EnrolledStates: NSManagedObject {
    static  let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext
    
    class  func insertSate(userdata:[String:String]) {
        
        /*
         An NSEntityDescription object is associated with a specific class instance
         Class
         NSEntityDescription
         A description of an entity in Core Data.
         
         Retrieving an Entity with a Given Name here person
         */
        let entityDesc = NSEntityDescription.entity(forEntityName: "EnrolledStates",
                                                    in: managedContext)!
        let objState = NSManagedObject(entity: entityDesc, insertInto: managedContext) as! EnrolledStates
        
        objState.stateID = parseDictionary(userdata: userdata, key: "Id")
        objState.name = parseDictionary(userdata: userdata, key: "Name")
        objState.shortname = parseDictionary(userdata: userdata, key: "ShortName")
        CoreDataManager.sharedManager.saveContext()
        
    }
    
    
    class func fetchAllStates() -> [EnrolledStates] {
        var allStates = [EnrolledStates]()
        
        do {
            if let enrolledStates = try managedContext.fetch(EnrolledStates.fetchRequest()) as? [EnrolledStates]{
                allStates = enrolledStates
            }
            return allStates
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return allStates
        }
    }
    
    class func deleteAllStates()  {
        do {
            guard let enrolledStates = try managedContext.fetch(EnrolledStates.fetchRequest()) as? [EnrolledStates] else {return}
            for enrolledState in enrolledStates {
                managedContext.delete(enrolledState)
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        CoreDataManager.sharedManager.saveContext()
    }
    
    class func parseDictionary(userdata:[String:Any],key:String)-> String{
        if let parsedString = userdata[key] as? String {
            return parsedString
        }else if let parsedNumber = userdata[key] as? NSNumber{
            return "\(parsedNumber)"
        }else if let parsedBool = userdata[key] as? Bool{
            return "\(parsedBool)"
        }else{
            return ""
        }
    }

}
