//
//  User+CoreDataProperties.swift
//  LexNarro
//
//  Created by Anand Awasthi on 29/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var userId: String?
    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var otherName: String?
    @NSManaged public var streetNumber: String?
    @NSManaged public var streetName: String?
    @NSManaged public var postCode: String?
    @NSManaged public var suburb: String?
    @NSManaged public var stateID: String?
    @NSManaged public var stateName: String?
    @NSManaged public var countryID: String?
    @NSManaged public var countryName: String?
    @NSManaged public var stateEnrolled: String?
    @NSManaged public var stateEnrolledName: String?
    @NSManaged public var stateEnrolledShortName: String?
    @NSManaged public var lawSocietyNumber: String?
    @NSManaged public var emailAddress: String?
    @NSManaged public var phoneNumber: String?
    @NSManaged public var password: String?
    @NSManaged public var date: String?
    @NSManaged public var device_Imei: String?
    @NSManaged public var device_Token: String?
    @NSManaged public var device_Type: String?
    @NSManaged public var accountConfirmed: String?
    @NSManaged public var activationCode: String?
    @NSManaged public var firm: String?
    @NSManaged public var token: String?

}
