//
//  States+CoreDataProperties.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData


extension States {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<States> {
        return NSFetchRequest<States>(entityName: "States")
    }

    @NSManaged public var stateId: String?
    @NSManaged public var name: String?
    @NSManaged public var shortName: String?

}
