//
//  User+CoreDataClass.swift
//  LexNarro
//
//  Created by Anand Awasthi on 29/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {
    
    static  let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext
    
    class  func insertUser(userdata:UserProfileStruct,userToken:String) {
        
        /*
         An NSEntityDescription object is associated with a specific class instance
         Class
         NSEntityDescription
         A description of an entity in Core Data.
         
         Retrieving an Entity with a Given Name here person
         */
        let entityDesc = NSEntityDescription.entity(forEntityName: "User",
                                                    in: managedContext)!
        let objUser = NSManagedObject(entity: entityDesc, insertInto: managedContext) as! User
        
        objUser.userId = userdata.userId
        objUser.firstName = userdata.firstName
        objUser.lastName = userdata.lastName
        objUser.otherName = userdata.otherName
        objUser.streetNumber = userdata.streetNumber
        objUser.streetName = userdata.streetName
        objUser.suburb = userdata.suburb
        objUser.stateID = userdata.stateID
        objUser.stateName = userdata.stateName
        objUser.countryID = userdata.countryID
        objUser.countryName = userdata.countryName
        objUser.stateEnrolled = userdata.stateEnrolledId
        objUser.stateEnrolledName = userdata.stateEnrolledName
        objUser.stateEnrolledShortName = userdata.stateEnrolledShortName
        objUser.lawSocietyNumber = userdata.lawSocietyNumber
        objUser.emailAddress = userdata.emailAddress
        objUser.phoneNumber = userdata.phoneNumber
        objUser.password = userdata.password
        objUser.date = userdata.date
        objUser.postCode = userdata.postCode
        objUser.device_Imei = userdata.device_Imei
        objUser.device_Token = userdata.device_Token
        objUser.device_Type = userdata.device_Type
        objUser.accountConfirmed = userdata.accountConfirmed
        objUser.activationCode = userdata.activationCode
        objUser.firm = userdata.firm
        objUser.token = userToken
        
        CoreDataManager.sharedManager.saveContext()
        
    }
    
    class func parseDictionary(userdata:[String:Any],key:String)-> String{
        if let parsedString = userdata[key] as? String {
            return parsedString
        }else if let parsedNumber = userdata[key] as? NSNumber{
            return "\(parsedNumber)"
        }else if let parsedBool = userdata[key] as? Bool{
            return "\(parsedBool)"
        }else{
            return ""
        }
    }
    
   class func fetchCurrentUser() -> User? {
        do {
            let user = try managedContext.fetch(User.fetchRequest()) as? [User]
            return user?.last
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
    class func deleteUser()  {
        do {
            guard let users = try managedContext.fetch(User.fetchRequest()) as? [User] else {return}
            for user in users {
                managedContext.delete(user)
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        CoreDataManager.sharedManager.saveContext()
    }
}
