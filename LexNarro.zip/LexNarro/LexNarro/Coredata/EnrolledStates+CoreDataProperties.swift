//
//  EnrolledStates+CoreDataProperties.swift
//  LexNarro
//
//  Created by Anand Awasthi on 01/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//
//

import Foundation
import CoreData


extension EnrolledStates {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<EnrolledStates> {
        return NSFetchRequest<EnrolledStates>(entityName: "EnrolledStates")
    }

    @NSManaged public var stateID: String?
    @NSManaged public var name: String?
    @NSManaged public var shortname: String?

}
