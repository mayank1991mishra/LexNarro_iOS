//
//  WebBasedVC.swift
//  LexNarro
//
//  Created by Anand Avasthy on 04/10/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import WebKit

class WebBasedVC: UIViewController, WKUIDelegate {
     var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       
    }
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        CommonFunctions.showLoader("")
        
        self.title = (objTermsAndPolicy == .TERMS) ? "Terms and Conditions" : "Privacy Policy"
        
        
        let url = (objTermsAndPolicy == .TERMS) ? "https://www.lexnarro.com.au/Account/TermAndCondition" : "https://www.lexnarro.com.au/Account/privacyPolicy"
        webView.navigationDelegate = self
        if let url = URL(string: url) {
            let request = URLRequest(url: url)
            webView.load(request)
        }else{
            CommonFunctions.hideLoader()
        }
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension WebBasedVC: WKNavigationDelegate{
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        //CommonFunctions.hideLoader()

        CommonFunctions.showLoader("")
        
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        CommonFunctions.hideLoader()
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        CommonFunctions.hideLoader()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        CommonFunctions.hideLoader()
    }
}
