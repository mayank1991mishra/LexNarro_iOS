//
//  SignupVCViewModel.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation
import QuartzCore
import SWXMLHash

struct SignupState {
    var Id:String
    var shortName:String
    var name: String
}

class SignupVCViewModel: SignupVCProtocol {
    
    var getAllStatesArray = [[String:String]]()
    
    var getAllEnrolledStatesArray = [[String:String]]()
    
    
    func validateFirstname(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldFirstName.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateLastName(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldLastName.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateEmailAddress(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtEmailAddress.text!.isEmpty{
            isValidate = false
        }else if !target.txtEmailAddress.text!.isValidEmail(){
            isValidate = false
        }
        else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateMobileNo(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldMobileNumber.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateStreetNo(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldStreetNumber.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateStreetName(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldStreetName.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validatePostCode(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldPostCode.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateState(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldSelectState.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateEnrolledState(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldStateEnrolled.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateCountry(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldCountry.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validateLawSocietyNo(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldLawSocietyNumber.text!.isEmpty{
            isValidate = false
        }else if target.txtFldLawSocietyNumber.text!.count < 5{
            isValidate = false
        }
        else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validatePassword(target: SignupVC) -> Bool {
        var isValidate = false
        
        if target.txtFldPassword.text!.isEmpty{
            isValidate = false
        }else if target.txtFldPassword.text!.count < 4{
            target.txtFldPassword.text = ""
            isValidate = false
        }
        else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func doSignup(target: SignupVC, isEdit:Bool,completion: @escaping(String) -> Void ){
        
        if !validateFirstname(target: target) {
            target.txtFldFirstName.shakeTextField(errorMessage: "First name") { (status) in
                target.btnSignup.isEnabled = true
            }
            
            addAnimationOnSignupButton(target: target)
        }else if !validateEmailAddress(target: target){
            target.txtEmailAddress.shakeTextField(errorMessage: "Email address is not valid") { (status) in
                target.txtEmailAddress.text = ""
                target.txtEmailAddress.shakeTextField(errorMessage: "Email address is not valid") { (status) in
                    target.btnSignup.isEnabled = true
                }
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }
        else if !validateMobileNo(target: target){
            target.txtFldMobileNumber.shakeTextField(errorMessage: "Mobile number can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateStreetNo(target: target){
            target.txtFldStreetNumber.shakeTextField(errorMessage: "Street number can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateStreetName(target: target){
            target.txtFldStreetName.shakeTextField(errorMessage: "Street name can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validatePostCode(target: target){
            target.txtFldPostCode.shakeTextField(errorMessage: "Postal code should be valid") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateState(target: target){
            target.txtFldSelectState.shakeTextField(errorMessage: "State can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateCountry(target: target){
            target.txtFldCountry.shakeTextField(errorMessage: "Country can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateEnrolledState(target: target){
            target.txtFldStateEnrolled.shakeTextField(errorMessage: "Enrolled state can not be empty!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validateLawSocietyNo(target: target){
            target.txtFldLawSocietyNumber.shakeTextField(errorMessage: "LawSociety number is not valid!") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if !validatePassword(target: target){
            target.txtFldPassword.shakeTextField(errorMessage: "Password can not be less than 6.") { (status) in
                target.btnSignup.isEnabled = true
            }
            addAnimationOnSignupButton(target: target)
        }else if isEdit{
            
          
            callWebServiceToUpdate(target: target) { (message) in
                print(message)
                completion(message)
            }
        }
        else {
            if !target.btnTermsAndPolicy.isSelected{
                CommonFunctions.showAlertMessage(title: "Alert", message: "Please select terms and conditions & Privacy Policy.", viewController: target)
                addAnimationOnSignupButton(target: target)

            }else{
            callWebServiceToRegister(target: target) { (message) in
                print(message)
                completion(message)
                }
            }
        }
    }
    
    func callWebServiceToRegister(target:SignupVC,completion:@escaping (String) -> Void){
        let deviceToken = UserDefaults.standard.object(forKey: Constants.kDeviceToken) as! String
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:reg="http://www.lexnarro.com.au/services/Registration.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <reg:UserRegistration>
        <!--Optional:-->
        <reg:FirstName>\(target.txtFldFirstName.text!)</reg:FirstName>
        <!--Optional:-->
        <reg:LastName>\(target.txtFldLastName.text!)</reg:LastName>
        <!--Optional:-->
        <reg:OtherName></reg:OtherName>
        <!--Optional:-->
        <reg:StreetNumber>\(target.txtFldStreetNumber.text!)</reg:StreetNumber>
        <!--Optional:-->
        <reg:StreetName>\(target.txtFldStreetNumber.text!)</reg:StreetName>
        <!--Optional:-->
        <reg:PostCode>\(target.txtFldPostCode.text!)</reg:PostCode>
        <!--Optional:-->
        <reg:Suburb>\(target.txtFldSubpurb.text!)</reg:Suburb>
        <!--Optional:-->
        <reg:stateName>\(target.txtFldSelectState.text!)</reg:stateName>
        <!--Optional:-->
        <reg:countryName>\(target.txtFldCountry.text ?? "Australia")</reg:countryName>
        <!--Optional:-->
        <reg:StateEnrolledName>\(target.txtFldStateEnrolled.text!)</reg:StateEnrolledName>
        <!--Optional:-->
        <reg:Firm>\(target.txtFldLawFirm.text ?? "")</reg:Firm>
        <!--Optional:-->
        <reg:LawSocietyNumber>\(target.txtFldLawSocietyNumber.text!)</reg:LawSocietyNumber>
        <!--Optional:-->
        <reg:EmailAddress>\(target.txtEmailAddress.text!)</reg:EmailAddress>
        <!--Optional:-->
        <reg:PhoneNumber>\(target.txtFldMobileNumber.text!)</reg:PhoneNumber>
        <!--Optional:-->
        <reg:Password>\(target.txtFldPassword.text!)</reg:Password>
        <!--Optional:-->
        <reg:Address></reg:Address>
        <!--Optional:-->
        <reg:Device_Imei>\(deviceToken)</reg:Device_Imei>
        <!--Optional:-->
        <reg:Device_Token>?\(deviceToken)</reg:Device_Token>
        <!--Optional:-->
        <reg:Device_Type>iOS</reg:Device_Type>
        </reg:UserRegistration>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        guard let url = URL(string: LexString.WebService.Registration.service) else{return}
        CommonFunctions.showLoader()
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Registration.soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                
                let message = xml["soap:Envelope"]["soap:Body"]["UserRegistrationResponse"]["UserRegistrationResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["UserRegistrationResponse"]["UserRegistrationResult"]["Status"].element?.text ?? ""
                if status == "Success" || status == "SUCCESS"{
                    
                    OperationQueue.main.addOperation({
                        let alertController = UIAlertController(title: "Registration Successful", message: message, preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                            target.dismiss(animated: true, completion: nil)
                        }))
                        target.present(alertController, animated: true, completion: nil)
                    })
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: target)
                    completion("Success")

                    
                }else{
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: target)
                    completion("Error")

                }
                
            }
            CommonFunctions.hideLoader()
        }
        
        task.resume()
        
        
    }
    func addAnimationOnSignupButton(target: SignupVC) {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 3
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: target.btnSignup.center.x - 10, y: target.btnSignup.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: target.btnSignup.center.x + 10, y: target.btnSignup.center.y))
        target.btnSignup.layer.add(animation, forKey: "position")
    }
    
    
    func getAllStates(target: SignupVC,countryId:String,completion:@escaping ([SignupState])-> Void){
        CommonFunctions.showLoader()
        
        let soapMessage = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:stat=\"http://www.lexnarro.com.au/services/States.asmx\">" +
        "<soapenv:Header/>" +
        "<soapenv:Body>" +
        "<stat:GetAllStates>" +
        "<stat:countryId>9</stat:countryId>" +
        "</stat:GetAllStates>" +
        "</soapenv:Body>" +
        "</soapenv:Envelope>"
      
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        
        self.callWebServiceGetAllStatesSoapMessage(serviceUrl: LexString.WebService.StateNames.getAllStatesService, soapAction: LexString.WebService.StateNames.getAllStatesSoapAction, soapMessage: soapMessage) { (status, response, message) in
            var arrayState = [SignupState]()
            
            if status{
                print(response ?? "")
                guard let res = response!["GetAllStatesResult"] as? [String:Any] else{return}
                guard let allStates = res["States"] as? [Dictionary<String,String>] else{return}
                print(allStates)
                
                for state in allStates{
                    let sate = SignupState(Id: state["Id"] ?? "", shortName: state["ShortName"] ?? "", name: state["Name"] ?? "")
                    arrayState.append(sate)
                }
                CommonFunctions.hideLoader()
            }
            
            
            completion(arrayState)
        }
        
        
    }
    
    
    
    func getAllEnrolledStates(target: SignupVC,userID:String,completion:@escaping ([EnrolledStates])-> Void){
        //  CommonFunctions.showLoader()
       
        let soapMessage = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tra=\"http://www.lexnarro.com.au/services/Training.asmx\">\n" +
            "<soapenv:Header/>\n" +
            "<soapenv:Body>\n" +
            "<tra:GetUserEnrolledState>\n" +
            "<tra:User_ID>\(userID)</tra:User_ID>\n" +
            "</tra:GetUserEnrolledState>\n" +
            "</soapenv:Body>\n" +
        "</soapenv:Envelope>"
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        
        self.callWebServiceGetAllEnrolledStatesSoapMessage(serviceUrl: LexString.WebService.StateNames.getAllStatesService, soapAction: LexString.WebService.StateNames.getAllStatesSoapAction, soapMessage: soapMessage) { (status, response, message) in
            
            if status{
                print(response ?? "")
                guard let res = response!["GetUserEnrolledStateResult"] as? [String:Any] else{  CommonFunctions.hideLoader(); return}
                guard let allStates = res["States"] as? [[String: String]] else{  CommonFunctions.hideLoader(); return}
                print(allStates)
                EnrolledStates.deleteAllStates()
                for state in allStates{
                    EnrolledStates.insertSate(userdata: state)
                }
                self.getAllEnrolledStatesArray  = allStates
            }
            completion(EnrolledStates.fetchAllStates())
            CommonFunctions.hideLoader()
        }
        
        
    }
    
    
    func callWebServiceGetAllStatesSoapMessage(serviceUrl:String,soapAction:String, soapMessage:String, complitionHandler:@escaping (Bool,[String:Any]?,String?) -> Void){
        guard let url = URL(string: serviceUrl) else{return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                complitionHandler(false,nil,error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                print(xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["States"])
                var dictGetAllStatesResult = [String:Any]()
                
                var stateMasterArray = [[String:String]]()
                
                
                for elem in xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["States"]["StateMaster"].all {
                    let dictMaster = ["Id":elem["Id"].element?.text ?? "",
                                      "Name":elem["Name"].element?.text ?? "",
                                      "ShortName":elem["ShortName"].element?.text ?? ""]
                    
                    print(elem["Id"].element?.text ?? "")
                    print(elem["Name"].element?.text ?? "")
                    print(elem["ShortName"].element?.text ?? "")
                    stateMasterArray.append(dictMaster)
                }
                
                print(stateMasterArray)
                
                let message = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Status"].element?.text ?? ""
                
                let requestKey = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Requestkey"].element?.text ?? ""
                
                
                let finalDict = ["Status": status,
                                 "Message": message,
                                 "RequestKey": requestKey,
                                 "States": stateMasterArray] as [String : Any]
                
                dictGetAllStatesResult = ["GetAllStatesResult":finalDict]
                
                complitionHandler(true,dictGetAllStatesResult,"Response Received")
            }
        }
        
        task.resume()
        
    }
    
    
    func callWebServiceGetAllEnrolledStatesSoapMessage(serviceUrl:String,soapAction:String, soapMessage:String, complitionHandler:@escaping (Bool,[String:Any]?,String?) -> Void){
        guard let url = URL(string: serviceUrl) else{return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                complitionHandler(false,nil,error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                print(xml["soap:Envelope"]["soap:Body"]["GetUserEnrolledStateResponse"]["GetUserEnrolledStateResult"]["States"])
                var dictGetAllStatesResult = [String:Any]()
                
                var stateMasterArray = [[String:String]]()
                
                
                for elem in xml["soap:Envelope"]["soap:Body"]["GetUserEnrolledStateResponse"]["GetUserEnrolledStateResult"]["States"]["StateMaster"].all {
                    let dictMaster = ["Id":elem["Id"].element?.text ?? "",
                                      "Name":elem["Name"].element?.text ?? "",
                                      "ShortName":elem["ShortName"].element?.text ?? ""]
                    
                    print(elem["Id"].element?.text ?? "")
                    print(elem["Name"].element?.text ?? "")
                    print(elem["ShortName"].element?.text ?? "")
                    stateMasterArray.append(dictMaster)
                }
                
                print(stateMasterArray)
                
                let message = xml["soap:Envelope"]["soap:Body"]["GetUserEnrolledStateResponse"]["GetUserEnrolledStateResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["GetUserEnrolledStateResponse"]["GetUserEnrolledStateResult"]["Status"].element?.text ?? ""
                
                let requestKey = xml["soap:Envelope"]["soap:Body"]["GetUserEnrolledStateResponse"]["GetUserEnrolledStateResult"]["Requestkey"].element?.text ?? ""
                
                
                let finalDict = ["Status": status,
                                 "Message": message,
                                 "RequestKey": requestKey,
                                 "States": stateMasterArray] as [String : Any]
                
                dictGetAllStatesResult = ["GetUserEnrolledStateResult":finalDict]
                
                complitionHandler(true,dictGetAllStatesResult,"Response Received")
            }
        }
        
        task.resume()
        
    }
    
    
    
    
    
    func callWebServiceToRegisterTheUser(serviceUrl:String,soapAction:String, soapMessage:String, complitionHandler:@escaping (Bool,[String:Any]?,String?) -> Void){
        guard let url = URL(string: serviceUrl) else{return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                complitionHandler(false,nil,error.debugDescription)
            }
            else if data != nil{
                
                complitionHandler(true,nil,"Response Received")
            }
        }
        
        task.resume()
        
    }
    
    func userIntractionEnableAndDisable(status:Bool,target:SignupVC) {
        target.txtFldFirstName.isUserInteractionEnabled = status
        target.txtFldLastName.isUserInteractionEnabled = status
        target.txtEmailAddress.isUserInteractionEnabled = status
        target.txtFldStreetNumber.isUserInteractionEnabled = status
        target.txtFldStreetName.isUserInteractionEnabled = status
        target.txtFldSelectState.isUserInteractionEnabled = status
        target.txtFldStateEnrolled.isUserInteractionEnabled = status
        target.txtFldPassword.isUserInteractionEnabled = status
        target.txtFldMobileNumber.isUserInteractionEnabled = status
        target.txtFldPostCode.isUserInteractionEnabled = status
        target.txtFldLawSocietyNumber.isUserInteractionEnabled = status
        target.txtFldSubpurb.isUserInteractionEnabled = status

        target.btnSignup.isHidden = !status
        target.btnHideAndShowPassword.isHidden = !status
    }
    
    func setEditableFieldsToViewController(target:SignupVC){
        let disabledColor = UIColor(red: 97/255, green: 97/255, blue: 97/255, alpha: 1.0)
        let enabledColor = UIColor(red: 180/255, green: 0/255, blue: 0/255, alpha: 1.0)
        
        target.txtFldFirstName.backgroundColor = disabledColor
        target.txtFldLastName.backgroundColor = disabledColor
        target.txtEmailAddress.backgroundColor = disabledColor
        target.txtFldCountry.backgroundColor = disabledColor
        target.txtFldStateEnrolled.backgroundColor = disabledColor


        target.txtFldMobileNumber.backgroundColor = enabledColor
        target.txtFldStreetNumber.backgroundColor = enabledColor
        target.txtFldStreetName.backgroundColor = enabledColor
        target.txtFldSelectState.backgroundColor = enabledColor

        target.txtFldLawSocietyNumber.backgroundColor = enabledColor
        target.txtFldPassword.backgroundColor = enabledColor
        target.txtFldPostCode.backgroundColor = enabledColor
        target.txtFldSubpurb.backgroundColor = enabledColor
        target.txtFldLawFirm.backgroundColor = enabledColor

        target.viewPassword.backgroundColor = enabledColor
        target.txtFldMobileNumber.isUserInteractionEnabled = true
        target.txtFldStreetNumber.isUserInteractionEnabled = true
        target.txtFldStreetName.isUserInteractionEnabled = true
        target.txtFldSelectState.isUserInteractionEnabled = true
        target.txtFldLawSocietyNumber.isUserInteractionEnabled = true
        target.txtFldPassword.isUserInteractionEnabled = true
        target.txtFldPostCode.isUserInteractionEnabled = true
        target.txtFldSubpurb.isUserInteractionEnabled = true
        target.txtFldLawFirm.isUserInteractionEnabled = true
        target.txtFldPassword.placeholder = "****"
        target.btnHideAndShowPassword.isHidden = false

    }
    
    
    func updateUsersOfflineRecord(target:SignupVC,selectedState:SignupState){
        guard let user = User.fetchCurrentUser() else{return}
        user.setValue(target.txtFldMobileNumber.text!, forKey: "phoneNumber")
        user.setValue(target.txtFldStreetNumber.text!, forKey: "streetNumber")
        user.setValue(target.txtFldStreetName.text!, forKey: "streetName")
        user.setValue(target.txtFldSubpurb.text!, forKey: "suburb")
        user.setValue(target.txtFldPostCode.text!, forKey: "postCode")
        user.setValue(selectedState.name, forKey: "stateName")
        user.setValue(selectedState.Id, forKey: "stateID")
        user.setValue(target.txtFldPassword.text!, forKey: "password")
        user.setValue(target.txtFldLawFirm.text ?? "", forKey: "firm")
        user.setValue(target.txtFldLawSocietyNumber.text!, forKey: "lawSocietyNumber")
        CoreDataManager.sharedManager.saveContext()
    }
    
    
    func callWebServiceToUpdate(target:SignupVC,completion:@escaping (String) -> Void){
        
        let stateId:String = (target.selectedState != nil) ? (target.selectedState?.Id)! : User.fetchCurrentUser()!.stateID ?? ""
        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:upd="http://www.lexnarro.com.au/services/UpdateProfile.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <upd:UpdateUserProfile>
         <!--Optional:-->
         <upd:id>\(User.fetchCurrentUser()!.userId ?? "")</upd:id>
         <!--Optional:-->
         <upd:firstName>\(target.txtFldFirstName.text!)</upd:firstName>
         <!--Optional:-->
         <upd:lastName>\(target.txtFldLastName.text!)</upd:lastName>
         <!--Optional:-->
         <upd:otherName></upd:otherName>
         <!--Optional:-->
         <upd:streetName>\(target.txtFldStreetName.text!)</upd:streetName>
         <!--Optional:-->
         <upd:postCode>\(target.txtFldPostCode.text!)</upd:postCode>
         <!--Optional:-->
         <upd:suburb>\(target.txtFldSubpurb.text!)</upd:suburb>
         <!--Optional:-->
         <upd:stateId>\(stateId)</upd:stateId>
         <!--Optional:-->
         <upd:countryId>9</upd:countryId>
         <!--Optional:-->
         <upd:lawSocietyNumber>\(target.txtFldLawSocietyNumber.text!)</upd:lawSocietyNumber>
         <!--Optional:-->
         <upd:streetNumber>\(target.txtFldStreetNumber.text!)</upd:streetNumber>
         <!--Optional:-->
         <upd:phoneNumber>\(target.txtFldMobileNumber.text!)</upd:phoneNumber>
         <!--Optional:-->
         <upd:Password>\(target.txtFldPassword.text!)</upd:Password>
         <!--Optional:-->
         <upd:address>""</upd:address>
         <!--Optional:-->
         <upd:firm>\(target.txtFldLawFirm.text ?? "")</upd:firm>
        </upd:UpdateUserProfile>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        
        
        guard let url = URL(string: LexString.WebService.UpdateProfile.updateUserProfileService) else{return}
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        CommonFunctions.showLoader()

        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.UpdateProfile.updateUserProfileSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                
                let message = xml["soap:Envelope"]["soap:Body"]["UpdateUserProfileResponse"]["UpdateUserProfileResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["UpdateUserProfileResponse"]["UpdateUserProfileResult"]["Status"].element?.text ?? ""
                if status == "Success" || status == "SUCCESS"{
                    OperationQueue.main.addOperation({
                      //  self.updateUsersOfflineRecord(target: target, selectedState: target.selectedState!)
                        guard let user = User.fetchCurrentUser() else{return}

                        let statName = target.selectedState != nil ? target.selectedState?.name : user.stateName
                        let stateId = target.selectedState != nil ? target.selectedState?.Id : user.stateID
                        
                        user.setValue(target.txtFldMobileNumber.text!, forKey: "phoneNumber")
                        user.setValue(target.txtFldStreetNumber.text!, forKey: "streetNumber")
                        user.setValue(target.txtFldStreetName.text!, forKey: "streetName")
                        user.setValue(target.txtFldSubpurb.text!, forKey: "suburb")
                        user.setValue(target.txtFldPostCode.text!, forKey: "postCode")
                        user.setValue(statName, forKey: "stateName")
                        user.setValue(stateId, forKey: "stateID")
                        user.setValue(target.txtFldPassword.text!, forKey: "password")
                        user.setValue(target.txtFldLawFirm.text ?? "", forKey: "firm")
                        user.setValue(target.txtFldLawSocietyNumber.text!, forKey: "lawSocietyNumber")
                        CoreDataManager.sharedManager.saveContext()

                        let alertController = UIAlertController(title: "Updates Successful", message: message, preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                          //  NotificationCenter.default.post(name: Notification.Name(LexNotification.RefereshData), object: nil)
                            target.dismiss(animated: true, completion: nil)
                        }))
                        target.present(alertController, animated: true, completion: nil)
                    })
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: target)
                    
                }else{
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: target)
                }
                
                completion(message)
            }
            CommonFunctions.hideLoader()
        }
        
        task.resume()
        
        
    }
}

extension XMLIndexer{
    
    var parsedText:String{
        return element?.text ?? ""
    }
    
    func pasredString(key:String) ->String  {
        return self[key].element?.text ?? ""
    }
}
