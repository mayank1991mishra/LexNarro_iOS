//
//  SignupVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

enum TermsAndPolicy: String {
    case TERMS
    case POLICY
    init(){
        self = .TERMS
    }
}

var objTermsAndPolicy = TermsAndPolicy()


class SignupVC: UIViewController,UINavigationControllerDelegate {
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var txtFldFirstName: TextFieldWithIcon!
    @IBOutlet weak var txtFldLastName: TextFieldWithIcon!
    @IBOutlet weak var txtEmailAddress: TextFieldWithIcon!
    @IBOutlet weak var txtFldMobileNumber: TextFieldWithIcon!
    @IBOutlet weak var txtFldStreetNumber: TextFieldWithIcon!
    @IBOutlet weak var txtFldStreetName: TextFieldWithIcon!
    @IBOutlet weak var txtFldPostCode: TextFieldWithIcon!
    @IBOutlet weak var txtFldSelectState: TextFieldWithIcon!
    @IBOutlet weak var txtFldCountry: TextFieldWithIcon!
    @IBOutlet weak var txtFldStateEnrolled: TextFieldWithIcon!
    @IBOutlet weak var txtFldLawSocietyNumber: TextFieldWithIcon!
    @IBOutlet weak var txtFldPassword: TextFieldWithIcon!
    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var txtFldSubpurb: TextFieldWithIcon!
    @IBOutlet weak var txtFldLawFirm: TextFieldWithIcon!
    
    
    var naviagetionType = NavigationType()
    var selectedState:SignupState?
    var selectedEnrolledState:SignupState?
    
    @IBOutlet weak var viewPassword: UIView!
    @IBOutlet weak var btnHideAndShowPassword: UIButton!
    var imagePicker = UIImagePickerController()
    
    @IBOutlet weak var btnTermsAndPolicy: UIButton!
    @IBOutlet weak var txtViewTermsAndPolicyPhrase: UITextView!
    
    @IBOutlet weak var viewTermsAndPolicy: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // imagePicker.delegate = self
        if naviagetionType == .Signup {
            btnEdit.isHidden = true
            
            self.title = "Signup"
            self.termsAndPolicy()
            self.makePrefix()
            viewTermsAndPolicy.isHidden = false
        }else{
            btnEdit.isHidden = false
            // btnHideAndShowPassword.isHidden =
            self.title = "Profile"
            
            viewTermsAndPolicy.isHidden = true
            SignupVCViewModel().userIntractionEnableAndDisable(status: false, target: self)
            setdata()
        }
    }
    
    func termsAndPolicy() {
        let text = NSMutableAttributedString(string: "I Agreed with ")
        text.addAttribute(NSAttributedString.Key.font,
                          value: UIFont.systemFont(ofSize: 15),
                          range: NSRange(location: 0, length: text.length))
        
        text.addAttribute(NSAttributedString.Key.foregroundColor,
                          value: UIColor.white,
                          range: NSRange(location: 0, length: text.length))
        
        
        var interactableTerms = NSMutableAttributedString(string: "Terms and Conditions")
        interactableTerms.addAttribute(NSAttributedString.Key.font,
                                       value: UIFont.systemFont(ofSize: 15),
                                       range: NSRange(location: 0, length: interactableTerms.length))
        interactableTerms =  interactableTerms.underline
        
        
        var interactablePolicy = NSMutableAttributedString(string: "Privacy Policy")
        interactablePolicy.addAttribute(NSAttributedString.Key.font,
                                        value: UIFont.systemFont(ofSize: 15),
                                        range: NSRange(location: 0, length: interactablePolicy.length))
        interactablePolicy =  interactablePolicy.underline
        
        
        // Adding the link interaction to the interactable text
        interactableTerms.addAttribute(NSAttributedString.Key.link,
                                       value: "TermsPseudoLink",
                                       range: NSRange(location: 0, length: interactableTerms.length))
        
        interactablePolicy.addAttribute(NSAttributedString.Key.link,
                                        value: "PolicyPseudoLink",
                                        range: NSRange(location: 0, length: interactablePolicy.length))
        
        // Adding it all together
        text.append(interactableTerms)
        let textAnd = NSMutableAttributedString(string: " & ")
        textAnd.addAttribute(NSAttributedString.Key.font,
                             value: UIFont.systemFont(ofSize: 15),
                             range: NSRange(location: 0, length: textAnd.length))
        textAnd.addAttribute(NSAttributedString.Key.foregroundColor,
                             value: UIColor.white,
                             range: NSRange(location: 0, length: textAnd.length))
        
        
        text.append(textAnd)
        text.append(interactablePolicy)
        
        // Set the text view to contain the attributed text
        txtViewTermsAndPolicyPhrase.attributedText = text
        
        // Disable editing, but enable selectable so that the link can be selected
        txtViewTermsAndPolicyPhrase.isEditable = false
        txtViewTermsAndPolicyPhrase.isSelectable = true
        txtViewTermsAndPolicyPhrase.delegate = self
    }
    
    func setdata()  {
        let user = User.fetchCurrentUser()
        txtFldFirstName.text = user?.firstName
        txtFldLastName.text = user?.lastName
        txtEmailAddress.text = user?.emailAddress
        txtFldMobileNumber.text = user?.phoneNumber
        txtFldStreetNumber.text = user?.streetNumber
        txtFldStreetName.text = user?.streetName
        txtFldPostCode.text = user?.postCode
        txtFldSelectState.text = user?.stateName
        txtFldCountry.text = user?.countryName
        txtFldStateEnrolled.text = user?.stateEnrolledName
        txtFldLawSocietyNumber.text = user?.lawSocietyNumber
        txtFldPassword.text = user?.password
        txtFldSubpurb.text = user?.suburb
        txtFldLawFirm.text = user?.firm
        // txtFldFirstName.text = user?.firstName
        
        
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSignupAction(_ sender: Any) {
        SignupVCViewModel().doSignup(target: self,isEdit: false, completion: {(message) in
            
        })
    }
    
    
    @IBAction func btnEditAction(_ sender: Any) {
        
        if btnEdit.currentImage == UIImage(named: "profile_edit")! {
            SignupVCViewModel().setEditableFieldsToViewController(target: self)
            
            btnEdit.setImage(UIImage(named: "right_Ok")!, for: .normal)
            // btnEdit.setTitle("Save", for: .normal)
        }else{
            
            //btnEdit.setTitle("Edit", for: .normal)
            SignupVCViewModel().doSignup(target: self,isEdit: true, completion: {[weak self](message) in
                if message == "Success"{
                    OperationQueue.main.addOperation({
                        self?.btnEdit.setImage(UIImage(named: "profile_edit")!, for: .normal)
                    })
                }
            })
        }
        
    }
    
    @IBAction func btnPasswordHideShowAction(_ sender: Any) {
        let btn = sender as! UIButton
        btn.isSelected = !btn.isSelected
        txtFldPassword.isSecureTextEntry = !btn.isSelected
    }
    @IBAction func btnTermsAndPolicyAction(_ sender: Any) {
        btnTermsAndPolicy.isSelected = !btnTermsAndPolicy.isSelected
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func makePrefix() {
        let attributedString = NSMutableAttributedString(string: "0")
        attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.white, range: NSMakeRange(0,1))
        txtFldMobileNumber.attributedText = attributedString
    }
    
    func OpenTermsAndPolicy(){
        let stryBoard = UIStoryboard(name: "LeftMenu", bundle: nil)
        let termsNavVC = stryBoard.instantiateViewController(withIdentifier: "WebBasedNavVC") as! CommonNavVC
        self.present(termsNavVC, animated: true, completion: nil)
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension SignupVC:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.txtFldPostCode{
            let maxLength = 4
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
            
        } else if textField == self.txtFldLawSocietyNumber{
            let maxLength = 10
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
            
        } else if textField == self.txtFldMobileNumber{
            textField.typingAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
            let protectedRange = NSMakeRange(0, 1)
            let intersection = NSIntersectionRange(protectedRange, range)
            if intersection.length > 0 {
                
                return false
            }
            if range.location == 9 {
                return true
            }
            if range.location + range.length > 9 {
                return false
            }
            return true
        }
        return true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.txtFldSelectState {
            
            SignupVCViewModel().getAllStates(target: self, countryId: "9") {[unowned self] (states) in
                
                OperationQueue.main.addOperation({
                    let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
                    if  states.count == 0{
                        
                        CommonFunctions.showAlertMessage(title: "Alert!", message: "No States are available.", viewController: self)
                    }else{
                        pickerPopupVC.showPickerForData(data: states) { (selectedData,selectedIndex) in
                            let state = selectedData as! SignupState
                            self.selectedState = state
                            self.txtFldSelectState?.text = state.name
                        }
                        self.present(pickerPopupVC, animated: true, completion: nil)
                    }
                })
            }
            return false
        }else if textField == self.txtFldStateEnrolled {
            
            
            SignupVCViewModel().getAllStates(target: self, countryId: "9") {[unowned self] (states) in
                OperationQueue.main.addOperation({
                    let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
                    if  states.count == 0{
                        
                        CommonFunctions.showAlertMessage(title: "Alert!", message: "No States are available.", viewController: self)
                    }
                    pickerPopupVC.showPickerForData(data: states) { (selectedData,selectedIndex)  in
                        let state = selectedData as! SignupState
                        self.selectedEnrolledState = state
                        self.txtFldStateEnrolled?.text = state.name
                    }
                    self.present(pickerPopupVC, animated: true, completion: nil)
                })
                
                
            }
            return false
            
        }
        return true
    }
    
    
    
}


extension SignupVC: UITextViewDelegate{
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        print(URL.absoluteString)
        let absUrl = URL.absoluteString
        
        objTermsAndPolicy = (absUrl == "TermsPseudoLink") ? .TERMS : .POLICY
        
        if absUrl == "TermsPseudoLink" {
            print("Terms \(absUrl)")
        }else {
            print("Policy \(absUrl)")
        }
        OpenTermsAndPolicy()
        
        return true
    }
}
