//
//  SignupVCProtocol.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation
import UIKit

@objc protocol SignupVCProtocol:class {
    
    func validateFirstname(target:SignupVC) -> Bool
    func validateLastName(target: SignupVC) -> Bool
    func validateEmailAddress(target:SignupVC) -> Bool
    func validateMobileNo(target: SignupVC) -> Bool
    func validateStreetNo(target:SignupVC) -> Bool
    func validateStreetName(target: SignupVC) -> Bool
    func validatePostCode(target:SignupVC) -> Bool
    func validateState(target: SignupVC) -> Bool
    func validateEnrolledState(target:SignupVC) -> Bool
    func validateCountry(target:SignupVC) -> Bool
    func validateLawSocietyNo(target: SignupVC) -> Bool
    func validatePassword(target: SignupVC) -> Bool

    func addAnimationOnSignupButton(target:SignupVC)

    func doSignup(target:SignupVC,isEdit:Bool,completion: @escaping(String) -> Void)
    
}


let __firstpart = "[A-Z0-9a-z]([A-Z0-9a-z._%+-]{0,30}[A-Z0-9a-z])?"
let __serverpart = "([A-Z0-9a-z]([A-Z0-9a-z-]{0,30}[A-Z0-9a-z])?\\.){1,5}"
let __emailRegex = __firstpart + "@" + __serverpart + "[A-Za-z]{2,8}"
let __emailPredicate = NSPredicate(format: "SELF MATCHES %@", __emailRegex)

extension String {
    func isValidEmail() -> Bool {
        return __emailPredicate.evaluate(with: self)
    }
    
   
}

extension NSMutableAttributedString {
    var underline: NSMutableAttributedString {
          self.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: NSRange(location: 0, length: self.length))
        return self
    }
}
