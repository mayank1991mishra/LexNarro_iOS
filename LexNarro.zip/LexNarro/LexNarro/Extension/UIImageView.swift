//
//  UIImageView.swift
//  LexNarro
//
//  Created by Anand Awasthi on 30/07/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation
import UIKit
extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit,completion: @escaping (Bool) -> Void) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
          
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { completion(true);return }
           
            OperationQueue.main.addOperation({
                UIView.animate(withDuration:0.9,
                               delay: 0.2,
                               usingSpringWithDamping: 0.3,
                               initialSpringVelocity: 0.5,
                               options: .curveEaseIn,
                               animations: {
                                //Do all animations here
                                self.image = image
                                completion(true)
                                
                }, completion: {
                    //Code to run after animating
                    (value: Bool) in
                })
            })
            }.resume()
    }
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit,completion: @escaping (Bool) -> Void) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { completion(false); return }
        downloaded(from: url, contentMode: mode, completion: completion)
    }
}
