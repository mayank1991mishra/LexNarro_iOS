//
//  UILabel.swift
//  LexNarro
//
//  Created by Anand Awasthi on 23/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

extension UILabel{
    
    func addAnimationOnWelcomeLabel() {
        UIView.animate(withDuration: 0.8, delay: 0.0, options: [.transitionCurlDown], animations: {
            
        }, completion: nil)
    }

    func moveLeft(){
        
    }
    
    func moveRight(){
        
    }
    
}
