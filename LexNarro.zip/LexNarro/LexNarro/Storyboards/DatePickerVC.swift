//
//  DatePickerVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 29/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit



class DatePickerVC: UIViewController {
    @IBOutlet weak var datePicker: UIDatePicker!
   private var selectedDate:String = ""
    
   private var completionHandler: ((String)->Void)?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        datePicker.maximumDate = Date()
        datePicker.date = Date()
        datePicker.setValue(UIColor.white, forKeyPath: "textColor")
        datePicker.addTarget(self, action: #selector(handleDatePicker), for: .valueChanged)

    }
    
    func getDate(completion:@escaping (String)->Void)  {
        completionHandler = completion
    }
    @objc func handleDatePicker(_ datePicker: UIDatePicker) {
       selectedDate = datePicker.date.formatted
    }
    
    @IBAction func btnCancelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btnDoneAction(_ sender: Any) {
        
       let newSelectedDate = selectedDate.isEmpty ? Date().formatted : selectedDate
        
        completionHandler!(newSelectedDate)
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension Date {
    static let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }()
    var formatted: String {
        return Date.formatter.string(from: self)
    }
}
