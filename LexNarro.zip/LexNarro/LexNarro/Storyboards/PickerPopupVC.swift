//
//  PickerPopupVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 29/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit


class PickerPopupVC: UIViewController {
    @IBOutlet weak var pickerView: UIPickerView!
    var selectedData:Any?
    var numberOfComponents = 1
    var selectedIndex = 0
    
    private var data = [Any]()
    
    var completionHandler: ((Any,Int)->Void)?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        pickerView.selectRow(selectedIndex, inComponent: 0, animated: true)
        // Do any additional setup after loading the view.
        pickerView.setValue(UIColor.white, forKeyPath: "textColor")

    }
    
    func showPickerForData(data:[Any],completion: @escaping (Any,Int) -> Void)  {
        self.data = data
        pickerView?.reloadAllComponents()
      //  pickerView.showsSelectionIndicator = true
       // pickerView.selectedRow(inComponent: selectedIndex)
        completionHandler = completion
    }

    @IBAction func btnCancelAction(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btnDoneAction(_ sender: Any) {
        completionHandler!(selectedData ?? (data[selectedIndex] ?? "No Data Found"),selectedIndex)
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PickerPopupVC:UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return numberOfComponents
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return data.count
    }
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        
        if let dt = data[row] as? SubActivity {
            return NSAttributedString(string: dt.name, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
            
        }else if let dt = data[row] as? Activity{
            return NSAttributedString(string: dt.name, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }else if let dt = data[row] as? Category{
            return NSAttributedString(string: dt.name, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }else if let dt = data[row] as? States{
            return NSAttributedString(string: dt.name ?? "", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }else if let dt = data[row] as? SignupState{
            return NSAttributedString(string: dt.name, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }else if let dt = data[row] as? DashboardCPDYearModel{
            return NSAttributedString(string: dt.value, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }else if let dt = data[row] as? String{
            return NSAttributedString(string: dt, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }
        return NSAttributedString(string: "", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])

    }
    
  
    
}

extension PickerPopupVC:UIPickerViewDelegate{
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedData = data[row]
        selectedIndex = row
    }
}
