//
//  MyTransactionVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 26/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash


struct UserTransactions {
    var transactionId:String
    var rateID:String
    var userID:String
    var firstName:String
    var lastName:String
    var PlanID:String
    var planName:String
    var amount:String
    var startDate:String
    var endDate:String
    var paymentStatus:String
    var transectionID:String
    var status:String
    var paymentDate:String
    var invoiceNo:String
    var paymentMethod:String

}

class MyTransactionVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var arrayTransactions = [UserTransactions]()
    var dataFromService: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dataFromService = false
        tblView.tableFooterView = UIView()

        
        callWebserviceMyTransaction(email: User.fetchCurrentUser()?.emailAddress ?? "")
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    
    func callWebserviceMyTransaction(email:String){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:user="http://www.lexnarro.com.au/services/UserTransaction.asmx">
            <soapenv:Header/>
        <soapenv:Body>
        <user:GetTransactions>
         <user:email>\(email)</user:email>
        </user:GetTransactions>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.UserTransaction.getTransactionsService) else{return}
        if !CommonFunctions.checkInternetConnection() {
                CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()

        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.UserTransaction.getTransactionsSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["GetTransactionsResponse"]["GetTransactionsResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["GetTransactionsResponse"]["GetTransactionsResult"]["Message"].element?.text ?? ""
                
                self.dataFromService = true
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    for elem in xml["soap:Envelope"]["soap:Body"]["GetTransactionsResponse"]["GetTransactionsResult"]["Transactions"]["UserTransactions"].all {
                        
                        let endDateArray = !(elem["End_Date"].element?.text ?? "").isEmpty ? (elem["End_Date"].element?.text ?? "").components(separatedBy: "T") : [""]
                        
                        let paymentDate = !(elem["Payment_Date"].element?.text ?? "").isEmpty ? (elem["Payment_Date"].element?.text ?? "").components(separatedBy: "T") : [""]

                        let transaction =  UserTransactions(transactionId: elem["Transection_ID"].element?.text ?? "", rateID: elem["Rate_ID"].element?.text ?? "", userID: elem["User_ID"].element?.text ?? "", firstName: elem["FirstName"].element?.text ?? "", lastName: elem["LastName"].element?.text ?? "", PlanID: elem["PlanID"].element?.text ?? "", planName: elem["PlanName"].element?.text ?? "", amount: elem["Amount"].element?.text ?? "", startDate: elem["Start_Date"].element?.text ?? "", endDate: endDateArray.first!, paymentStatus: elem["Payment_Status"].element?.text ?? "", transectionID: elem["Transection_ID"].element?.text ?? "", status: elem["Status"].element?.text ?? "", paymentDate: paymentDate.first!, invoiceNo: elem["Invoice_No"].element?.text ?? "", paymentMethod: elem["Payment_Method"].element?.text ?? "")
                        
                        self.arrayTransactions.append(transaction)
                    }
                    
                    print(self.arrayTransactions)
                    
                    OperationQueue.main.addOperation({
                        self.arrayTransactions = self.arrayTransactions.reversed()
                        self.tblView.reloadData()
                    })
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }

    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MyTransactionVC:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrayTransactions.isEmpty {
            let lbl = CommonFunctions.addEmptyMessageLablel(text: "No transactions performed by you ",dataFromService: dataFromService)
            tableView.backgroundView = lbl
            return 0
        }
        tableView.backgroundView = UIView()
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  self.arrayTransactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTransactionCell", for: indexPath) as! MyTransactionCell
        cell.loadData(transaction: self.arrayTransactions[indexPath.row])
        return cell
        
    }
    
    
}
