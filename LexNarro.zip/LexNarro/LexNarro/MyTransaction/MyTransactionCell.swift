//
//  MyTransactionCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 26/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class MyTransactionCell: UITableViewCell {
    @IBOutlet weak var lblPaymentDate: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblPlan: UILabel!
    @IBOutlet weak var lblInvoiceNo: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func loadData(transaction:UserTransactions)  {
        lblPaymentDate.text = transaction.paymentDate
        lblAmount.text = transaction.amount
        lblPlan.text = transaction.planName
        lblInvoiceNo.text = transaction.invoiceNo
        lblEndDate.text = transaction.endDate
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
