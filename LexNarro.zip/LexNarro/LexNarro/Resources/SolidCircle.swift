//
//  SolidCircle.swift
//  LexNarro
//
//  Created by Anand Awasthi on 25/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

@IBDesignable class SolidCircle: UIView {
    let shapeLayer = CAShapeLayer()
    var circularPathFix: UIBezierPath!
    @IBInspectable var circleColor: UIColor = UIColor.red
    var startAngle = -CGFloat.pi/2

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
   
    */

    override func draw(_ rect: CGRect) {
        // Drawing code
        let radius = self.frame.size.width/2
        let centerX = radius
        let centerY = radius
        let center = CGPoint(x: centerX, y: centerY)
        circularPathFix = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: 2*CGFloat.pi, clockwise: true)

        shapeLayer.path = circularPathFix.cgPath
        shapeLayer.strokeColor = circleColor.cgColor
        shapeLayer.lineWidth = 0
        shapeLayer.fillColor = circleColor.cgColor
        shapeLayer.strokeEnd = 1
        shapeLayer.lineCap = CAShapeLayerLineCap.butt
        self.layer.addSublayer(shapeLayer)
    }
    
}
