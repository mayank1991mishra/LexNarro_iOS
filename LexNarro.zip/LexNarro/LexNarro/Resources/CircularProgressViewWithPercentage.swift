//
//  CircularProgressViewWithPercentage.swift
//  Circular_Progressbar
//
//  Created by User on 5/20/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit

@IBDesignable class CircularProgressViewWithPercentage: UIView {

    //let center = self.center
    let trackLayer = CAShapeLayer()
    let shapeLayer = CAShapeLayer()
    var circularPath: UIBezierPath!
    var circularPathFix: UIBezierPath!
    var startAngle = -CGFloat.pi/2
    var endAngle = CGFloat.pi*2
    
   // @IBInspectable var radius:CGFloat = 100
  
    @IBInspectable var lineColor: UIColor = UIColor.red
    @IBInspectable var fixLineColor: UIColor = UIColor.black
    @IBInspectable var lineWidth:CGFloat = 10
    @IBInspectable var animationDuration:Double = 10
    @IBInspectable var progress:CGFloat = 5

    //var  = value
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
       // fatalError("init(coder:) has not been implemented")
    }
    //     Only override draw() if you perform custom drawing.
//     An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
         //Drawing code
        let radius = self.frame.size.width/2.0 - (lineWidth + 4.0)/2.0 - 5.0
        let centerX = radius + (lineWidth + 4.0)/2.0 + 2.5
        let centerY = radius + (lineWidth + 4.0)/2.0 + 2.5
        let center = CGPoint(x: centerX, y: centerY)
        //endAngle = 90
        endAngle = RadianAngle(degrees: CGFloat.pi*10/100)
       // endAngle = CGFloat.pi/100000
        print(endAngle)
      //  let end_angle:CGFloat = 30 * 1.8
        
        let strtAngle = CGFloat(270).toRadians()
        let end_Angle = progress(progressInPercentage: (progress >= 100 ? 99.9 : progress)  * 3.6).toRadians()
        
        circularPath = UIBezierPath(arcCenter: center, radius: radius, startAngle:  strtAngle, endAngle: end_Angle, clockwise: true)
         circularPathFix = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: 2*CGFloat.pi, clockwise: true)
        // Progressive circle color
        trackLayer.path = circularPath.cgPath
        trackLayer.strokeColor = lineColor.cgColor
        trackLayer.lineWidth = lineWidth + 4
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.strokeEnd = 0
        trackLayer.lineCap = CAShapeLayerLineCap.square

        // Fix circle color
        shapeLayer.path = circularPathFix.cgPath
        shapeLayer.strokeColor = fixLineColor.cgColor
        shapeLayer.lineWidth = lineWidth
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeEnd = 1
        shapeLayer.lineCap = CAShapeLayerLineCap.butt
        self.layer.addSublayer(shapeLayer)
        self.layer.addSublayer(trackLayer)
        
       // animation()
    }
    
    
    func animation(){
        let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        basicAnimation.toValue = 1
        basicAnimation.duration = animationDuration
        basicAnimation.fillMode = CAMediaTimingFillMode.forwards
        basicAnimation.isRemovedOnCompletion = false
        trackLayer.add(basicAnimation, forKey: "basicAnimation")
    }
    
    func progress(progressInPercentage:CGFloat) -> CGFloat{
        let progressPer = 270 + progressInPercentage
        
        if progressPer <= 360 {
            return progressPer
        }else if progressInPercentage == 108{
            return 2*CGFloat.pi
        }
        else {
            return progressPer - 360
        }
    }

}


typealias RadianAngle = CGFloat

let π = RadianAngle(CGFloat.pi)
//let π_x_2 = RadianAngle(M_PI * 2)
//let π_2 = RadianAngle(M_PI_2)
//let π_4 = RadianAngle(M_PI_4)

extension RadianAngle {
    var degrees: CGFloat {
        return self * 180 / π
    }
    func toRadians() -> CGFloat {
        return self * π / 180.0
    }
    init(degrees: CGFloat) {
        self = CGFloat(degrees) * π / 180
    }
}
