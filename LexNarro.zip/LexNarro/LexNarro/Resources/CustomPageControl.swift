//
//  CustomPageControl.swift
//  CustomPageControl
//
//  Created by User on 5/24/19.
//  Copyright © 2019 User. All rights reserved.
//
import UIKit

@IBDesignable class CustomPageControl: UIPageControl {
    
    @IBInspectable var currentPageImage: UIImage?
    
    @IBInspectable var otherPagesImage: UIImage?
    
    override var numberOfPages: Int   {
        didSet {
            updateDots()
        }
    }
    
    override var currentPage: Int {
        didSet {
            updateDots()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.transform = CGAffineTransform.init(scaleX: 1.6, y: 1.6)
        pageIndicatorTintColor = .clear
        currentPageIndicatorTintColor = .clear
        clipsToBounds = false
    }
    
    private func updateDots() {
        
        for (index, subview) in subviews.enumerated() {
            var imageView: UIImageView
            if let existingImageview = getImageView(forSubview: subview) {
               // existingImageview.frame = CGRect(x: 0, y: 0, width: 14, height: 14)
                imageView = existingImageview
            } else {
                imageView = UIImageView(image: otherPagesImage)
                //imageView.frame = CGRect(x: 0, y: 0, width: 7, height: 7)

                imageView.center = subview.center
                subview.addSubview(imageView)
                subview.clipsToBounds = false
            }
            
            if currentPage == index {
                
                UIView.animate(withDuration:0.9,
                               delay: 0.2,
                               usingSpringWithDamping: 0.3,
                               initialSpringVelocity: 0.5,
                               options: .curveEaseIn,
                               animations: {
                                //Do all animations here
                                imageView.frame.size.width = 12
                                imageView.frame.size.height = 12
                                imageView.frame.origin.x = -2.8
                                imageView.frame.origin.y = -2.8

                }, completion: {
                    //Code to run after animating
                    (value: Bool) in
                })
                

            }else{
                imageView.frame.size.width = 6
                imageView.frame.size.height = 6
                imageView.frame.origin.x = 0
                imageView.frame.origin.y = 0
            }
            
            imageView.image = currentPage == index ? currentPageImage : otherPagesImage
        }
    }
    
    private func getImageView(forSubview view: UIView) -> UIImageView? {
        if let imageView = view as? UIImageView {
            return imageView
        } else {
            let view = view.subviews.first { (view) -> Bool in
                return view is UIImageView
                } as? UIImageView
            
            return view
        }
    }
}

