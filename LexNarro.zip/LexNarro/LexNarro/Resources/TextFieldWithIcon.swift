//
//  TextFieldWithIcon.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

@IBDesignable class TextFieldWithIcon: UITextField {

    @IBInspectable var leftPadding: CGFloat = 0
    var closure: ((Bool) -> Void)?


    @IBInspectable var color: UIColor = UIColor.white {
        didSet {
            updateView(tintColor: UIColor.white)
        }
    }
    
    @IBInspectable var leftImage: UIImage? {
        didSet {
            updateView(tintColor: UIColor.white)
        }
    }
    
    @IBInspectable var cornorRadiusTF: CGFloat = 5.0 {
        didSet {
            updateView(tintColor: UIColor.white)
        }
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    
    */
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        super.draw(rect)
        self.tintColor = UIColor.white
        self.textColor = color
        self.layer.cornerRadius = cornorRadiusTF
        self.clipsToBounds = true
        let vw = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 50))
        self.rightView = vw
        self.rightViewMode = UITextField.ViewMode.always
        self.attributedPlaceholder = NSAttributedString(string: placeholder != nil ?  placeholder! : "", attributes:[NSAttributedString.Key.foregroundColor: color])
        self.layoutIfNeeded()
    }
    
    // Provides left padding for images
    override func leftViewRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.leftViewRect(forBounds: bounds)
        textRect.origin.x += leftPadding
        return textRect

    }

    override func rightViewRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.rightViewRect(forBounds: bounds)
        textRect.origin.x -= 20
        return textRect
        
    }

    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.editingRect(forBounds: bounds)
        textRect.origin.x += leftPadding + 10
        return textRect
    }
    override func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.placeholderRect(forBounds: bounds)
        textRect.origin.x += leftPadding - 10
        return textRect

    }
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.textRect(forBounds: bounds)
        textRect.origin.x += leftPadding + 10
        return textRect
    }
    
    func updateView(tintColor:UIColor) {
        if let image = leftImage {
            leftViewMode = UITextField.ViewMode.always
            let imageView = UIImageView(frame: CGRect(x: 10, y: 0, width: 20, height: 20))
            imageView.contentMode = .scaleAspectFit
            imageView.image = image
            // Note: In order for your image to use the tint color, you have to select the image in the Assets.xcassets and change the "Render As" property to "Template Image".
            imageView.tintColor = color
            leftView = imageView
        } else {
            leftViewMode = UITextField.ViewMode.never
            leftView = nil
        }
        
        // Placeholder text color
        attributedPlaceholder = NSAttributedString(string: placeholder != nil ?  placeholder! : "", attributes:[NSAttributedString.Key.foregroundColor: color])
        self.layer.cornerRadius = cornorRadiusTF

    }
    
    
    
}

extension TextFieldWithIcon {
    public func shakeTextField(errorMessage:String, completion: @escaping (Bool) -> Void )
    {
        let oldPlaceHolder = self.placeholder ?? ""
        
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 3
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        self.layer.add(animation, forKey: "position")
        //  updateView(tintColor: UIColor.red)
        closure = completion
        self.attributedPlaceholder = NSAttributedString(string: errorMessage,
                                                        attributes: [NSAttributedString.Key.foregroundColor: UIColor.red])
        perform(#selector(resetPlaceHolder(placeHolder:)), with: oldPlaceHolder, afterDelay: 2.0)
        
        
    }
    
    @objc func resetPlaceHolder(placeHolder:String){
        
        self.attributedPlaceholder = NSAttributedString(string: placeHolder,
                                                        attributes: [NSAttributedString.Key.foregroundColor: self.color])
        closure!(true)
        self.layoutIfNeeded()
        
    }
}
