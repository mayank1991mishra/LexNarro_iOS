//
//  SideMenuController.swift
//  UrbanDrive
//
//  Created by ANAND AVASTHI on 30/05/18.
//  Copyright © 2018 Roovea. All rights reserved.
//

import UIKit

protocol SlideMenuDelegate {
    func slideMenuItemSelectedAtIndex(_ index : Int32)
}

class SideMenuController: CommonVC {
    @IBOutlet weak var constraintTrailingSideMenu: NSLayoutConstraint!
    var sideMenuWidth:CGFloat = 0.0
    let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
    var blurEffectView: UIVisualEffectView?

    @IBOutlet weak var mainContainerView: UIView!
    @IBOutlet weak var sideMenuView: UIView!
    
    var mainViewControllerVC:UIViewController?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        constraintTrailingSideMenu.constant = self.view.frame.size.width
        sideMenuWidth = self.view.frame.width * 0.80
        
        //print(self.childViewControllers.first)
        if let navVC = self.children.first as? UINavigationController {
           let dashVC = navVC.viewControllers.first as? DashboardVC
            dashVC?.objSideMenuVC = self
        }
        mainViewControllerVC = self.children.first
        
        
        // Do any additional setup after loading the view.
    }

  
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    @objc func toggleMenu()  {
        UIView.animate(withDuration:0.9,
                       delay: 0.2,
                       usingSpringWithDamping: 0.6,
                       initialSpringVelocity: 0.2,
                       options: .curveEaseIn,
                       animations: {
                        //Do all animations here
                        if self.constraintTrailingSideMenu.constant == self.view.frame.size.width {
                            //constraintTrailingSideMenu.constant = self.view.frame.size.width
                            self.constraintTrailingSideMenu.constant = 120
                            self.mainContainerView.addSubview(self.blurEffectView!)
                            
                        }else{
                            self.constraintTrailingSideMenu.constant = self.view.frame.size.width
                            
                            self.blurEffectView?.removeFromSuperview()
                        }

        }, completion: {
            //Code to run after animating
            (value: Bool) in
        })
        
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
            //self.mainContainerView.layoutIfNeeded()
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension SideMenuController: SlideMenuDelegate{
    func slideMenuItemSelectedAtIndex(_ index: Int32) {
        if blurEffectView == nil {
            blurEffectView = UIVisualEffectView(effect: blurEffect)
            blurEffectView?.frame = mainContainerView.bounds
            blurEffectView?.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(SideMenuController.toggleMenu))
            blurEffectView?.addGestureRecognizer(tapGesture)
        }
        toggleMenu()
    }
}
