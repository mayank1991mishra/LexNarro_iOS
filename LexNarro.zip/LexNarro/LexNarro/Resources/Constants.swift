//
//  Constants.swift
//  LexNarro
//
//  Created by Anand Awasthi on 05/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

struct Constants {
    static let kDeviceToken = "DeviceToken"
}

struct LexColor {
    static let redColor = UIColor(red: 180/255.0, green: 0, blue: 0, alpha: 1.0)
    static let whiteColor = UIColor.white
}

struct LexNotification {
    static let RefereshData = "RefereshData"
}


struct LexString {
    struct WebService {
        struct Login {
            static let service:String = "https://lexnarro.com.au/services/login.asmx"
            static let soapAction:String = "http://www.lexnarro.com.au/services/Login.asmx/UserLogin"
        }
        
        struct Registration {
            static let service:String = "https://lexnarro.com.au/services/registration.asmx"
            static let soapAction:String = "http://www.lexnarro.com.au/services/Registration.asmx/UserRegistration"
        }
        struct ForgotPassword {
            static let mailPasswordService:String =  "https://lexnarro.com.au/services/forgotpassword.asmx"
            static let mailPasswordSoapAction:String = "http://www.lexnarro.com.au/services/ForgotPassword.asmx/mailPassword"
        }
        struct UpdateProfile {
            static let updateUserProfileService:String = "https://lexnarro.com.au/services/updateprofile.asmx?op=UpdateUserProfile"
            static let updateUserProfileSoapAction:String = "http://www.lexnarro.com.au/services/UpdateProfile.asmx/UpdateUserProfile"
        }
        struct StateNames {
            static let getAllStatesService:String = "https://lexnarro.com.au/services/states.asmx"
            static let getAllStatesSoapAction:String = "http://www.lexnarro.com.au/services/States.asmx/GetAllStates"
            
            static let getUserEnrolledStateService:String = "https://lexnarro.com.au/services/states.asmx?op=GetUserEnrolledState"
            static let getUserEnrolledStateSoapAction:String = "http://www.lexnarro.com.au/services/States.asmx/GetUserEnrolledState"

        }
        struct Dashboard {
            static let trainingSummaryService:String = "https://lexnarro.com.au/services/dashboard.asmx?op=TrainingSummary"
            static let trainingSummarySoapAction:String = "http://www.lexnarro.com.au/services/Dashboard.asmx/TrainingSummary"
        }
        struct Training {
            static let createTrainingService:String = "https://lexnarro.com.au/services/training.asmx?op=CreateTraining"
            static let createTrainingSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/CreateTraining"
            
            static let deleteTrainingService:String = "https://lexnarro.com.au/services/training.asmx?op=DeleteTraining"
            static let deleteTrainingSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/DeleteTraining"

            static let detailTrainingService:String = "https://lexnarro.com.au/services/training.asmx?op=DetailTraining"
            static let detailTrainingSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/DetailTraining"

            static let editTrainingService:String = "https://lexnarro.com.au/services/training.asmx?op=EditTraining"
            static let editTrainingSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/EditTraining"

            static let getActivitiesService:String = "https://lexnarro.com.au/services/training.asmx?op=GetActivities"
            static let getActivitiesSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/GetActivities"

            static let getSubActivitiesService:String = "https://lexnarro.com.au/services/training.asmx?op=GetSubActivities"
            static let getSubActivitiesSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/GetSubActivities"

            static let getCategoriesService:String = "https://lexnarro.com.au/services/training.asmx?op=GetCategories"
            static let getCategoriesSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/GetCategories"

            static let getTrainingService:String = "https://lexnarro.com.au/services/training.asmx?op=GetTraining"
            static let getTrainingSoapAction:String = "http://www.lexnarro.com.au/services/Training.asmx/GetTraining"

        }
        struct PlanMaster {
            static let getPlanService:String = "https://lexnarro.com.au/services/planmaster.asmx"
            static let getPlanSoapAction:String = "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        }
        struct UserTransaction {
            static let getTransactionsService:String = "https://lexnarro.com.au/services/usertransaction.asmx"
            static let getTransactionsSoapAction:String = "http://www.lexnarro.com.au/services/UserTransaction.asmx/GetTransactions"
            
            static let postTransactionService:String = "https://lexnarro.com.au/services/usertransaction.asmx?op=PostTransaction"
            static let postTransactionSoapAction:String = "http://www.lexnarro.com.au/services/UserTransaction.asmx/PostTransaction"

        }
        struct DownloadAndEmailService {
        
            static let downloadInvoiceService:String = "https://lexnarro.com.au/services/DownloadAndEmailService.asmx?op=DownloadInvoice"
            static let downloadInvoiceSoapAction:String = "http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx/DownloadInvoice"
            
            static let downloadTrainingReportService:String = "https://lexnarro.com.au/services/DownloadAndEmailService.asmx?op=DownloadTrainingReport"
            static let downloadTrainingReportsoapAction:String = "http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx/DownloadTrainingReport"

            static let emailInvoiceService:String = "https://lexnarro.com.au/services/DownloadAndEmailService.asmx?op=EmailInvoice"
            static let emailInvoiceSoapAction:String = "http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx/EmailInvoice"

            static let emailTrainingReportService:String = "https://lexnarro.com.au/services/DownloadAndEmailService.asmx?op=EmailTrainingReport"
            static let emailTrainingReportSoapAction:String = "http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx/EmailTrainingReport"

        }
        struct CarryOver {
            static let getService:String = "https://lexnarro.com.au/services/carryover.asmx?op=GetCarryOverRecords"
            static let getSoapAction:String = "http://www.lexnarro.com.au/services/carryOver.asmx/GetCarryOverRecords"
            
            static let doService:String = "https://lexnarro.com.au/services/carryover.asmx?op=DoCarryOver"
            static let doSoapAction:String = "http://www.lexnarro.com.au/services/carryOver.asmx/DoCarryOver"

        }
    }
}
