//
//  CommonFunctions.swift
//  LexNarro
//
//  Created by Anand Awasthi on 31/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class CommonFunctions: NSObject {
    lazy var objAppdelegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    
    class func showLoader(_ title:String? = nil)  {
        OperationQueue.main.addOperation {
            var config : SwiftLoader.Config = SwiftLoader.Config()
            config.size = 100
            config.spinnerColor = .red
            config.foregroundColor = .black
            config.foregroundAlpha = 0.5
            SwiftLoader.setConfig(config: config)
            SwiftLoader.show(title: title, animated: true)
        }
        
    }
    
    class func hideLoader(){
        OperationQueue.main.addOperation {
            
            SwiftLoader.hide()
        }
    }
    
    class func showAlertMessage(title:String?,message:String,viewController:UIViewController){
        OperationQueue.main.addOperation {

        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        viewController.present(alertVC, animated: true, completion: nil)
        }
    }
    
    class func savePdf(pdfUrl:URL, fileName:String, completion:@escaping (String)->Void) {
        DispatchQueue.main.async {
            
            guard let  pdfData = try? Data(contentsOf: pdfUrl) else {return}
            
            let resourceDocPath = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
            let pdfNameFromUrl = "LexNarro-\(fileName).pdf"
            let actualPath = resourceDocPath.appendingPathComponent(pdfNameFromUrl)
            do {
                try pdfData.write(to: actualPath, options: .atomic)
                print("pdf successfully saved!")
                completion("pdf successfully saved!")
            } catch {
                print("Pdf could not be saved")
                completion("Pdf could not be saved")

            }
        }
    }
    
   class func showSavedPdf(url:String, fileName:String) {
        if #available(iOS 10.0, *) {
            do {
                let docURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let contents = try FileManager.default.contentsOfDirectory(at: docURL, includingPropertiesForKeys: [.fileResourceTypeKey], options: .skipsHiddenFiles)
                for url in contents {
                    if url.description.contains("\(fileName).pdf") {
                        // its your file! do what you want with it!
                        
                    }
                }
            } catch {
                print("could not locate pdf file !!!!!!!")
            }
        }
    }
    
    // check to avoid saving a file multiple times
    class func pdfFileAlreadySaved(url:String, fileName:String)-> Bool {
        var status = false
        if #available(iOS 10.0, *) {
            do {
                let docURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let contents = try FileManager.default.contentsOfDirectory(at: docURL, includingPropertiesForKeys: [.fileResourceTypeKey], options: .skipsHiddenFiles)
                for url in contents {
                    if url.description.contains("YourAppName-\(fileName).pdf") {
                        status = true
                    }
                }
            } catch {
                print("could not locate pdf file !!!!!!!")
            }
        }
        return status
    }
    

    
    class func checkInternetConnection()-> Bool{
       let reachability = Reachability(hostname: "www.google.com")
        guard let internetStatus = reachability?.currentReachabilityStatus() else{return false}
        if (internetStatus != NetworkStatus.ReachableViaWiFi) && (internetStatus == NetworkStatus.NotReachable) && (internetStatus != NetworkStatus.ReachableViaWWAN) {
            return false
        }else{
            return true
        }
        
    }
    
  class func calCulateCPDYear(date1: Date) -> String {
        let calendar = Calendar.current
        
        // Extract the components of the dates
        let date1Components = calendar.dateComponents([.year, .month, .day], from: date1)
        var nextYear = 0
        var previousYear = 0
        var CPDYear = ""
        if let month = date1Components.month, let year = date1Components.year{
            if month > 3{
                nextYear = year + 1
                CPDYear = "\(year)-\(nextYear)"
            }else{
                previousYear = year - 1
                CPDYear = "\(previousYear)-\(year)"
            }
            return CPDYear
        }
        return ""
    }
    
  class func calCulateRemainingDays() -> String {
        let calendar = Calendar.current
        
        // Replace the hour (time) of both dates with 00:00
        
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let CPDYear = calCulateCPDYear(date1: Date())
        let arrayCPDYear = CPDYear.components(separatedBy: "-")
        let endingYear:String! = arrayCPDYear.count > 0 ? arrayCPDYear.last : "2018"
        let endingDateStr = "\(endingYear ?? "2018")-03-31"
        guard let endingDate = dateFormatter.date(from: endingDateStr)else {return ""}
        let date1 = calendar.startOfDay(for: Date())
        let date2 = calendar.startOfDay(for: endingDate)
        
        let components = calendar.dateComponents([.day], from: date1, to: date2)
        guard let remainingDays = components.day else {
            
            return ""
        }
        return "\(remainingDays)"
    }
    
   class func calCulateSelectedIndex(selectedYear:String)->Int{
        guard let arrayCPDYear = CommonFunctions().objAppdelegate.CPDYear else{return 0}
        for (indx,finY) in arrayCPDYear.enumerated() {
            let  isSelected = finY.value == selectedYear
            if isSelected{return indx;}
        }
        return 0
    }
    
    class func addEmptyMessageLablel(text:String,dataFromService:Bool) -> UILabel {
        let lbl = UILabel()
        lbl.text =  !dataFromService ? "" : "  " + text + "  "
        lbl.textColor = UIColor.white
        lbl.backgroundColor = UIColor.clear
        lbl.textAlignment = .center
        lbl.font = UIFont.systemFont(ofSize: 28.0)
        lbl.numberOfLines = 0
        
        return lbl
    }
}
