//
//  ViewReportVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 05/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import PDFKit
class ViewReportVC: UIViewController {
    var urlString = ""
    var pdfData:Data?
    var fileName = ""
 
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.downloadPdf(url: urlString)
       // getFileFromDocumentDirectory()

    }
    func getFileFromDocumentDirectory()  {
        let fileManager = FileManager.default
        let docsurl = try! fileManager.url(for:.documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let documentoPath =  docsurl.appendingPathComponent(fileName)

        print(documentoPath)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       // self.navigationController?.isNavigationBarHidden = false

    }
    func downloadPdf(url:String){
        
        let pdfView = PDFView()
        pdfView.canZoomIn
        pdfView.canZoomOut
        pdfView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pdfView)
        
        pdfView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        pdfView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        pdfView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 44.0).isActive = true
        pdfView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true

        
        if let url = URL(string: url) {
           SwiftLoader.show(animated: true)
            URLSession.shared.dataTask(with: url) { [weak self](data, response, error) in
                OperationQueue.main.addOperation({
                    guard let dt = data else{
                        SwiftLoader.hide()

                        let alertVC = UIAlertController(title: nil, message: "No pdf attached", preferredStyle: .alert)
                        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: {[weak self] (action) in
                            self?.navigationController?.popViewController(animated: true)
                        }))
                        self?.present(alertVC, animated: true, completion: nil)
                        
                        return
                        
                    }
                    self?.pdfData = dt
                    if let pdfDocument = PDFDocument(data: dt){
                        pdfView.displayMode = .singlePageContinuous
                        pdfView.autoScales = true
                        pdfView.displayDirection = .vertical
                        pdfView.document = pdfDocument
                            SwiftLoader.hide()
                    }else{
                            SwiftLoader.hide()
                        let alertVC = UIAlertController(title: nil, message: "No pdf attached", preferredStyle: .alert)
                        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: {[weak self] (action) in
                            self?.navigationController?.popViewController(animated: true)
                        }))
                        self?.present(alertVC, animated: true, completion: nil)
                    }
                })
           
               
                }.resume()
        }else{
            let alertVC = UIAlertController(title: nil, message: "No pdf attached", preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: {[weak self] (action) in
                self?.navigationController?.popViewController(animated: true)
            }))
           self.present(alertVC, animated: true, completion: nil)
            
        }
    
        
    }
    @IBAction func btnBackAction(_ sender: Any) {
        if let nav = self.navigationController {
         nav.popViewController(animated: true)
        }else{
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func btnShareAction(_ sender: Any) {
        // image to share
        if !urlString.isEmpty {
        
        // set up activity view controller
//            guard let pdfUrl =  URL(string: urlString) else{return}
//            guard let  pdfData = try? Data(contentsOf: pdfUrl) else {return}

        let pdfDataArray = [ urlString ]
        let activityViewController = UIActivityViewController(activityItems: pdfDataArray, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
       // activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
        
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
        }else{
            let alertVC = UIAlertController(title: nil, message: "No pdf to share", preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: {[weak self] (action) in
                self?.navigationController?.popViewController(animated: true)
            }))
            self.present(alertVC, animated: true, completion: nil)

        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

