//
//  SoapDemo-Header.h
//  SoapDemo
//
//  Created by User on 5/28/19.
//  Copyright © 2019 User. All rights reserved.
//

#ifndef SoapDemo_Header_h
#define SoapDemo_Header_h

#import "CXMLDocument.h"
#import "CXMLNode.h"
#import "Soap.h"
#import "SoapLiteral.h"
#import "NSMutableArray+Soap.h"
#import "TouchXML.h"
#import "SoapParameter.h"
#import "SoapDictionary.h"
#import "SoapReachability.h"
#import "SoapService.h"

#import "SoapRequest.h"
#import "SoapObject.h"
#import "SoapHandler.h"
#import "SoapNil.h"
#import "Reachability.h"


#endif /* SoapDemo_Header_h */
