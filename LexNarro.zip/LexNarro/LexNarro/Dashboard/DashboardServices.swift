//
//  DashboardServices.swift
//  LexNarro
//
//  Created by Anand Awasthi on 29/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation
import SWXMLHash

extension DashboardVC{
    func callWebserviceToDashBoardDetails(username:String,CPDYear:String){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:das="http://www.lexnarro.com.au/services/Dashboard.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <das:TrainingSummary>
        <das:emailID>\(username)</das:emailID>
        <das:finYear>\(CPDYear)</das:finYear>
        </das:TrainingSummary>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.Dashboard.trainingSummaryService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Dashboard.trainingSummarySoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) {[unowned self] (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                //   print(backToString)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["TrainingSummaryResponse"]["TrainingSummaryResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["TrainingSummaryResponse"]["TrainingSummaryResult"]["Message"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    self.arrayMyCategory.removeAll()
                    for elem in xml["soap:Envelope"]["soap:Body"]["TrainingSummaryResponse"]["TrainingSummaryResult"]["categ"]["MyCategory"].all {
                        let myCategory = DashboardCategoryModel(categoryId: elem.pasredString(key: "CategoryID"), shortName: elem.pasredString(key: "ShortName"), categoryName:elem.pasredString(key: "Category_Name"))
                        
                        self.arrayMyCategory.append(myCategory)
                    }
                    
                    print(self.arrayMyCategory)
                    
                    
                    self.arrayExistingCategory.removeAll()
                    
                    for elem in xml["soap:Envelope"]["soap:Body"]["TrainingSummaryResponse"]["TrainingSummaryResult"]["execCateg"]["ExistingCategory"].all {
                        let exeCategory = DashboardExistingCategoryModel(categoryId:elem["Category_Id"].element?.text ?? "",unitsDone:elem["Units_Done"].element?.text ?? "",CPDYear:elem["Financial_Year"].element?.text ?? "", categoryName:elem["Category_Name"].element?.text ?? "",shortName:elem["Short_Name"].element?.text ?? "")
                        self.arrayExistingCategory.append(exeCategory)
                        
                    }
                    
                    print(self.arrayExistingCategory)
                    self.arrayCPDYear.removeAll()
                    for elem in xml["soap:Envelope"]["soap:Body"]["TrainingSummaryResponse"]["TrainingSummaryResult"]["FinancialYear"]["SelectListItem"].all {
                        let finYear = DashboardCPDYearModel(disabled:elem["Disabled"].element?.text ?? "", group: elem.pasredString(key: "Group"),selected:elem["Selected"].element?.text ?? "",text:elem["Text"].element?.text ?? "",value:elem["Value"].element?.text ?? "")
                        
                        self.arrayCPDYear.append(finYear)
                    }
                    
                    
                    self.updateMyCategory(arrayMycategory: self.arrayMyCategory, arrayExistingcategory: self.arrayExistingCategory, arrayCPDYear: self.arrayCPDYear)
                    print(self.arrayCPDYear)
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    func callWebServiceToDownloadTheReport(user:User,CPDYear:String,completion: @escaping(String?,String)-> Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dow="http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <dow:DownloadTrainingReport>
        <dow:finYear>\(CPDYear)</dow:finYear>
        <dow:userEmail>\(user.emailAddress ?? "")</dow:userEmail>
        <dow:user_Id>\(user.userId ?? "")</dow:user_Id>
        <dow:stateShortName>\(user.stateEnrolledShortName ?? "")</dow:stateShortName>
        </dow:DownloadTrainingReport>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.DownloadAndEmailService.downloadTrainingReportService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.DownloadAndEmailService.downloadTrainingReportsoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(nil,error.debugDescription)
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["Message"].element?.text ?? ""
                let documentUrl = xml["soap:Envelope"]["soap:Body"]["DownloadTrainingReportResponse"]["DownloadTrainingReportResult"]["DocumentUrl"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    completion(documentUrl,message)
                    
                    
                    
                }else {
                    completion(nil,message)
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
    
    
    func callWebServiceToEmailTheReport(user:User,CPDYear:String,completion: @escaping(String?,String)-> Void){
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dow="http://www.lexnarro.com.au/services/DownloadAndEmailService.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <dow:EmailTrainingReport>
        <dow:finYear>\(CPDYear)</dow:finYear>
        <dow:userEmail>\(user.emailAddress ?? "")</dow:userEmail>
        <dow:user_Id>\(user.userId ?? "")</dow:user_Id>
        <dow:stateShortName>\(user.stateEnrolledShortName ?? "")</dow:stateShortName>
        </dow:EmailTrainingReport>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.DownloadAndEmailService.emailTrainingReportService) else{return}
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        CommonFunctions.showLoader()
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.DownloadAndEmailService.emailTrainingReportSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(nil,error.debugDescription)
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                let status = xml["soap:Envelope"]["soap:Body"]["EmailTrainingReportResponse"]["EmailTrainingReportResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["EmailTrainingReportResponse"]["EmailTrainingReportResult"]["Message"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: self)
                    
                    
                }else {
                    completion(nil,message)
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                    
                }
                
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
}
