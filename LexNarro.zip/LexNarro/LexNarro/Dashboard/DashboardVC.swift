//
//  DashboardVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 23/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash
import PDFKit



class DashboardVC: UIViewController {
    @IBOutlet weak var collectionVw: UICollectionView!
    private var startingScrollingOffset = CGPoint.zero
    @IBOutlet weak var lblEnrolledState: UILabel!
    @IBOutlet weak var lblRemainingDays: UILabel!
    @IBOutlet weak var pageControl: CustomPageControl!
    @IBOutlet weak var constraintVerticalSpacingLblAndpgcntrl: NSLayoutConstraint!
    @IBOutlet weak var constraintVCenter: NSLayoutConstraint!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var btnCPDYear: UIButton!
    @IBOutlet weak var collectionViewConstraintHeight: NSLayoutConstraint!
    
    var objSideMenuVC: SideMenuController?
    var subCategory = [SubCategory]()
    var arrayMyCategory = [DashboardCategoryModel]()
    var arrayExistingCategory = [DashboardExistingCategoryModel]()
    var arrayCPDYear = [DashboardCPDYearModel]()
    var pageNumber:Int = 0
    var numberOfRows = 0
    var currentCPDYear = ""
    var selectedIndex = 0
    var CPDYear:DashboardCPDYearModel?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let rect = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 40)
        let vw = UIView(frame: rect)
        vw.backgroundColor = UIColor.red
        
        //  UIApplication.shared.st
        //UIStatusBarAnimation.fade
        
        currentCPDYear = CommonFunctions.calCulateCPDYear(date1: Date())
        
        let email = User.fetchCurrentUser()?.emailAddress ?? ""
        let enrolledState = User.fetchCurrentUser()?.stateEnrolledShortName ?? ""
        
        lblEnrolledState.text = enrolledState
        let width =  self.collectionVw.bounds.width
        let height = width + 20
        collectionViewConstraintHeight.constant = height
        btnCPDYear.setTitle(currentCPDYear, for: .normal)
        let remainingDays = CommonFunctions.calCulateRemainingDays()
        lblRemainingDays.text = "\(remainingDays) days remaining to complete your units"
        if UIDevice().name == "iPhone 5s" ||  UIDevice().name == "iPhone 5" || UIDevice().name == "iPhone 5c"  || UIDevice().name == "iPhone SE" {
            constraintVCenter.constant = 0
            constraintVerticalSpacingLblAndpgcntrl.constant = 8
        }
        //print(UIDevice().model)
        self.callWebserviceToDashBoardDetails(username:  email , CPDYear: currentCPDYear)
        
        collectionVw.reloadData()
        pageControl.addTarget(self, action: #selector(pageControlTapHandler(sender:)), for: .touchUpInside)
        
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.barTintColor = UIColor.black
        NotificationCenter.default.addObserver(self, selector: #selector(refereshData), name: Notification.Name(LexNotification.RefereshData), object: nil)
        
    }
    
    
    
    @objc func refereshData(){
        let email = User.fetchCurrentUser()?.emailAddress ?? ""
        NotificationCenter.default.removeObserver(self, name: Notification.Name(LexNotification.RefereshData), object: nil)
        self.callWebserviceToDashBoardDetails(username:  email , CPDYear: currentCPDYear)
        
    }
    
    @IBAction func panGestureAction(_ sender: Any) {
        
    }
    
    @IBAction func OpenSideMenuAction(_ sender: Any) {
        UIView.animate(withDuration:0.9,
                       delay: 0.2,
                       usingSpringWithDamping: 0.6,
                       initialSpringVelocity: 0.2,
                       options: .curveEaseIn,
                       animations: {
                        //Do all animations here
                        self.objSideMenuVC?.slideMenuItemSelectedAtIndex(0)
        }, completion: {
            //Code to run after animating
            (value: Bool) in
        })
        
    }
    
    @IBAction func btnCPDYearAction(_ sender: Any) {
        // get a reference to the view controller for the popover
        if arrayCPDYear.count <= 0{
            CommonFunctions.showAlertMessage(title: nil, message: "No Previous CPD Years are available.", viewController: self)
            return
        }
        let email = User.fetchCurrentUser()?.emailAddress ?? ""
        
        let btn = sender as! UIButton
        let pickerPopupVC = PickerPopupVC.instantiate(fromAppStoryboard: .Popup)
        // let data = ["2018-2019"]
        pickerPopupVC.selectedIndex = selectedIndex
        pickerPopupVC.showPickerForData(data: arrayCPDYear) {[unowned self] (selectedData,selectedIndex)  in
            self.CPDYear  = selectedData as? DashboardCPDYearModel
            self.selectedIndex = selectedIndex
            self.currentCPDYear = self.CPDYear?.value ?? ""
            btn.setTitle(self.CPDYear?.value ?? "", for: .normal)
            self.callWebserviceToDashBoardDetails(username: email, CPDYear: self.CPDYear?.value ?? "")
        }
        // pickerPopupVC.delegate = self
        self.present(pickerPopupVC, animated: true, completion: nil)
        
    }
    @IBAction func btnCreateNewRecordAction(_ sender: Any) {
        let openRecordDetails = CreateNewRecordVC.instantiate(fromAppStoryboard: .LeftMenu)
        self.navigationController?.pushViewController(openRecordDetails, animated: true)
        
    }
    @IBAction func btnDownloadAction(_ sender: Any) {
        let user = User.fetchCurrentUser()
        
        let alertController = UIAlertController(title: "DOWNLOAD/EMAIL", message: "Please select what you want to do?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Download", style: .default, handler: { (action) in
            self.callWebServiceToDownloadTheReport(user: user!, CPDYear:self.CPDYear?.value ?? "" ) {[unowned self] (pdfUrl, message) in
                
                OperationQueue.main.addOperation({
                    if let pdf_url =  pdfUrl{
                        let vc = ViewReportVC.instantiate(fromAppStoryboard: .Dashboard)
                        vc.urlString = pdf_url
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                })
            }
        }))
        alertController.addAction(UIAlertAction(title: "Email", style: .default, handler: { (action) in
            self.callWebServiceToEmailTheReport(user: user!, CPDYear: self.CPDYear?.value ?? "") { (pdfUrl, message) in
                
            }
        }))
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
            
        }))
        
        self.present(alertController, animated: true, completion: nil)
        //
        
    }
    
    func openMyRecordsRecord()  {
        let storyboard = UIStoryboard(name: "LeftMenu", bundle: Bundle.main)
        
        let myRecordsNavVC = storyboard.instantiateViewController(withIdentifier: "MyRecordsNavVC")
        self.present(myRecordsNavVC, animated: false, completion: nil)
        
    }
    
    @IBAction func btnJoinAction(_ sender: Any) {
    }
    
    @IBAction func btnViewAction(_ sender: Any) {
        self .openMyRecordsRecord()
    }
    @objc func pageControlTapHandler(sender:UIPageControl) {
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        
        print("currentPage:", sender.currentPage) //currentPage: 1
        pageControl.currentPage = sender.currentPage
        let indxPath = IndexPath(item: sender.currentPage, section: 0)
        collectionVw.selectItem(at: indxPath, animated: true, scrollPosition: .right)
    }
    
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    
    
    func updateMyCategory(arrayMycategory:[DashboardCategoryModel],arrayExistingcategory:[DashboardExistingCategoryModel], arrayCPDYear:[DashboardCPDYearModel]){
        
        OperationQueue.main.addOperation {
            
            CommonFunctions().objAppdelegate.CPDYear = arrayCPDYear
            for (indx,finY) in arrayCPDYear.enumerated() {
                
                let isSelected = Bool(finY.selected) ?? false
                
                if isSelected{self.selectedIndex =  indx;
                    CommonFunctions().objAppdelegate.selectedCPDYear = finY
                    self.CPDYear = finY
                    break}
            }
            print(self.selectedIndex)
            
            self.pageControl.numberOfPages = arrayMycategory.count + 1
            self.numberOfRows = arrayMycategory.count + 1
            
            for (index,_) in arrayExistingcategory.enumerated(){
                print("ProgressSubCategoryCell1\(index)")
                let nib = UINib(nibName: "ProgressSubCategoryCell1", bundle: nil)
                
                self.collectionVw.register(nib, forCellWithReuseIdentifier: "ProgressSubCategoryCell1\(index)")
                
            }
            
            self.collectionVw.reloadData()
        }
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension DashboardVC: UICollectionViewDataSource{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionVw{
            return numberOfRows
        }else{
            return arrayMyCategory.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collectionVw{
            if indexPath.row == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProgressCell", for: indexPath) as! ProgressCell
                cell.loadData(target: self, cattegory: arrayMyCategory[indexPath.row], existingCategory: arrayExistingCategory, categoryCount: arrayMyCategory.count)
                return cell
                
            }else{
                let identifier = "ProgressSubCategoryCell1" + "\(indexPath.row-1)"
                
                let cell = self.collectionVw.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! ProgressSubCategoryCell1
                print(arrayExistingCategory[indexPath.row-1])
                
                cell.updateData(subCat: arrayExistingCategory[indexPath.row-1] )
                return cell
                
            }
        }else{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SubCategoryShortCell", for: indexPath) as! SubCategoryShortCell
            cell.loadData(target: self, cattegory: arrayMyCategory[indexPath.row], execCategory: arrayExistingCategory[indexPath.row])
            return cell
            
        }
        
    }
}

extension DashboardVC:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == collectionVw {
            let pageWidth:CGFloat = collectionView.frame.size.width
            let backgroundViewHeight = backgroundView.frame.size.height
            collectionViewConstraintHeight.constant = backgroundViewHeight - 120
            return CGSize(width: pageWidth, height: backgroundViewHeight - 120)
            
        }else{
            
            return CGSize(width: CGFloat(40), height: 66)
            
        }
    }
}
//
extension DashboardVC:UIScrollViewDelegate{
    
    func scrollViewDidScrollToTop(_ scrollView: UIScrollView) {
        
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
        print(velocity.x)
        print(velocity.y)
        
        let pageWidth:Float = Float(collectionVw.frame.size.width)
        
        let currentOffSet:Float = Float(scrollView.contentOffset.x)
        
        print(currentOffSet)
        
        let targetOffSet:Float = Float(targetContentOffset.pointee.x)
        
        print(targetOffSet)
        var newTargetOffset:Float = 0
        
        if(targetOffSet > currentOffSet){
            newTargetOffset = ceilf(currentOffSet / pageWidth) * pageWidth
        }else{
            newTargetOffset = floorf(currentOffSet / pageWidth) * pageWidth
        }
        
        if(newTargetOffset < 0){
            newTargetOffset = 0;
        }else if (newTargetOffset > Float(scrollView.contentSize.width)){
            newTargetOffset = Float(scrollView.contentSize.width)
        }
        
        targetContentOffset.pointee.x = CGFloat(currentOffSet)
        
        print(CGFloat(newTargetOffset)/CGFloat(pageWidth))
        pageNumber =  Int(CGFloat(newTargetOffset)/CGFloat(pageWidth))
        pageControl.currentPage = pageNumber
        
        scrollView.setContentOffset(CGPoint(x: CGFloat(newTargetOffset), y: 0), animated: true)
    }
}

extension DashboardVC: UIDocumentInteractionControllerDelegate{
    func documentInteractionControllerDidEndPreview(_ controller: UIDocumentInteractionController) {
        
    }
    func documentInteractionControllerWillBeginPreview(_ controller: UIDocumentInteractionController) {
        
    }
}

