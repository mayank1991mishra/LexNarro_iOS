//
//  ProgressSubCategoryCell1.swift
//  LexNarro
//
//  Created by Anand Awasthi on 28/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class ProgressSubCategoryCell1: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
    @IBOutlet weak var viewProgrss: CircularProgressViewWithPercentage!
    @IBOutlet weak var lblMinimumUnit: UILabel!
    @IBOutlet weak var lblCompletedUnit: UILabel!
    @IBOutlet weak var lblSubCategoryTitle: UILabel!
    @IBOutlet weak var lblUnits: UILabel!
    @IBOutlet weak var lblShortName: UILabel!
    var unitsDone:Float!
    @IBOutlet weak var viewInnerProgressDetails: UIView!
    
    
    override func draw(_ rect: CGRect) {
        self.lblMinimumUnit.layer.cornerRadius = 15.0
    }
    
    func updateData(subCat:DashboardExistingCategoryModel){
        self.lblMinimumUnit.layer.cornerRadius = 15.0
        
        unitsDone = Float(subCat.unitsDone) ?? 0.0
        
        lblSubCategoryTitle.text = subCat.categoryName
        print(subCat.categoryName)
        lblCompletedUnit.text = "\(subCat.unitsDone) units completed"
        lblShortName.text = "\(subCat.shortName)"
        //lblUnits.text = "\(Int(unitsDone))/1"
        if unitsDone == Float(0.0) {
            self.lblUnits.text = "0/1"
        }else{
            showProgressUnit(totalCategoryDone: unitsDone)
        }
        
        if unitsDone >= 1.0 {
            viewProgrss.progress = 100
        }else if  unitsDone == 0.5{
            viewProgrss.progress = 50
        }else{
            viewProgrss.progress = 0
        }
        
        viewProgrss.animation()
    }
    
    func showProgressUnit(totalCategoryDone:Float)  {
        
        let totalCategory = "\(totalCategoryDone)"
        let arrayUnitsDone = totalCategory.components(separatedBy: ".")
        let totalUnits = Int(arrayUnitsDone.first ?? "1")!
        let halfUnit = Int(arrayUnitsDone.last ?? "0")!
        
        if totalUnits == 0 {
            self.lblUnits.text = "0/1"
        }else{
            for x in 1...totalUnits{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4 * Double(x) ) {
                    self.lblUnits.text = "\(x)/1"
                    if x == totalUnits && (halfUnit == 5){
                        self.lblUnits.text = "\(x).\(halfUnit)/1.0"
                    }
                }
            }
            
        }
    }
}

struct SubCategory {
    var progressPercentage: CGFloat
    var totalUnits: Int
    var completedUnits: Int
    var subCategoryTitle:String
    var minimumUnits:Int
    
    init(progressPercentage: CGFloat,totalUnits: Int,completedUnits: Int,subCategoryTitle:String,minimumUnits:Int) {
        self.progressPercentage = progressPercentage
        self.totalUnits = totalUnits
        self.completedUnits = completedUnits
        self.minimumUnits = minimumUnits
        self.subCategoryTitle = subCategoryTitle
    }
}
