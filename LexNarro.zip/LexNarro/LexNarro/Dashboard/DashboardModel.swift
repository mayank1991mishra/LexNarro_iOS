//
//  DashboardModel.swift
//  LexNarro
//
//  Created by Anand Awasthi on 09/06/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation

struct DashboardCategoryModel {
    var categoryId:String
    var shortName:String
    var categoryName:String

}


struct DashboardExistingCategoryModel {
    var categoryId:String
    var unitsDone:String
    var CPDYear:String
    var categoryName:String
    var shortName:String
}


struct DashboardCPDYearModel {
    var disabled:String
    var group:String
    var selected:String
    var text:String
    var value:String
}
