//
//  ProgressCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 23/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class ProgressCell: UICollectionViewCell {
    @IBOutlet weak var viewProgressBar: CircularProgressViewWithPercentage!
    @IBOutlet weak var lblUnits: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var constraintShortCellWidth: NSLayoutConstraint!
    @IBOutlet weak var lblShortName: UILabel!
    @IBOutlet weak var lblCompletedUnits: UILabel!
    @IBOutlet weak var lblCompletedCategory: UILabel!
    @IBOutlet weak var imgViewChecked: UIImageView!
    var timer:Timer?
    
    
    func loadData(target:DashboardVC,cattegory:DashboardCategoryModel, existingCategory:[DashboardExistingCategoryModel],categoryCount:Int){
        
        var totalCategoryDone:Float = 0.0
        let totalExecCategory:Int = existingCategory.count
        var completedCategory:Int = 0
        for execCategory in existingCategory {
            let unitsDone:Float = Float(execCategory.unitsDone) ?? 0.0
            
            totalCategoryDone += unitsDone
            if unitsDone >= Float(1.0){
                completedCategory += 1
            }
        }
        
        showProgressUnit(totalCategoryDone: totalCategoryDone)
        lblUnits.text = "\(totalCategoryDone) units completed"
        lblCompletedCategory.text = "\(completedCategory)/\(totalExecCategory) Cats Completed"
        let progress = (totalCategoryDone/10.0)*100.0
        showProgressPercentage(target: target, progress: progress, categoryCount: categoryCount)
    }
    
    func showProgressPercentage(target:DashboardVC,progress:Float,categoryCount:Int)  {
        viewProgressBar.progress = CGFloat(progress)
        viewProgressBar.animation()
        
        print(self.frame.size.width)
        print(viewProgressBar.frame.size.width)
        let cellWidth:CGFloat = viewProgressBar.frame.size.width - 20
        print(cellWidth)
        let wdConstatnt = CGFloat((40+15) * CGFloat(categoryCount))
        
        print(wdConstatnt)
        constraintShortCellWidth.constant =  cellWidth >= wdConstatnt ? wdConstatnt  : cellWidth
        collectionView.isUserInteractionEnabled = cellWidth >= wdConstatnt  ? false : true
        collectionView.isScrollEnabled = cellWidth >= wdConstatnt  ? false : true
        
        collectionView.showsHorizontalScrollIndicator = cellWidth >= wdConstatnt  ? false : true
        
        collectionView.dataSource = target
        collectionView.reloadData()

    }
    
    func showProgressUnit(totalCategoryDone:Float)  {
        
        let totalCategory = "\(totalCategoryDone)"
        let arrayUnitsDone = totalCategory.components(separatedBy: ".")
        let totalUnits = Int(arrayUnitsDone.first ?? "1")!
        let halfUnit = Int(arrayUnitsDone.last ?? "0")!
        var count = 0

        if totalUnits == 0 {
            self.lblCompletedUnits.text = "0/10"
        }else{
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true, block: { (timer) in
                OperationQueue.main.addOperation({
                    count += 1
                    self.lblCompletedUnits.text = "\(count)/10"
                    if count == totalUnits && (halfUnit == 5){
                        self.lblCompletedUnits.text = "\(count).\(halfUnit)/10.0"
                        timer.invalidate()
                    }else if count == totalUnits{
                        timer.invalidate()
                    }
                })
                
                print(timer)
            })
            timer?.fire()
        }
    }
}
