//
//  ProgressCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 23/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class ProgressCell1: UICollectionViewCell {
    @IBOutlet weak var viewProgressBar: CircularProgressViewWithPercentage!
    @IBOutlet weak var lblUnits: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var constraintShortCellWidth: NSLayoutConstraint!
  //  @IBOutlet weak var lblShortName: UILabel!
    @IBOutlet weak var lblCompletedUnits: UILabel!
    @IBOutlet weak var lblCompletedCategory: UILabel!
   // @IBOutlet weak var imgViewChecked: UIImageView!
    
    func loadData(target:DashboardVC,cattegory:DashboardCategoryModel, existingCategory:[DashboardExistingCategoryModel],categoryCount:Int){
        
        // lblCompletedUnits.text = "\(existingCa)"
        var totalCategoryDone:Float = 0.0
        let totalExecCategory:Int = existingCategory.count
        var completedCategory:Int = 0
        
        
        for execCategory in existingCategory {
            let unitsDone:Float = Float(execCategory.unitsDone) ?? 0.0
            
            totalCategoryDone += unitsDone
            if unitsDone >= Float(1.0){
                completedCategory += 1
            }
        }
        // lblCompletedUnits.text = "\(totalCategoryDone)/10.0"
        lblUnits.text = "\(totalCategoryDone) units completed"
        lblCompletedCategory.text = "\(completedCategory)/\(totalExecCategory) Cats Completed"
        self.showProgressUnit(totalCategoryDone: totalCategoryDone)
        let progress = (totalCategoryDone/10.0)*100.0
        viewProgressBar.progress = CGFloat(progress)
        viewProgressBar.animation()
        
        print(self.frame.size.width)
        print(viewProgressBar.frame.size.width)
        let cellWidth:CGFloat = viewProgressBar.frame.size.width - 20
        print(cellWidth)
        let wdConstatnt = CGFloat((40+15) * CGFloat(categoryCount))
        
        print(wdConstatnt)
        constraintShortCellWidth.constant =  cellWidth >= wdConstatnt ? wdConstatnt  : cellWidth
        collectionView.isUserInteractionEnabled = cellWidth >= wdConstatnt  ? false : true
        collectionView.isScrollEnabled = cellWidth >= wdConstatnt  ? false : true
        
        collectionView.showsHorizontalScrollIndicator = cellWidth >= wdConstatnt  ? false : true
        
        collectionView.dataSource = target
        collectionView.reloadData()
    }
    
    func showProgressUnit(totalCategoryDone:Float)  {
        
        let totalCategory = "\(totalCategoryDone)"
        let arrayUnitsDone = totalCategory.components(separatedBy: ".")
        let totalUnits = Int(arrayUnitsDone.first ?? "1")!
        let halfUnit = Int(arrayUnitsDone.last ?? "0")!
        
        if totalUnits == 0 {
            self.lblCompletedUnits.text = "0/10"
        }else{
            for x in 1...totalUnits{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.48 * Double(x) ) {
                    self.lblCompletedUnits.text = "\(x)/10"
                    if x == totalUnits && (halfUnit == 5){
                        self.lblCompletedUnits.text = "\(x).\(halfUnit)/10.0"
                    }
                }
            }
            
        }
    }
}
