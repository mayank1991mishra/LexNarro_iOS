//
//  SubscriptionVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 26/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit
import SWXMLHash
import StoreKit

struct SubscriptionPlan {
    var planID:String
    var plan:String
    var rateId:String
    var amount:String
    
    init(planID:String,plan:String,rateId:String,amount:String) {
       self.planID = planID
        self.plan = plan
        self.rateId = rateId
        self.amount = amount
    }
    
}

class SubscriptionVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    
    var arrayPlans = [SubscriptionPlan]()
    let productIds = ["lex.narro.free","Lex.Narro.yearly","Lex.narro.twoyearly"]
    var dataFromService:Bool = true
    var products:[SKProduct]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        CommonFunctions.showLoader("Fetching in-app products...")
        IAPHandler.shared.setProductIds(ids: self.productIds)
        IAPHandler.shared.fetchAvailableProducts {[unowned self] (products) in
            print(products)
            var yearSubs: SubscriptionPlan!
            for prod in products{
                print("\(prod.localizedTitle) :  \(prod.price) \(prod.priceLocale)")
                self.products = products
                if prod.productIdentifier == "Lex.Narro.yearly"{
                let currency = prod.priceLocale.currencySymbol
                 yearSubs =   SubscriptionPlan(planID: "27", plan: "Yearly", rateId: "31", amount: "\(currency ?? "")\(prod.price) ")
                self.arrayPlans.append(yearSubs)
                }
            }
            self.dataFromService = false
            self.tblView.tableFooterView = UIView()
            self.tblView.reloadData()
            CommonFunctions.hideLoader()
        }
        
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func callPaymentService(plan:SubscriptionPlan, transact:SKPaymentTransaction){
        if !CommonFunctions.checkInternetConnection() {
            CommonFunctions.hideLoader();
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
            return
        }
        
        let email = User.fetchCurrentUser()!.emailAddress!
        let payerId = User.fetchCurrentUser()!.userId!

        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:user="http://www.lexnarro.com.au/services/UserTransaction.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <user:PostTransaction>
         <!--Optional:-->
         <user:email>\(email)</user:email>
         <!--Optional:-->
         <user:Plan_ID>\(plan.planID)</user:Plan_ID>
         <!--Optional:-->
         <user:payerId>\(payerId)</user:payerId>
         <!--Optional:-->
         <user:Rate_Id>\(plan.rateId)</user:Rate_Id>
         <!--Optional:-->
         <user:paymentId>\(transact.transactionIdentifier ?? "")</user:paymentId>
         <!--Optional:-->
         <user:Amount>\(plan.amount)</user:Amount>
         <!--Optional:-->
         <user:Transection_ID>\(transact.transactionIdentifier ?? "")</user:Transection_ID>
        </user:PostTransaction>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.UserTransaction.postTransactionService) else{CommonFunctions.hideLoader(); return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.UserTransaction.postTransactionSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                print(xml)
                
                let status = xml["soap:Envelope"]["soap:Body"]["PostTransactionResponse"]["PostTransactionResult"]["Status"].element?.text ?? ""
                let message = xml["soap:Envelope"]["soap:Body"]["PostTransactionResponse"]["PostTransactionResult"]["Message"].element?.text ?? ""
                
                
                if (status == "Success")  || (status == "SUCCESS") {
                    
                    CommonFunctions.showAlertMessage(title: "Success", message: "Thank you purchasing the \(plan.plan) plan.", viewController: self)
                    
                }else {
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
                }
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
//
//    func callWebserviceGetPlan(){
//        if !CommonFunctions.checkInternetConnection() {
//            CommonFunctions.hideLoader();
//            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: self)
//            return
//        }
//       // CommonFunctions.showLoader()
//        let soapMessage = """
//        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:plan="http://www.lexnarro.com.au/services/PlanMaster.asmx">
//        <soapenv:Header/>
//        <soapenv:Body>
//        <plan:GetPlans/>
//        </soapenv:Body>
//        </soapenv:Envelope>
//        """
//        guard let url = URL(string: LexString.WebService.PlanMaster.getPlanService) else{CommonFunctions.hideLoader(); return}
//
//        let contentLength = String(soapMessage.count)
//        var urlRequest = URLRequest(url: url)
//        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
//
//        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
//        urlRequest.addValue(LexString.WebService.PlanMaster.getPlanSoapAction, forHTTPHeaderField: "SOAPAction")
//        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
//        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
//        urlRequest.httpMethod = "POST"
//
//        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
//
//            self.dataFromService = true
//            if error != nil{
//                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: self)
//            }
//            else if data != nil{
//
//
//                let backToString = String(data: data!, encoding: String.Encoding.utf8)
//
//                let xml = SWXMLHash.parse(backToString!)
//                let status = xml["soap:Envelope"]["soap:Body"]["GetPlansResponse"]["GetPlansResult"]["Status"].element?.text ?? ""
//                let message = xml["soap:Envelope"]["soap:Body"]["GetPlansResponse"]["GetPlansResult"]["Message"].element?.text ?? ""
//
//
//                if (status == "Success")  || (status == "SUCCESS") {
//
//                    for elem in xml["soap:Envelope"]["soap:Body"]["GetPlansResponse"]["GetPlansResult"]["Plans"]["PlanList"].all {
//                        let subscrip = SubscriptionPlan(planID: elem["Plan_ID"].element?.text ?? "", plan: elem["Plan"].element?.text ?? "", rateId: elem["Rate_Id"].element?.text ?? "", amount: elem["Amount"].element?.text ?? "")
//
//                        self.arrayPlans.append(subscrip)
//                    }
//                   // self.arrayPlans.removeLast()
//
//                    print(self.arrayPlans)
//
//                    OperationQueue.main.addOperation({
//                        self.tblView.reloadData()
//                    })
//
//                }else {
//                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: self)
//
//                }
//
//            }
//            CommonFunctions.hideLoader()
//        }
//        task.resume()
//
//    }
    
    func initiatePayment(prod:SKProduct,plan:SubscriptionPlan)  {
        if IAPHandler.shared.canMakePurchases(){
            CommonFunctions.showLoader()
            
            IAPHandler.shared.purchase(product: prod) {[unowned self] (iapHandlerAlertType, skProd, skTransaction) in
               
                if let transact = skTransaction,  iapHandlerAlertType == .purchased {
                    
                    self.callPaymentService(plan: plan, transact: transact)
                }else{
                    print("failed")
                   CommonFunctions.hideLoader()
                }
            }
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension SubscriptionVC:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrayPlans.isEmpty {
            let lbl = CommonFunctions.addEmptyMessageLablel(text: "No subscription plan available for you ", dataFromService: dataFromService)
            tableView.backgroundView = lbl
            return 0
        }
        tableView.backgroundView = UIView()
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayPlans.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SubscriptionPlanCell", for: indexPath) as! SubscriptionPlanCell
        cell.delagate = self
        cell.loadData(plan: arrayPlans[indexPath.row])
        return cell
        
    }
    
    
}

extension SubscriptionVC:SubscriptionDelegate{
    func subscribeNow(cell:SubscriptionPlanCell) {
        guard let indexPath = tblView.indexPath(for: cell) else {return}
        let subscriptionPlan = arrayPlans[indexPath.row]
        print(subscriptionPlan)
        if let prods = self.products {
            for prod in prods{
                
                if prod.productIdentifier == "lex.narro.free" && subscriptionPlan.plan == "Demo"{
                    initiatePayment(prod: prod, plan: subscriptionPlan)
                    break
                }
                
                if prod.productIdentifier == "Lex.narro.twoyearly" && subscriptionPlan.plan == "Two Yearly"{
                    initiatePayment(prod: prod, plan: subscriptionPlan)
                    break
                }
                
                if prod.productIdentifier == "Lex.Narro.yearly" && subscriptionPlan.plan == "Yearly"{
                    initiatePayment(prod: prod, plan: subscriptionPlan)
                    break
                }
            }
        }
    }
}
