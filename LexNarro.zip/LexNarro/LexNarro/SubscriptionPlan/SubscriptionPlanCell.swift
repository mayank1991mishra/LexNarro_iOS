//
//  SubscriptionPlanCell.swift
//  LexNarro
//
//  Created by Anand Awasthi on 26/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

protocol SubscriptionDelegate:class {
    func subscribeNow(cell:SubscriptionPlanCell)
}

class SubscriptionPlanCell: UITableViewCell {
    @IBOutlet weak var lblPlan: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var btnSubscriptionNow: UIButton!
    weak var delagate:SubscriptionDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func loadData(plan:SubscriptionPlan)  {
        lblPlan.text = plan.plan
        lblAmount.text = plan.amount
        
    }
    @IBAction func btnSubscribeNowAction(_ sender: Any) {
        delagate?.subscribeNow(cell: self)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
