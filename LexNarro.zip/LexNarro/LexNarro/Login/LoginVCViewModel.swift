//
//  LoginVCViewModel.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation
import UIKit
import SWXMLHash

struct UserProfileStruct {
    var userId:String
    var firstName:String
    var lastName:String
    var otherName:String
    var streetNumber:String
    var streetName:String
    var postCode:String
    var suburb:String
    var stateID:String
    var stateName:String
    var countryID:String
    var countryName:String
    var stateEnrolledId:String
    var stateEnrolledName:String
    var stateEnrolledShortName:String
    var lawSocietyNumber:String
    var emailAddress:String
    var phoneNumber:String
    var date:String
    var device_Imei:String
    var device_Token:String
    var device_Type:String
    var accountConfirmed:String
    var activationCode :String
    var firm:String
    var password:String

}

class LoginVCViewModel: LoginVCProtocol {
    
    
    
    var username: String = ""
    var password: String = ""
    
    
    func hideSubviews(target: LoginVC) {
        donotHaveAccount(target: target)
        target.lblWelcomeCenterX.constant -= target.view.bounds.width
        target.txtFieldPasswordLeading.constant -= target.view.bounds.width
        target.txtFieldUsernameLeading.constant -= target.view.bounds.width
        target.btnForgotPasswordTrailing.constant -= target.view.bounds.width
        target.btnLogin.alpha = 0.0
        target.lblDonthaveAccount.alpha = 0.0
        target.view.layoutIfNeeded()
    }
    func addAnimationOnWelcomeLabel(target: LoginVC) {
        UIView.animate(withDuration: 0.8, delay: 0.0, options: [.transitionCurlDown], animations: {
            target.lblWelcomeCenterX.constant += target.view.bounds.width
            target.view.layoutIfNeeded()
            
        }, completion: nil)
    }
    
    func addAnimationOnTextFields(target: LoginVC) {
        UIView.animate(withDuration: 0.8, delay: 0.0, options: [.curveEaseIn], animations: {
            target.txtFieldUsernameLeading.constant += target.view.bounds.width
            target.txtFieldPasswordLeading.constant += target.view.bounds.width
            target.view.layoutIfNeeded()
            
        }, completion: nil)
    }
    
    func addAnimationOnForgotPassword(target: LoginVC) {
        UIView.animate(withDuration: 0.8, delay: 0.0, options: [], animations: {
            target.btnForgotPasswordTrailing.constant += target.view.bounds.width
            target.view.layoutIfNeeded()
        }, completion: { (status) in
            target.btnLogin.alpha = 1.0
            target.lblDonthaveAccount.alpha = 1.0
            target.view.layoutIfNeeded()
        })
    }
    
    func addAnimationOnLoginButton(target: LoginVC) {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 3
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: target.btnLogin.center.x - 10, y: target.btnLogin.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: target.btnLogin.center.x + 10, y: target.btnLogin.center.y))
        target.btnLogin.layer.add(animation, forKey: "position")
    }
    
    func validateUsername(target: LoginVC) -> Bool {
        var isValidate = false
        
        if target.txtFieldUserName.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func validatePassword(target: LoginVC) -> Bool {
        var isValidate = false
        
        if target.txtFieldPassword.text!.isEmpty{
            isValidate = false
        }else{
            isValidate = true
        }
        
        return isValidate
    }
    
    func doLogin(target: LoginVC, username:String, password:String) {
        if !validateUsername(target: target) {
            target.btnLogin.isEnabled = false

            target.txtFieldUserName.shakeTextField(errorMessage: "Username can not be empty!") { (status) in
                target.btnLogin.isEnabled = true
            }
            
            addAnimationOnLoginButton(target: target)
        }else if !validatePassword(target: target){
            target.btnLogin.isEnabled = false
            target.txtFieldPassword.shakeTextField(errorMessage: "Password can not be empty!") { (status) in
                target.btnLogin.isEnabled = true
            }
            addAnimationOnLoginButton(target: target)
        }else{
            //// Login Success
            
           // KVNProgress.show(withStatus: "Logging In...")
            if !CommonFunctions.checkInternetConnection() {
                CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
                return
            }
            CommonFunctions.showLoader()
            
            let deviceToken = UserDefaults.standard.object(forKey: Constants.kDeviceToken) as! String

            let soapMessage = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lex=\"http://www.lexnarro.com.au/services/Login.asmx\">\n" +
                "<soapenv:Header/>\n" +
                "<soapenv:Body>\n" +
                "<lex:UserLogin>\n" +
                "<lex:User_Name>\(username)</lex:User_Name>\n" +
                "<lex:Password>\(password)</lex:Password>\n" +
                "<lex:Device_Imei>66656</lex:Device_Imei>\n" +
                "<lex:Device_Token>\(deviceToken)</lex:Device_Token>\n" +
                "<lex:Device_Type>iOS</lex:Device_Type>\n" +
                "</lex:UserLogin>\n" +
                "</soapenv:Body>\n" +
            "</soapenv:Envelope>\n"
            
            callWebServiceToLogin(soapMessage: soapMessage, target: target) { (message) in
                print(message)
            }
            
            
        }
        
    }
    
    
    func callWebServiceToLogin(soapMessage:String,target:LoginVC,completion:@escaping (String) -> Void){
        
        if !CommonFunctions.checkInternetConnection() {
            
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        print(soapMessage)
        guard let url = URL(string: LexString.WebService.Login.service) else{return}
        CommonFunctions.showLoader()
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.Login.soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                completion(error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                
                let message = xml["soap:Envelope"]["soap:Body"]["UserLoginResponse"]["UserLoginResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["UserLoginResponse"]["UserLoginResult"]["Status"].element?.text ?? ""
                if status == "Success" || status == "SUCCESS"{
                    
                    OperationQueue.main.addOperation({
                        let profileD = xml["soap:Envelope"]["soap:Body"]["UserLoginResponse"]["UserLoginResult"]["Profile"]
                        
                        
                        let objUser = UserProfileStruct(userId: profileD.pasredString(key: "ID"), firstName: profileD.pasredString(key: "FirstName"), lastName: profileD.pasredString(key: "LastName"), otherName: profileD.pasredString(key: "OtherName"), streetNumber: profileD.pasredString(key: "StreetNumber"), streetName: profileD.pasredString(key: "StreetName"), postCode: profileD.pasredString(key: "PostCode"), suburb: profileD.pasredString(key: "Suburb"), stateID: profileD.pasredString(key: "StateID"), stateName: profileD.pasredString(key: "StateName"), countryID: profileD.pasredString(key: "CountryID"), countryName: profileD.pasredString(key: "CountryName"), stateEnrolledId: profileD.pasredString(key: "StateEnrolled"), stateEnrolledName: profileD.pasredString(key: "StateEnrolledName"), stateEnrolledShortName: profileD.pasredString(key: "StateEnrolledShortName"), lawSocietyNumber: profileD.pasredString(key: "LawSocietyNumber"), emailAddress: profileD.pasredString(key: "EmailAddress"), phoneNumber: profileD.pasredString(key: "PhoneNumber"), date: profileD.pasredString(key: "Date"), device_Imei: profileD.pasredString(key: "Device_Imei"), device_Token: profileD.pasredString(key: "Device_Token"), device_Type: profileD.pasredString(key: "Device_Type"), accountConfirmed: profileD.pasredString(key: "AccountConfirmed"), activationCode: profileD.pasredString(key: "ActivationCode"), firm: profileD.pasredString(key: "Firm"), password: target.txtFieldPassword.text!)
                         let userToken = xml["soap:Envelope"]["soap:Body"]["UserLoginResponse"]["UserLoginResult"]["Token"].parsedText
                        
                        User.deleteUser()
                        User.insertUser(userdata: objUser, userToken: userToken)
                            target.btnLogin.isEnabled = true
                           // CommonFunctions.hideLoader()
                        self.callPaymentService(target: target)

                    })
                    //CommonFunctions.showAlertMessage(title: "Success", message: message, viewController: target)
                    
                }else{
                    CommonFunctions.showAlertMessage(title: "Error", message: message, viewController: target)
                }
                
                completion(message)
            }
            CommonFunctions.hideLoader()
        }
        
        task.resume()
        
        
    }

    
    
    func requestForgotPassword(target: LoginVC) {
       let forgotPasswordVC = ForgotPasswordVC.instantiate(fromAppStoryboard: .Authentication)
        target.present(forgotPasswordVC, animated: true, completion: nil)
    }
    
    
    
    func donotHaveAccount(target:LoginVC){
        target.lblDonthaveAccount.isUserInteractionEnabled = true
        target.lblDonthaveAccount.text = "Don't have an Account? Signup"
        let text = (target.lblDonthaveAccount.text)!
        let signupAttriString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: "Signup")
        signupAttriString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red, range: range1)
        
        signupAttriString.addAttribute(NSAttributedString.Key.font, value: UIFont.systemFont(ofSize: 25), range: range1)
        
        let range2 = (text as NSString).range(of: "Don't have an Account? ")
        signupAttriString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.white, range: range2)
        
        signupAttriString.addAttribute(NSAttributedString.Key.font, value: UIFont.systemFont(ofSize: 20), range: range2)
        target.lblDonthaveAccount.attributedText = signupAttriString
        let  tapGestureReco = UITapGestureRecognizer(target: self, action: #selector(showSignup(tapGestureReco:)))
        target.lblDonthaveAccount.addGestureRecognizer(tapGestureReco)
    }
    
    @objc func showSignup(tapGestureReco: UITapGestureRecognizer)  {
        
    }
    
    
    
    func callPaymentService(target:LoginVC){
        if !CommonFunctions.checkInternetConnection() {
            CommonFunctions.hideLoader();
            CommonFunctions.showAlertMessage(title: "No Internet", message: "No internet connection", viewController: target)
            return
        }
        
        let email = User.fetchCurrentUser()!.emailAddress!
        let payerId = User.fetchCurrentUser()!.userId!
        let plan =   SubscriptionPlan(planID: "24", plan: "Demo", rateId: "30", amount: "0.00 AUD")

        
        let soapMessage = """
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:user="http://www.lexnarro.com.au/services/UserTransaction.asmx">
        <soapenv:Header/>
        <soapenv:Body>
        <user:PostTransaction>
        <!--Optional:-->
        <user:email>\(email)</user:email>
        <!--Optional:-->
        <user:Plan_ID>\(plan.planID)</user:Plan_ID>
        <!--Optional:-->
        <user:payerId>\(payerId)</user:payerId>
        <!--Optional:-->
        <user:Rate_Id>\(plan.rateId)</user:Rate_Id>
        <!--Optional:-->
        <user:paymentId>DEMO\(payerId)</user:paymentId>
        <!--Optional:-->
        <user:Amount>\(plan.amount)</user:Amount>
        <!--Optional:-->
        <user:Transection_ID>DEMO\(payerId)</user:Transection_ID>
        </user:PostTransaction>
        </soapenv:Body>
        </soapenv:Envelope>
        """
        guard let url = URL(string: LexString.WebService.UserTransaction.postTransactionService) else{CommonFunctions.hideLoader(); return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        //SOAPAction: "http://www.lexnarro.com.au/services/PlanMaster.asmx/GetPlans"
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(LexString.WebService.UserTransaction.postTransactionSoapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
       // CommonFunctions.showLoader()
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                CommonFunctions.showAlertMessage(title: "Error", message: error?.localizedDescription ?? "", viewController: target)
            }
            else if data != nil{
                
                
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                print(xml)
                
//                let status = xml["soap:Envelope"]["soap:Body"]["PostTransactionResponse"]["PostTransactionResult"]["Status"].element?.text ?? ""
//                let message = xml["soap:Envelope"]["soap:Body"]["PostTransactionResponse"]["PostTransactionResult"]["Message"].element?.text ?? ""
                
                OperationQueue.main.addOperation({
                    let sideMenuController =  SideMenuController.instantiate(fromAppStoryboard: .Dashboard)
                    (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController = sideMenuController
                })

               
            }
            CommonFunctions.hideLoader()
        }
        task.resume()
        
    }
}

extension UITapGestureRecognizer {
    
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        // Create instances of NSLayoutManager, NSTextContainer and NSTextStorage
        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: CGSize.zero)
        let textStorage = NSTextStorage(attributedString: label.attributedText!)
        
        // Configure layoutManager and textStorage
        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)
        
        // Configure textContainer
        textContainer.lineFragmentPadding = 0.0
        textContainer.lineBreakMode = label.lineBreakMode
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize
        
        // Find the tapped character location and compare it to the specified range
        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x,
                                          y: (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y);
        let locationOfTouchInTextContainer = CGPoint(x: (locationOfTouchInLabel.x - textContainerOffset.x),
                                                     y : (locationOfTouchInLabel.y - textContainerOffset.y))
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        
        return NSLocationInRange(indexOfCharacter, targetRange)
    }
    
}
