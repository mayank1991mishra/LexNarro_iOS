//
//  LoginVC.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    @IBOutlet weak var lblDonthaveAccount: UILabel!
    @IBOutlet weak var txtFieldUsernameLeading: NSLayoutConstraint!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtFieldPasswordLeading: NSLayoutConstraint!
    @IBOutlet weak var btnForgotPasswordTrailing: NSLayoutConstraint!
    @IBOutlet weak var lblWelcomeCenterX: NSLayoutConstraint!
    @IBOutlet weak var txtFieldUserName: TextFieldWithIcon!
    @IBOutlet weak var txtFieldPassword: TextFieldWithIcon!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        #if DEBUG
            txtFieldUserName.text = "sanjay.kr2205@gmail.com"
            txtFieldPassword.text = "12345678"
        #else
            txtFieldUserName.text = ""
            txtFieldPassword.text = ""
        #endif
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       LoginVCViewModel().hideSubviews(target: self)
    }
    

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        LoginVCViewModel().addAnimationOnWelcomeLabel(target: self)
        LoginVCViewModel().addAnimationOnTextFields(target: self)
        LoginVCViewModel().addAnimationOnForgotPassword(target: self)
        LoginVCViewModel().addAnimationOnLoginButton(target: self)
    }
    
    @IBAction func btnShowSignupAction(_ sender: Any) {
        guard let navSignupVc = self.storyboard?.instantiateViewController(withIdentifier: "navSignup") as? UINavigationController else{return}
       let signupVC = navSignupVc.viewControllers.first as? SignupVC
        signupVC?.naviagetionType = .Signup
        self.present(navSignupVc, animated: true, completion: nil)
    }
    @IBAction func btnLoginAction(_ sender: Any) {
        LoginVCViewModel().doLogin(target: self, username: txtFieldUserName.text!, password: txtFieldPassword.text!)
    }
    
    @IBAction func btnForgotPasswordAction(_ sender: Any) {
        LoginVCViewModel().requestForgotPassword(target: self)
    }
    
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
