//
//  LoginVCProtocal.swift
//  LexNarro
//
//  Created by Anand Awasthi on 21/05/19.
//  Copyright © 2019 Anand Awasthi. All rights reserved.
//

import Foundation

@objc protocol LoginVCProtocol:class {
    var username:String{get set}
    var password:String{get set}
    
    func hideSubviews(target:LoginVC)
    func addAnimationOnWelcomeLabel(target:LoginVC)
    func addAnimationOnTextFields(target:LoginVC)
    func addAnimationOnForgotPassword(target:LoginVC)
    func addAnimationOnLoginButton(target:LoginVC)
    func validateUsername(target:LoginVC) -> Bool
    func validatePassword(target: LoginVC) -> Bool
    func doLogin(target: LoginVC, username:String, password:String)
    func requestForgotPassword(target:LoginVC)
    func donotHaveAccount(target:LoginVC)

}
