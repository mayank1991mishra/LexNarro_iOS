 
/* 
Copyright (c) 2019 Syed Absar Karim https://www.linkedin.com/in/DashboardClient

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
 
import Foundation

/* Soap Client Generated from WSDL: https://lexnarro.com.au/services/dashboard.asmx?wsdl powered by http://www.wsdl2swift.com */

public class DashboardClient {

/**
    Calls the SOAP Operation: TrainingSummary with Message based on TrainingSummary Object.

    - parameter trainingSummary:  TrainingSummary Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opTrainingSummary(trainingSummary : TrainingSummary , completionHandler: (TrainingSummaryResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Dashboard.asmx\"><SOAP-ENV:Body><ns1:TrainingSummary><ns1:emailID>%@</ns1:emailID><ns1:finYear>%@</ns1:finYear></ns1:TrainingSummary></SOAP-ENV:Body></SOAP-ENV:Envelope>",trainingSummary.cpEmailID!,trainingSummary.cpFinYear!)

self.makeSoapConnection("https://lexnarro.com.au/services/dashboard.asmx", soapAction: "http://www.jajtechnologies.com/serives/Dashboard.asmx/TrainingSummary", soapMessage: soapMessage, soapVersion: "1", className:"TrainingSummaryResponse", completionHandler: { (DashboardClientObj:DashboardClientObjectBase?, error: NSError? )->Void in completionHandler(DashboardClientObj  as? TrainingSummaryResponse,error) })
 }



/**
    Private Method: Make Soap Connection.
    
    - parameter soapLocation: String.
    - soapAction: String.
    - soapMessage: String.
    - soapVersion: String (1.1 Or 1.2).
    - className: String.
    - completionHandler: Handler.
    - returns: Void.
    */
private func makeSoapConnection(soapLocation: String, soapAction: String, soapMessage: String,  soapVersion: String, className: String, completionHandler: (DashboardClientObjectBase?, NSError?) -> Void) {
        
        let request = NSMutableURLRequest(URL: NSURL(string: soapLocation)!)
        let msgLength  = String(soapMessage.characters.count)
        let data = soapMessage.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        
        request.HTTPMethod = "POST"
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        // request.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        request.HTTPBody = data
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let datastring = NSString(data: data!, encoding:NSUTF8StringEncoding) as! String
            print(datastring)
            
            //This is a temporary code where it returns the actual XML Response
            //At the moment, response parsing and mapping is under progress
            let aClass = NSClassFromString(className) as! DashboardClientObjectBase.Type
            let currentResp = aClass.newInstance()
            currentResp.xmlResponseString = "\(datastring)"
            completionHandler(currentResp, error)
            return

			//TODO: Code in progress for response parsing and mapping
			/*
            let xml = SWXMLHash.parse(datastring)
            
            let  coreElementKey = className
            
            let aClass = NSClassFromString(className) as! DashboardClientObjectBase.Type
            
            let obj = aClass
            
            let inst = obj.newInstance()
            
			var error : NSError?
            let soapFault = xml["soap:Envelope"]["soap:Body"]["soap:Fault"]
            
            if soapFault {
            
                let val =  soapFault["faultstring"].element?.text
                
                error =  NSError(domain: "soapFault", code: 0, userInfo: NSDictionary(object: val!, forKey: NSLocalizedDescriptionKey) as [NSObject : AnyObject])
            }
            
            if (error == nil) {
                for key in obj.cpKeys()  {
                    
                    let body =  xml["soap:Envelope"]["soap:Body"]
                    let val =  body[coreElementKey][key].element?.text
                    
                    inst.setValue(val, forKeyPath: "cp"+key)
                    
                    print (inst)
                }
            }
            completionHandler(inst, error)
            */

        }
        task.resume()

    }    




}
/** 
  Training Summary. 
*/
@objc(TrainingSummary)
public class TrainingSummary : DashboardClientObjectBase {


/// Email I D
var cpEmailID: String?

/// Fin Year
var cpFinYear: String?

override static func cpKeys() -> Array<String> {
return ["EmailID","FinYear"]
}
}

/** 
  Training Summary Response. 
*/
@objc(TrainingSummaryResponse)
public class TrainingSummaryResponse : DashboardClientObjectBase {


/// Training Summary Result
var cpTrainingSummaryResult: String?

override static func cpKeys() -> Array<String> {
return ["TrainingSummaryResult"]
}
}

/** 
  Data Return. 
*/
@objc(DataReturn)
public class DataReturn : DashboardClientObjectBase {


/// Categ
var cpCateg: String?

/// Exec Categ
var cpExecCateg: String?

/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// Financial Year
var cpFinancialYear: String?

override static func cpKeys() -> Array<String> {
return ["Categ","ExecCateg","Status","Message","Requestkey","FinancialYear"]
}
}

/** 
  Array Of My Category. 
*/
@objc(ArrayOfMyCategory)
public class ArrayOfMyCategory : DashboardClientObjectBase {


/// My Category
var cpMyCategory: String?

override static func cpKeys() -> Array<String> {
return ["MyCategory"]
}
}

/** 
  My Category. 
*/
@objc(MyCategory)
public class MyCategory : DashboardClientObjectBase {


/// Category I D
var cpCategoryID: Double?

/// Short Name
var cpShortName: String?

/// Category_ Name
var cpCategory_Name: String?

override static func cpKeys() -> Array<String> {
return ["CategoryID","ShortName","Category_Name"]
}
}

/** 
  Array Of Existing Category. 
*/
@objc(ArrayOfExistingCategory)
public class ArrayOfExistingCategory : DashboardClientObjectBase {


/// Existing Category
var cpExistingCategory: String?

override static func cpKeys() -> Array<String> {
return ["ExistingCategory"]
}
}

/** 
  Existing Category. 
*/
@objc(ExistingCategory)
public class ExistingCategory : DashboardClientObjectBase {


/// Category_ Id
var cpCategory_Id: Double?

/// Units_ Done
var cpUnits_Done: Double?

/// Financial_ Year
var cpFinancial_Year: String?

/// Category_ Name
var cpCategory_Name: String?

/// Short_ Name
var cpShort_Name: String?

override static func cpKeys() -> Array<String> {
return ["Category_Id","Units_Done","Financial_Year","Category_Name","Short_Name"]
}
}

/** 
  Array Of Select List Item. 
*/
@objc(ArrayOfSelectListItem)
public class ArrayOfSelectListItem : DashboardClientObjectBase {


/// Select List Item
var cpSelectListItem: String?

override static func cpKeys() -> Array<String> {
return ["SelectListItem"]
}
}

/** 
  Select List Item. 
*/
@objc(SelectListItem)
public class SelectListItem : DashboardClientObjectBase {


/// Disabled
var cpDisabled: Bool?

/// Group
var cpGroup: String?

/// Selected
var cpSelected: Bool?

/// Text
var cpText: String?

/// Value
var cpValue: String?

override static func cpKeys() -> Array<String> {
return ["Disabled","Group","Selected","Text","Value"]
}
}

/** 
  Select List Group. 
*/
@objc(SelectListGroup)
public class SelectListGroup : DashboardClientObjectBase {


/// Disabled
var cpDisabled: Bool?

/// Name
var cpName: String?

override static func cpKeys() -> Array<String> {
return ["Disabled","Name"]
}
}


/**
    A generic base class for all Objects.
*/
public class DashboardClientObjectBase : NSObject
{
    var xmlResponseString: String?

    class func cpKeys() -> Array <String>
    {
        return []
    }
    
    required override public init(){}
  
    class func newInstance() -> Self {
        return self.init()
    }


}
