 
/* 
Copyright (c) 2019 Syed Absar Karim https://www.linkedin.com/in/StateNameClient

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
 
import Foundation

/* Soap Client Generated from WSDL: https://lexnarro.com.au/services/states.asmx?wsdl powered by http://www.wsdl2swift.com */

public class StateNameClient {

/**
    Calls the SOAP Operation: GetAllStates with Message based on GetAllStates Object.

    - parameter getAllStates:  GetAllStates Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
    public func opGetAllStates(getAllStates : GetAllStates , completionHandler: @escaping (GetAllStatesResponse?, Error?) -> Void) {

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetAllStates><ns1:countryId>%@</ns1:countryId></ns1:GetAllStates></SOAP-ENV:Body></SOAP-ENV:Envelope>",getAllStates.cpCountryId!)

        self.makeSoapConnection(soapLocation: "https://lexnarro.com.au/services/states.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetAllStates", soapMessage: soapMessage, soapVersion: "1", className:"GetAllStatesResponse", completionHandler: { (StateNameClientObj:StateNameClientObjectBase?, error: NSError? )->Void in completionHandler(StateNameClientObj  as? GetAllStatesResponse,error) } as! (StateNameClientObjectBase?, Error?) -> Void)
 }

/**
    Calls the SOAP Operation: GetUserEnrolledState with Message based on GetUserEnrolledState Object.

    - parameter getUserEnrolledState:  GetUserEnrolledState Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
    public func opGetUserEnrolledState(getUserEnrolledState : GetUserEnrolledState , completionHandler: @escaping (GetUserEnrolledStateResponse?, Error?) -> Void) {

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetUserEnrolledState><ns1:User_ID>%@</ns1:User_ID></ns1:GetUserEnrolledState></SOAP-ENV:Body></SOAP-ENV:Envelope>",getUserEnrolledState.cpUser_ID!)

        self.makeSoapConnection(soapLocation: "https://lexnarro.com.au/services/states.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetUserEnrolledState", soapMessage: soapMessage, soapVersion: "1", className:"GetUserEnrolledStateResponse", completionHandler: { (StateNameClientObj:StateNameClientObjectBase?, error: NSError? )->Void in completionHandler(StateNameClientObj  as? GetUserEnrolledStateResponse,error) } as! (StateNameClientObjectBase?, Error?) -> Void)
 }



/**
    Private Method: Make Soap Connection.
    
    - parameter soapLocation: String.
    - soapAction: String.
    - soapMessage: String.
    - soapVersion: String (1.1 Or 1.2).
    - className: String.
    - completionHandler: Handler.
    - returns: Void.
    */
    private func makeSoapConnection(soapLocation: String, soapAction: String, soapMessage: String,  soapVersion: String, className: String, completionHandler: @escaping (StateNameClientObjectBase?, Error?) -> Void) {
    
   
    let request = NSMutableURLRequest(url:  URL(string: soapLocation)!)
        let msgLength  = String(soapMessage.count)
    let data = soapMessage.data(using: .utf8, allowLossyConversion: false)
        
        request.httpMethod = "POST"
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        // request.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        request.httpBody = data
        
    let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
        
        
        
        let datastring = String(data: data!, encoding: String.Encoding.utf8)
            print(datastring)
            
            //This is a temporary code where it returns the actual XML Response
            //At the moment, response parsing and mapping is under progress
            let aClass = NSClassFromString(className) as! StateNameClientObjectBase.Type
            let currentResp = aClass.newInstance()
            currentResp.xmlResponseString = "\(datastring)"
            completionHandler(currentResp, error)
            return

			//TODO: Code in progress for response parsing and mapping
			/*
            let xml = SWXMLHash.parse(datastring)
            
            let  coreElementKey = className
            
            let aClass = NSClassFromString(className) as! StateNameClientObjectBase.Type
            
            let obj = aClass
            
            let inst = obj.newInstance()
            
			var error : NSError?
            let soapFault = xml["soap:Envelope"]["soap:Body"]["soap:Fault"]
            
            if soapFault {
            
                let val =  soapFault["faultstring"].element?.text
                
                error =  NSError(domain: "soapFault", code: 0, userInfo: NSDictionary(object: val!, forKey: NSLocalizedDescriptionKey) as [NSObject : AnyObject])
            }
            
            if (error == nil) {
                for key in obj.cpKeys()  {
                    
                    let body =  xml["soap:Envelope"]["soap:Body"]
                    let val =  body[coreElementKey][key].element?.text
                    
                    inst.setValue(val, forKeyPath: "cp"+key)
                    
                    print (inst)
                }
            }
            completionHandler(inst, error)
            */

        }
        task.resume()

    }    




}
/** 
  Get All States. 
*/
@objc(GetAllStates)
public class GetAllStates : StateNameClientObjectBase {


/// Country Id
var cpCountryId: Double?

override static func cpKeys() -> Array<String> {
return ["CountryId"]
}
}

/** 
  Get All States Response. 
*/
@objc(GetAllStatesResponse)
public class GetAllStatesResponse : StateNameClientObjectBase {


/// Get All States Result
var cpGetAllStatesResult: String?

override static func cpKeys() -> Array<String> {
return ["GetAllStatesResult"]
}
}

/** 
  Return All States. 
*/
@objc(ReturnAllStates)
public class ReturnAllStates : StateNameClientObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// States
var cpStates: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","States"]
}
}

/** 
  Array Of State Master. 
*/
@objc(ArrayOfStateMaster)
public class ArrayOfStateMaster : StateNameClientObjectBase {


/// State Master
var cpStateMaster: String?

override static func cpKeys() -> Array<String> {
return ["StateMaster"]
}
}

/** 
  State Master. 
*/
@objc(StateMaster)
public class StateMaster : StateNameClientObjectBase {


/// Id
var cpId: Double?

/// Name
var cpName: String?

/// Short Name
var cpShortName: String?

override static func cpKeys() -> Array<String> {
return ["Id","Name","ShortName"]
}
}

/** 
  Get User Enrolled State. 
*/
@objc(GetUserEnrolledState)
public class GetUserEnrolledState : StateNameClientObjectBase {


/// User_ I D
var cpUser_ID: String?

override static func cpKeys() -> Array<String> {
return ["User_ID"]
}
}

/** 
  Get User Enrolled State Response. 
*/
@objc(GetUserEnrolledStateResponse)
public class GetUserEnrolledStateResponse : StateNameClientObjectBase {


/// Get User Enrolled State Result
var cpGetUserEnrolledStateResult: String?

override static func cpKeys() -> Array<String> {
return ["GetUserEnrolledStateResult"]
}
}


/**
    A generic base class for all Objects.
*/
public class StateNameClientObjectBase : NSObject
{
    var xmlResponseString: String?

    class func cpKeys() -> Array <String>
    {
        return []
    }
    
    required override public init(){}
  
    class func newInstance() -> Self {
        return self.init()
    }


}
