//
//  SoapClient.swift
//  SoapDemo
//
//  Created by User on 5/28/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit
import SWXMLHash


class SoapClient: NSObject {
    static var sharedManager: SoapClient  {
        return SoapClient()
    }
    
    private override init() {
        //
    }
    
    func callWebServiceWithSoapMessage(serviceUrl:String,soapAction:String, soapMessage:String, complitionHandler:@escaping (String?,String?) -> Void){
        guard let url = URL(string: serviceUrl) else{return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
     
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
         
            if error != nil{
                complitionHandler(nil,error.debugDescription)
            }
           else if data != nil{
               
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                complitionHandler(backToString,nil)


               // print(backToString)
            }
        }
        
        task.resume()
        
    }
    
    
    
    
    func callWebServiceToGetArrayWithSoapMessage(serviceUrl:String,soapAction:String, soapMessage:String, complitionHandler:@escaping (Bool,Any?,String?) -> Void){
        guard let url = URL(string: serviceUrl) else{return}
        
        let contentLength = String(soapMessage.count)
        var urlRequest = URLRequest(url: url)
        
        urlRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        urlRequest.addValue(contentLength, forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = soapMessage.data(using: .utf8, allowLossyConversion: false)
        urlRequest.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil{
                complitionHandler(false,nil,error.debugDescription)
            }
            else if data != nil{
                let backToString = String(data: data!, encoding: String.Encoding.utf8)
                
                let xml = SWXMLHash.parse(backToString!)
                
                print(xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["States"])
                var dictGetAllStatesResult = [String:Any]()
                
                var stateMasterArray = [[String:String]]()
                
                
                for elem in xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["States"]["StateMaster"].all {
                    let dictMaster = ["Id":elem["Id"].element?.text ?? "",
                                      "Name":elem["Name"].element?.text ?? "",
                                      "ShortName":elem["ShortName"].element?.text ?? ""]
                    
                    print(elem["Id"].element?.text ?? "")
                    print(elem["Name"].element?.text ?? "")
                    print(elem["ShortName"].element?.text ?? "")
                    stateMasterArray.append(dictMaster)
                }
                
                print(stateMasterArray)
                
                let message = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Message"].element?.text ?? ""
                
                let status = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Status"].element?.text ?? ""

                let requestKey = xml["soap:Envelope"]["soap:Body"]["GetAllStatesResponse"]["GetAllStatesResult"]["Requestkey"].element?.text ?? ""


                    let finalDict = ["Status": status,
                                     "Message": message,
                                     "RequestKey": requestKey,
                                     "States": stateMasterArray] as [String : Any]
                
                dictGetAllStatesResult = ["GetAllStatesResult":finalDict]
                
                complitionHandler(true,dictGetAllStatesResult,"Response Received")
            }
        }
        
        task.resume()
        
    }
    
}
