 
/* 
Copyright (c) 2019 Syed Absar Karim https://www.linkedin.com/in/syedabsar

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
 
import Foundation

/* Soap Client Generated from WSDL: https://lexnarro.com.au/services/registration.asmx?wsdl powered by http://www.wsdl2swift.com */

public class RegisterClient {

/**
    Calls the SOAP Operation: UserRegistration with Message based on UserRegistration Object.

    - parameter userRegistration:  UserRegistration Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opUserRegistration(userRegistration : UserRegistration , completionHandler: (UserRegistrationResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Registration.asmx\"><SOAP-ENV:Body><ns1:UserRegistration><ns1:FirstName>%@</ns1:FirstName><ns1:LastName>%@</ns1:LastName><ns1:OtherName>%@</ns1:OtherName><ns1:StreetNumber>%@</ns1:StreetNumber><ns1:StreetName>%@</ns1:StreetName><ns1:PostCode>%@</ns1:PostCode><ns1:Suburb>%@</ns1:Suburb><ns1:stateName>%@</ns1:stateName><ns1:countryName>%@</ns1:countryName><ns1:StateEnrolledName>%@</ns1:StateEnrolledName><ns1:LawSocietyNumber>%@</ns1:LawSocietyNumber><ns1:EmailAddress>%@</ns1:EmailAddress><ns1:PhoneNumber>%@</ns1:PhoneNumber><ns1:Password>%@</ns1:Password><ns1:Address>%@</ns1:Address><ns1:Device_Imei>%@</ns1:Device_Imei><ns1:Device_Token>%@</ns1:Device_Token><ns1:Device_Type>%@</ns1:Device_Type></ns1:UserRegistration></SOAP-ENV:Body></SOAP-ENV:Envelope>",userRegistration.cpFirstName!,userRegistration.cpLastName!,userRegistration.cpOtherName!,userRegistration.cpStreetNumber!,userRegistration.cpStreetName!,userRegistration.cpPostCode!,userRegistration.cpSuburb!,userRegistration.cpStateName!,userRegistration.cpCountryName!,userRegistration.cpStateEnrolledName!,userRegistration.cpLawSocietyNumber!,userRegistration.cpEmailAddress!,userRegistration.cpPhoneNumber!,userRegistration.cpPassword!,userRegistration.cpAddress!,userRegistration.cpDevice_Imei!,userRegistration.cpDevice_Token!,userRegistration.cpDevice_Type!)

self.makeSoapConnection("https://lexnarro.com.au/services/registration.asmx", soapAction: "http://www.jajtechnologies.com/serives/Registration.asmx/UserRegistration", soapMessage: soapMessage, soapVersion: "1", className:"UserRegistrationResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? UserRegistrationResponse,error) })
 }



/**
    Private Method: Make Soap Connection.
    
    - parameter soapLocation: String.
    - soapAction: String.
    - soapMessage: String.
    - soapVersion: String (1.1 Or 1.2).
    - className: String.
    - completionHandler: Handler.
    - returns: Void.
    */
private func makeSoapConnection(soapLocation: String, soapAction: String, soapMessage: String,  soapVersion: String, className: String, completionHandler: (SyedAbsarObjectBase?, NSError?) -> Void) {
        
        let request = NSMutableURLRequest(URL: NSURL(string: soapLocation)!)
        let msgLength  = String(soapMessage.characters.count)
        let data = soapMessage.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        
        request.HTTPMethod = "POST"
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        // request.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        request.HTTPBody = data
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let datastring = NSString(data: data!, encoding:NSUTF8StringEncoding) as! String
            print(datastring)
            
            //This is a temporary code where it returns the actual XML Response
            //At the moment, response parsing and mapping is under progress
            let aClass = NSClassFromString(className) as! SyedAbsarObjectBase.Type
            let currentResp = aClass.newInstance()
            currentResp.xmlResponseString = "\(datastring)"
            completionHandler(currentResp, error)
            return

			//TODO: Code in progress for response parsing and mapping
			/*
            let xml = SWXMLHash.parse(datastring)
            
            let  coreElementKey = className
            
            let aClass = NSClassFromString(className) as! SyedAbsarObjectBase.Type
            
            let obj = aClass
            
            let inst = obj.newInstance()
            
			var error : NSError?
            let soapFault = xml["soap:Envelope"]["soap:Body"]["soap:Fault"]
            
            if soapFault {
            
                let val =  soapFault["faultstring"].element?.text
                
                error =  NSError(domain: "soapFault", code: 0, userInfo: NSDictionary(object: val!, forKey: NSLocalizedDescriptionKey) as [NSObject : AnyObject])
            }
            
            if (error == nil) {
                for key in obj.cpKeys()  {
                    
                    let body =  xml["soap:Envelope"]["soap:Body"]
                    let val =  body[coreElementKey][key].element?.text
                    
                    inst.setValue(val, forKeyPath: "cp"+key)
                    
                    print (inst)
                }
            }
            completionHandler(inst, error)
            */

        }
        task.resume()

    }    




}
/** 
  User Registration. 
*/
@objc(UserRegistration)
public class UserRegistration : SyedAbsarObjectBase {


/// First Name
var cpFirstName: String?

/// Last Name
var cpLastName: String?

/// Other Name
var cpOtherName: String?

/// Street Number
var cpStreetNumber: String?

/// Street Name
var cpStreetName: String?

/// Post Code
var cpPostCode: String?

/// Suburb
var cpSuburb: String?

/// State Name
var cpStateName: String?

/// Country Name
var cpCountryName: String?

/// State Enrolled Name
var cpStateEnrolledName: String?

/// Law Society Number
var cpLawSocietyNumber: String?

/// Email Address
var cpEmailAddress: String?

/// Phone Number
var cpPhoneNumber: String?

/// Password
var cpPassword: String?

/// Address
var cpAddress: String?

/// Device_ Imei
var cpDevice_Imei: String?

/// Device_ Token
var cpDevice_Token: String?

/// Device_ Type
var cpDevice_Type: String?

override static func cpKeys() -> Array<String> {
return ["FirstName","LastName","OtherName","StreetNumber","StreetName","PostCode","Suburb","StateName","CountryName","StateEnrolledName","LawSocietyNumber","EmailAddress","PhoneNumber","Password","Address","Device_Imei","Device_Token","Device_Type"]
}
}

/** 
  User Registration Response. 
*/
@objc(UserRegistrationResponse)
public class UserRegistrationResponse : SyedAbsarObjectBase {


/// User Registration Result
var cpUserRegistrationResult: String?

override static func cpKeys() -> Array<String> {
return ["UserRegistrationResult"]
}
}

/** 
  Data_return. 
*/
@objc(Data_return)
public class Data_return : SyedAbsarObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// Token
var cpToken: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","Token"]
}
}


/**
    A generic base class for all Objects.
*/
public class SyedAbsarObjectBase : NSObject
{
    var xmlResponseString: String?

    class func cpKeys() -> Array <String>
    {
        return []
    }
    
    required override public init(){}
  
    class func newInstance() -> Self {
        return self.init()
    }


}
