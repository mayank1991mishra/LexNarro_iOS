 
/* 
Copyright (c) 2019 Syed Absar Karim https://www.linkedin.com/in/syedabsar

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
 
import Foundation

/* Soap Client Generated from WSDL: https://lexnarro.com.au/services/training.asmx?wsdl powered by http://www.wsdl2swift.com */

public class TrainingClient {

/**
    Calls the SOAP Operation: GetTraining with Message based on GetTraining Object.

    - parameter getTraining:  GetTraining Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opGetTraining(getTraining : GetTraining , completionHandler: (GetTrainingResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetTraining><ns1:email>%@</ns1:email><ns1:finYear>%@</ns1:finYear></ns1:GetTraining></SOAP-ENV:Body></SOAP-ENV:Envelope>",getTraining.cpEmail!,getTraining.cpFinYear!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetTraining", soapMessage: soapMessage, soapVersion: "1", className:"GetTrainingResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? GetTrainingResponse,error) })
 }

/**
    Calls the SOAP Operation: DetailTraining with Message based on DetailTraining Object.

    - parameter detailTraining:  DetailTraining Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opDetailTraining(detailTraining : DetailTraining , completionHandler: (DetailTrainingResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:DetailTraining><ns1:id>%@</ns1:id></ns1:DetailTraining></SOAP-ENV:Body></SOAP-ENV:Envelope>",detailTraining.cpId!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/DetailTraining", soapMessage: soapMessage, soapVersion: "1", className:"DetailTrainingResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? DetailTrainingResponse,error) })
 }

/**
    Calls the SOAP Operation: GetCategories with Message based on GetCategories Object.

    - parameter getCategories:  GetCategories Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opGetCategories(getCategories : GetCategories , completionHandler: (GetCategoriesResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetCategories><ns1:stateId>%@</ns1:stateId></ns1:GetCategories></SOAP-ENV:Body></SOAP-ENV:Envelope>",getCategories.cpStateId!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetCategories", soapMessage: soapMessage, soapVersion: "1", className:"GetCategoriesResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? GetCategoriesResponse,error) })
 }

/**
    Calls the SOAP Operation: GetActivities with Message based on GetActivities Object.

    - parameter getActivities:  GetActivities Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opGetActivities(getActivities : GetActivities , completionHandler: (GetActivitiesResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetActivities><ns1:stateId>%@</ns1:stateId></ns1:GetActivities></SOAP-ENV:Body></SOAP-ENV:Envelope>",getActivities.cpStateId!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetActivities", soapMessage: soapMessage, soapVersion: "1", className:"GetActivitiesResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? GetActivitiesResponse,error) })
 }

/**
    Calls the SOAP Operation: GetSubActivities with Message based on GetSubActivities Object.

    - parameter getSubActivities:  GetSubActivities Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opGetSubActivities(getSubActivities : GetSubActivities , completionHandler: (GetSubActivitiesResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:GetSubActivities><ns1:stateId>%@</ns1:stateId><ns1:activityId>%@</ns1:activityId></ns1:GetSubActivities></SOAP-ENV:Body></SOAP-ENV:Envelope>",getSubActivities.cpStateId!,getSubActivities.cpActivityId!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/GetSubActivities", soapMessage: soapMessage, soapVersion: "1", className:"GetSubActivitiesResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? GetSubActivitiesResponse,error) })
 }

/**
    Calls the SOAP Operation: CreateTraining with Message based on CreateTraining Object.

    - parameter createTraining:  CreateTraining Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opCreateTraining(createTraining : CreateTraining , completionHandler: (CreateTrainingResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:CreateTraining><ns1:User_Id>%@</ns1:User_Id><ns1:Date>%@</ns1:Date><ns1:State_Id>%@</ns1:State_Id><ns1:Category_Id>%@</ns1:Category_Id><ns1:Activity_Id>%@</ns1:Activity_Id><ns1:SubActivity_Id>%@</ns1:SubActivity_Id><ns1:Hours>%@</ns1:Hours><ns1:Provider>%@</ns1:Provider><ns1:Your_Role>%@</ns1:Your_Role><ns1:Descrption>%@</ns1:Descrption><ns1:FileName>%@</ns1:FileName><ns1:File>JUA=</ns1:File></ns1:CreateTraining></SOAP-ENV:Body></SOAP-ENV:Envelope>",createTraining.cpUser_Id!,createTraining.cpDate!,createTraining.cpState_Id!,createTraining.cpCategory_Id!,createTraining.cpActivity_Id!,createTraining.cpSubActivity_Id!,createTraining.cpHours!,createTraining.cpProvider!,createTraining.cpYour_Role!,createTraining.cpDescrption!,createTraining.cpFileName!,createTraining.cpFile!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/CreateTraining", soapMessage: soapMessage, soapVersion: "1", className:"CreateTrainingResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? CreateTrainingResponse,error) })
 }

/**
    Calls the SOAP Operation: EditTraining with Message based on EditTraining Object.

    - parameter editTraining:  EditTraining Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opEditTraining(editTraining : EditTraining , completionHandler: (EditTrainingResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:EditTraining><ns1:recordId>%@</ns1:recordId><ns1:User_Id>%@</ns1:User_Id><ns1:Date>%@</ns1:Date><ns1:State_Id>%@</ns1:State_Id><ns1:Category_Id>%@</ns1:Category_Id><ns1:Activity_Id>%@</ns1:Activity_Id><ns1:SubActivity_Id>%@</ns1:SubActivity_Id><ns1:Hours>%@</ns1:Hours><ns1:Provider>%@</ns1:Provider><ns1:Your_Role>%@</ns1:Your_Role><ns1:Descrption>%@</ns1:Descrption><ns1:FileName>%@</ns1:FileName><ns1:File>JUA=</ns1:File></ns1:EditTraining></SOAP-ENV:Body></SOAP-ENV:Envelope>",editTraining.cpRecordId!,editTraining.cpUser_Id!,editTraining.cpDate!,editTraining.cpState_Id!,editTraining.cpCategory_Id!,editTraining.cpActivity_Id!,editTraining.cpSubActivity_Id!,editTraining.cpHours!,editTraining.cpProvider!,editTraining.cpYour_Role!,editTraining.cpDescrption!,editTraining.cpFileName!,editTraining.cpFile!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/EditTraining", soapMessage: soapMessage, soapVersion: "1", className:"EditTrainingResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? EditTrainingResponse,error) })
 }

/**
    Calls the SOAP Operation: DeleteTraining with Message based on DeleteTraining Object.

    - parameter deleteTraining:  DeleteTraining Object.
    - parameter completionHandler:  The Callback Handler.

    - returns: Void.
*/
public func opDeleteTraining(deleteTraining : DeleteTraining , completionHandler: (DeleteTrainingResponse?, NSError?) -> Void) { 

let soapMessage = String(format:"<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://www.jajtechnologies.com/serives/Training.asmx\"><SOAP-ENV:Body><ns1:DeleteTraining><ns1:Id>%@</ns1:Id></ns1:DeleteTraining></SOAP-ENV:Body></SOAP-ENV:Envelope>",deleteTraining.cpId!)

self.makeSoapConnection("https://lexnarro.com.au/services/training.asmx", soapAction: "http://www.jajtechnologies.com/serives/Training.asmx/DeleteTraining", soapMessage: soapMessage, soapVersion: "1", className:"DeleteTrainingResponse", completionHandler: { (syedabsarObj:SyedAbsarObjectBase?, error: NSError? )->Void in completionHandler(syedabsarObj  as? DeleteTrainingResponse,error) })
 }



/**
    Private Method: Make Soap Connection.
    
    - parameter soapLocation: String.
    - soapAction: String.
    - soapMessage: String.
    - soapVersion: String (1.1 Or 1.2).
    - className: String.
    - completionHandler: Handler.
    - returns: Void.
    */
private func makeSoapConnection(soapLocation: String, soapAction: String, soapMessage: String,  soapVersion: String, className: String, completionHandler: (SyedAbsarObjectBase?, NSError?) -> Void) {
        
        let request = NSMutableURLRequest(URL: NSURL(string: soapLocation)!)
        let msgLength  = String(soapMessage.characters.count)
        let data = soapMessage.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        
        request.HTTPMethod = "POST"
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        // request.addValue(soapAction, forHTTPHeaderField: "SOAPAction")
        request.HTTPBody = data
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let datastring = NSString(data: data!, encoding:NSUTF8StringEncoding) as! String
            print(datastring)
            
            //This is a temporary code where it returns the actual XML Response
            //At the moment, response parsing and mapping is under progress
            let aClass = NSClassFromString(className) as! SyedAbsarObjectBase.Type
            let currentResp = aClass.newInstance()
            currentResp.xmlResponseString = "\(datastring)"
            completionHandler(currentResp, error)
            return

			//TODO: Code in progress for response parsing and mapping
			/*
            let xml = SWXMLHash.parse(datastring)
            
            let  coreElementKey = className
            
            let aClass = NSClassFromString(className) as! SyedAbsarObjectBase.Type
            
            let obj = aClass
            
            let inst = obj.newInstance()
            
			var error : NSError?
            let soapFault = xml["soap:Envelope"]["soap:Body"]["soap:Fault"]
            
            if soapFault {
            
                let val =  soapFault["faultstring"].element?.text
                
                error =  NSError(domain: "soapFault", code: 0, userInfo: NSDictionary(object: val!, forKey: NSLocalizedDescriptionKey) as [NSObject : AnyObject])
            }
            
            if (error == nil) {
                for key in obj.cpKeys()  {
                    
                    let body =  xml["soap:Envelope"]["soap:Body"]
                    let val =  body[coreElementKey][key].element?.text
                    
                    inst.setValue(val, forKeyPath: "cp"+key)
                    
                    print (inst)
                }
            }
            completionHandler(inst, error)
            */

        }
        task.resume()

    }    




}
/** 
  Get Training. 
*/
@objc(GetTraining)
public class GetTraining : SyedAbsarObjectBase {


/// Email
var cpEmail: String?

/// Fin Year
var cpFinYear: String?

override static func cpKeys() -> Array<String> {
return ["Email","FinYear"]
}
}

/** 
  Get Training Response. 
*/
@objc(GetTrainingResponse)
public class GetTrainingResponse : SyedAbsarObjectBase {


/// Get Training Result
var cpGetTrainingResult: String?

override static func cpKeys() -> Array<String> {
return ["GetTrainingResult"]
}
}

/** 
  Return Data. 
*/
@objc(ReturnData)
public class ReturnData : SyedAbsarObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// User Training
var cpUserTraining: String?

/// Financial Year
var cpFinancialYear: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","UserTraining","FinancialYear"]
}
}

/** 
  Array Of User Training Transaction. 
*/
@objc(ArrayOfUserTrainingTransaction)
public class ArrayOfUserTrainingTransaction : SyedAbsarObjectBase {


/// User Training Transaction
var cpUserTrainingTransaction: String?

override static func cpKeys() -> Array<String> {
return ["UserTrainingTransaction"]
}
}

/** 
  User Training Transaction. 
*/
@objc(UserTrainingTransaction)
public class UserTrainingTransaction : SyedAbsarObjectBase {


/// Id
var cpId: Double?

/// Transaction Id
var cpTransactionId: Double?

/// User_ Id
var cpUser_Id: Double?

/// First Name
var cpFirstName: String?

/// Date
var cpDate: NSDate?

/// State Id
var cpStateId: Double?

/// State Name
var cpStateName: String?

/// Category Id
var cpCategoryId: Double?

/// Category Name
var cpCategoryName: String?

/// Activity Id
var cpActivityId: Double?

/// Activity Name
var cpActivityName: String?

/// Sub Activity Id
var cpSubActivityId: Double?

/// Sub Activity Name
var cpSubActivityName: String?

/// Hours
var cpHours: Double?

/// Provider
var cpProvider: String?

/// Financial_ Year
var cpFinancial_Year: String?

/// Your_ Role
var cpYour_Role: String?

/// Forwardable
var cpForwardable: String?

/// Has_been_ Forwarded
var cpHas_been_Forwarded: String?

/// Descrption
var cpDescrption: String?

/// Units
var cpUnits: Double?

override static func cpKeys() -> Array<String> {
return ["Id","TransactionId","User_Id","FirstName","Date","StateId","StateName","CategoryId","CategoryName","ActivityId","ActivityName","SubActivityId","SubActivityName","Hours","Provider","Financial_Year","Your_Role","Forwardable","Has_been_Forwarded","Descrption","Units"]
}
}

/** 
  Array Of Select List Item. 
*/
@objc(ArrayOfSelectListItem)
public class ArrayOfSelectListItem : SyedAbsarObjectBase {


/// Select List Item
var cpSelectListItem: String?

override static func cpKeys() -> Array<String> {
return ["SelectListItem"]
}
}

/** 
  Select List Item. 
*/
@objc(SelectListItem)
public class SelectListItem : SyedAbsarObjectBase {


/// Disabled
var cpDisabled: Bool?

/// Group
var cpGroup: String?

/// Selected
var cpSelected: Bool?

/// Text
var cpText: String?

/// Value
var cpValue: String?

override static func cpKeys() -> Array<String> {
return ["Disabled","Group","Selected","Text","Value"]
}
}

/** 
  Select List Group. 
*/
@objc(SelectListGroup)
public class SelectListGroup : SyedAbsarObjectBase {


/// Disabled
var cpDisabled: Bool?

/// Name
var cpName: String?

override static func cpKeys() -> Array<String> {
return ["Disabled","Name"]
}
}

/** 
  Detail Training. 
*/
@objc(DetailTraining)
public class DetailTraining : SyedAbsarObjectBase {


/// Id
var cpId: String?

override static func cpKeys() -> Array<String> {
return ["Id"]
}
}

/** 
  Detail Training Response. 
*/
@objc(DetailTrainingResponse)
public class DetailTrainingResponse : SyedAbsarObjectBase {


/// Detail Training Result
var cpDetailTrainingResult: String?

override static func cpKeys() -> Array<String> {
return ["DetailTrainingResult"]
}
}

/** 
  Get Categories. 
*/
@objc(GetCategories)
public class GetCategories : SyedAbsarObjectBase {


/// State Id
var cpStateId: String?

override static func cpKeys() -> Array<String> {
return ["StateId"]
}
}

/** 
  Get Categories Response. 
*/
@objc(GetCategoriesResponse)
public class GetCategoriesResponse : SyedAbsarObjectBase {


/// Get Categories Result
var cpGetCategoriesResult: String?

override static func cpKeys() -> Array<String> {
return ["GetCategoriesResult"]
}
}

/** 
  Return Category List. 
*/
@objc(ReturnCategoryList)
public class ReturnCategoryList : SyedAbsarObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// User Categories
var cpUserCategories: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","UserCategories"]
}
}

/** 
  Array Of Category_ Master. 
*/
@objc(ArrayOfCategory_Master)
public class ArrayOfCategory_Master : SyedAbsarObjectBase {


/// Category_ Master
var cpCategory_Master: String?

override static func cpKeys() -> Array<String> {
return ["Category_Master"]
}
}

/** 
  Category_ Master. 
*/
@objc(Category_Master)
public class Category_Master : SyedAbsarObjectBase {


/// I D
var cpID: Double?

/// Name
var cpName: String?

override static func cpKeys() -> Array<String> {
return ["ID","Name"]
}
}

/** 
  Get Activities. 
*/
@objc(GetActivities)
public class GetActivities : SyedAbsarObjectBase {


/// State Id
var cpStateId: String?

override static func cpKeys() -> Array<String> {
return ["StateId"]
}
}

/** 
  Get Activities Response. 
*/
@objc(GetActivitiesResponse)
public class GetActivitiesResponse : SyedAbsarObjectBase {


/// Get Activities Result
var cpGetActivitiesResult: String?

override static func cpKeys() -> Array<String> {
return ["GetActivitiesResult"]
}
}

/** 
  Return Activity List. 
*/
@objc(ReturnActivityList)
public class ReturnActivityList : SyedAbsarObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// User Activities
var cpUserActivities: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","UserActivities"]
}
}

/** 
  Array Of Activity_ Master. 
*/
@objc(ArrayOfActivity_Master)
public class ArrayOfActivity_Master : SyedAbsarObjectBase {


/// Activity_ Master
var cpActivity_Master: String?

override static func cpKeys() -> Array<String> {
return ["Activity_Master"]
}
}

/** 
  Activity_ Master. 
*/
@objc(Activity_Master)
public class Activity_Master : SyedAbsarObjectBase {


/// I D
var cpID: Double?

/// Name
var cpName: String?

override static func cpKeys() -> Array<String> {
return ["ID","Name"]
}
}

/** 
  Get Sub Activities. 
*/
@objc(GetSubActivities)
public class GetSubActivities : SyedAbsarObjectBase {


/// State Id
var cpStateId: String?

/// Activity Id
var cpActivityId: String?

override static func cpKeys() -> Array<String> {
return ["StateId","ActivityId"]
}
}

/** 
  Get Sub Activities Response. 
*/
@objc(GetSubActivitiesResponse)
public class GetSubActivitiesResponse : SyedAbsarObjectBase {


/// Get Sub Activities Result
var cpGetSubActivitiesResult: String?

override static func cpKeys() -> Array<String> {
return ["GetSubActivitiesResult"]
}
}

/** 
  Return Sub Activity List. 
*/
@objc(ReturnSubActivityList)
public class ReturnSubActivityList : SyedAbsarObjectBase {


/// Status
var cpStatus: String?

/// Message
var cpMessage: String?

/// Requestkey
var cpRequestkey: String?

/// User Sub Activities
var cpUserSubActivities: String?

override static func cpKeys() -> Array<String> {
return ["Status","Message","Requestkey","UserSubActivities"]
}
}

/** 
  Array Of Sub_ Activity_ Master. 
*/
@objc(ArrayOfSub_Activity_Master)
public class ArrayOfSub_Activity_Master : SyedAbsarObjectBase {


/// Sub_ Activity_ Master
var cpSub_Activity_Master: String?

override static func cpKeys() -> Array<String> {
return ["Sub_Activity_Master"]
}
}

/** 
  Sub_ Activity_ Master. 
*/
@objc(Sub_Activity_Master)
public class Sub_Activity_Master : SyedAbsarObjectBase {


/// I D
var cpID: String?

/// Name
var cpName: String?

/// Activity_ I D
var cpActivity_ID: Double?

/// Short Name
var cpShortName: String?

/// State I D
var cpStateID: Double?

override static func cpKeys() -> Array<String> {
return ["ID","Name","Activity_ID","ShortName","StateID"]
}
}

/** 
  Create Training. 
*/
@objc(CreateTraining)
public class CreateTraining : SyedAbsarObjectBase {


/// User_ Id
var cpUser_Id: String?

/// Date
var cpDate: String?

/// State_ Id
var cpState_Id: String?

/// Category_ Id
var cpCategory_Id: String?

/// Activity_ Id
var cpActivity_Id: String?

/// Sub Activity_ Id
var cpSubActivity_Id: String?

/// Hours
var cpHours: String?

/// Provider
var cpProvider: String?

/// Your_ Role
var cpYour_Role: String?

/// Descrption
var cpDescrption: String?

/// File Name
var cpFileName: String?

/// File
var cpFile: String?

override static func cpKeys() -> Array<String> {
return ["User_Id","Date","State_Id","Category_Id","Activity_Id","SubActivity_Id","Hours","Provider","Your_Role","Descrption","FileName","File"]
}
}

/** 
  Create Training Response. 
*/
@objc(CreateTrainingResponse)
public class CreateTrainingResponse : SyedAbsarObjectBase {


/// Create Training Result
var cpCreateTrainingResult: String?

override static func cpKeys() -> Array<String> {
return ["CreateTrainingResult"]
}
}

/** 
  Edit Training. 
*/
@objc(EditTraining)
public class EditTraining : SyedAbsarObjectBase {


/// Record Id
var cpRecordId: String?

/// User_ Id
var cpUser_Id: String?

/// Date
var cpDate: String?

/// State_ Id
var cpState_Id: String?

/// Category_ Id
var cpCategory_Id: String?

/// Activity_ Id
var cpActivity_Id: String?

/// Sub Activity_ Id
var cpSubActivity_Id: String?

/// Hours
var cpHours: String?

/// Provider
var cpProvider: String?

/// Your_ Role
var cpYour_Role: String?

/// Descrption
var cpDescrption: String?

/// File Name
var cpFileName: String?

/// File
var cpFile: String?

override static func cpKeys() -> Array<String> {
return ["RecordId","User_Id","Date","State_Id","Category_Id","Activity_Id","SubActivity_Id","Hours","Provider","Your_Role","Descrption","FileName","File"]
}
}

/** 
  Edit Training Response. 
*/
@objc(EditTrainingResponse)
public class EditTrainingResponse : SyedAbsarObjectBase {


/// Edit Training Result
var cpEditTrainingResult: String?

override static func cpKeys() -> Array<String> {
return ["EditTrainingResult"]
}
}

/** 
  Delete Training. 
*/
@objc(DeleteTraining)
public class DeleteTraining : SyedAbsarObjectBase {


/// Id
var cpId: String?

override static func cpKeys() -> Array<String> {
return ["Id"]
}
}

/** 
  Delete Training Response. 
*/
@objc(DeleteTrainingResponse)
public class DeleteTrainingResponse : SyedAbsarObjectBase {


/// Delete Training Result
var cpDeleteTrainingResult: String?

override static func cpKeys() -> Array<String> {
return ["DeleteTrainingResult"]
}
}

/** 
  String Array[]. 
*/
@objc(StringArray[])
public class StringArray[] : SyedAbsarObjectBase {


override static func cpKeys() -> Array<String> {
return []
}
}


/**
    A generic base class for all Objects.
*/
public class SyedAbsarObjectBase : NSObject
{
    var xmlResponseString: String?

    class func cpKeys() -> Array <String>
    {
        return []
    }
    
    required override public init(){}
  
    class func newInstance() -> Self {
        return self.init()
    }


}
